"use strict";
// ============================================================ yardımcılar
// Tek dosya sürümünde (tools/tek_dosya.py) bütün dosyalar sayfanın içine gömülür; yol() onları blob adresine çevirir.
// Normal sürümde LUMI_VARLIK yoktur ve yol() adresi olduğu gibi döndürür.
const GOMULU = window.LUMI_VARLIK || null, _blob = {};
function yol(u) {
  if (!GOMULU || !GOMULU[u]) return (window.LUMI_TEMEL && !/^(?:[a-z]+:|\/|#)/i.test(u)) ? window.LUMI_TEMEL + u : u;
  if (!_blob[u]) {
    const [tip, b64] = GOMULU[u], ham = atob(b64), d = new Uint8Array(ham.length);
    for (let i = 0; i < ham.length; i++) d[i] = ham.charCodeAt(i);
    _blob[u] = URL.createObjectURL(new Blob([d], { type: tip }));
  }
  return _blob[u];
}
const getir = u => fetch(yol(u));
const $ = s => document.querySelector(s);
function h(etiket, oz, ...cocuklar) {
  const e = document.createElement(etiket);
  if (oz) for (const [k, v] of Object.entries(oz)) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "style") e.style.cssText = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : k === "src" || k === "poster" ? yol(v) : v);
  }
  for (const c of cocuklar.flat(9)) if (c != null && c !== false) e.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return e;
}
const karistir = a => { const b = a.slice(); for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };
const rastgele = a => a[Math.floor(Math.random() * a.length)];
const bekle = ms => new Promise(r => setTimeout(r, ms));
const depo = { al(k) { try { return localStorage.getItem(k); } catch { return null; } }, yaz(k, v) { try { localStorage.setItem(k, v); } catch {} } };
function acikRenk(hex, oran = .78) {
  const n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255, k = c => Math.round(c + (255 - c) * oran);
  return `rgb(${k(r)},${k(g)},${k(b)})`;
}
let V = null; // veri.json
let EMOJI = {};
function em(kod, px = 64) {
  const i = EMOJI[kod];
  if (i == null) {
    const kutu = h("span", { class: "em", "aria-hidden": "true", style: `width:${px}px;height:${px}px` });
    const ic = typeof Geo !== "undefined" && Geo.ikon(kod);
    if (ic) {
      kutu.innerHTML = `<svg class="geo em-geo" viewBox="-130 -280 260 290" width="${px}" height="${px}" xmlns="http://www.w3.org/2000/svg">${ic}</svg>`;
      requestAnimationFrame(() => { try { const sv = kutu.firstChild, b = sv.firstChild.getBBox(), m = Math.max(b.width, b.height) / 2 + 6, cx = b.x + b.width / 2, cy = b.y + b.height / 2; if (b.width) sv.setAttribute("viewBox", `${cx - m} ${cy - m} ${2 * m} ${2 * m}`); } catch {} });
    }
    return kutu;
  }
  const { sutun, satir } = V.emoji, x = i % sutun, y = Math.floor(i / sutun);
  return h("span", { class: "em", "aria-hidden": "true", style: `width:${px}px;height:${px}px;background-image:url(${yol("img/emoji.png")});background-size:${sutun * 100}% ${satir * 100}%;background-position:${x / (sutun - 1) * 100}% ${y / (satir - 1) * 100}%` });
}
const SEKIL = {
  cerc: '<circle cx="50" cy="50" r="42"/>', patrat: '<rect x="12" y="12" width="76" height="76" rx="6"/>', triunghi: '<path d="M50 10 92 86H8z"/>',
  dreptunghi: '<rect x="6" y="26" width="88" height="48" rx="6"/>', stea: '<path d="M50 6l12.6 27.4 29.9 3.4-22.3 20.2 6.2 29.5L50 71.6 23.6 86.5l6.2-29.5L7.5 36.8l29.9-3.4z"/>',
  inima: '<path d="M50 88S8 62 8 34a20 20 0 0 1 42-8 20 20 0 0 1 42 8c0 28-42 54-42 54z"/>', oval: '<ellipse cx="50" cy="50" rx="44" ry="30"/>', romb: '<path d="M50 6 90 50 50 94 10 50z"/>',
  pata: '<path d="M52 8c18 0 38 10 38 32s-6 38-30 46S10 82 10 56 30 8 52 8z"/>',
};
function sekil(ad, renk = "#42A5F5", px = 100) {
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  s.setAttribute("viewBox", "0 0 100 100"); s.setAttribute("width", px); s.setAttribute("height", px);
  s.innerHTML = `<g fill="${renk}" stroke="rgba(0,0,0,.12)" stroke-width="2">${SEKIL[ad] || SEKIL.pata}</g>`;
  return s;
}
// Kelime görseli: emoji, sayı, renk lekesi ya da şekil.
function kelimeGorsel(k, px) {
  if (k.img) return em(k.img, px);
  if (k.sekil) return sekil(k.sekil, k.renk || "#42A5F5", px);
  if (k.renk) return sekil("pata", k.renk, px);
  if (k.sayi != null) return h("span", { style: `width:${px}px;height:${px}px;display:grid;place-items:center;font-family:var(--baslik);font-weight:800;font-size:${Math.round(px * .72)}px;line-height:1;color:#5c6bc0` }, k.sayi);
  return em("2b50", px);
}
const HOPARLOR = '<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z"/></svg>';
function hoparlor(metin, px = 52) {
  const b = h("button", { class: "hoparlor", type: "button", "aria-label": "Ascultă", style: `width:${px}px;height:${px}px` });
  b.innerHTML = HOPARLOR;
  b.addEventListener("click", async e => { e.stopPropagation(); b.classList.add("calar"); await Ses.soyle(metin); b.classList.remove("calar"); });
  return b;
}
function tost(icerik) { const t = $("#tost"); t.replaceChildren(...[icerik].flat()); t.hidden = false; clearTimeout(tost.z); tost.z = setTimeout(() => t.hidden = true, 3200); }
function patlat(x, y, n = 14) {
  if (Kayit.v.az_anim || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, d = 60 + Math.random() * 110;
    const p = h("span", { class: "parcacik", style: `left:${x - 13}px;top:${y - 13}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d}px;--r:${Math.random() * 360}deg` }, rastgele(["⭐", "✨", "💛", "🌟"]));
    document.body.append(p); setTimeout(() => p.remove(), 950);
  }
}
const merkez = el => { const r = el.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; };

// ============================================================ KAYIT (bu tarayıcıda)
const Kayit = {
  ANAHTAR: "lumi-copii",
  v: null,
  bos: () => ({ stele: 0, toplam: 0, sayac: {}, ogrenilen: {}, rozetler: [], varsta: 5, ses_acik: true, ses: .9, az_anim: false, profil: null, hesap: false, t: 0,
    ebeveyn: null, oturum: false, gunler: {}, sure_limit: 0, duyuru_kapali: false, tanitim_goruldu: false }),
  gun() { const k = bugun(), g = this.v.gunler[k] = this.v.gunler[k] || {}; for (const a of ["dk", "e", "s", "ek"]) g[a] = g[a] || 0; return g; },
  yukle() { let d = null; try { d = JSON.parse(depo.al(this.ANAHTAR) || "null"); } catch {} this.v = Object.assign(this.bos(), d || {}); },
  kaydet() {
    const eski = bugun(new Date(Date.now() - 60 * 864e5));
    for (const k of Object.keys(this.v.gunler || {})) if (k < eski) delete this.v.gunler[k];
    this.v.t = Date.now(); depo.yaz(this.ANAHTAR, JSON.stringify(this.v)); Hesap.yaz(); },
  stea(n = 1) { this.v.stele += n; this.gun().s += n; this.kaydet(); steleCiz(); this.rozetKontrol(); },
  etkinlik(kat) { this.v.toplam++; this.gun().e++; this.v.sayac[kat] = (this.v.sayac[kat] || 0) + 1; this.kaydet(); this.rozetKontrol(); },
  ogren(kat, id) {
    const o = this.v.ogrenilen[kat] = this.v.ogrenilen[kat] || [];
    if (id && !o.includes(id)) { o.push(id); this.kaydet(); this.rozetKontrol(); }
  },
  ogrenilenSay(kat) { return kat ? (this.v.ogrenilen[kat] || []).length : Object.values(this.v.ogrenilen).reduce((a, l) => a + l.length, 0); },
  rozetDurum(r) {
    const k = r.kosul;
    const deger = { toplam: this.v.toplam, kategori: this.v.sayac[k.kategori] || 0, ogrenilen: this.ogrenilenSay(k.kategori), ogrenilen_toplam: this.ogrenilenSay(), yildiz: this.v.stele }[k.tip];
    return [Math.min(deger || 0, k.deger), k.deger];
  },
  rozetKontrol() {
    for (const r of rozetler()) {
      if (this.v.rozetler.includes(r.id)) continue;
      const [a, b] = this.rozetDurum(r);
      if (a >= b) { this.v.rozetler.push(r.id); this.kaydet(); Ses.efekt("fanfar"); tost([em(r.img, 34), h("span", null, "Insignă nouă: " + r.ad)]); }
    }
  },
};
const rozetler = () => V.rozetler.filter(r => !["misiune", "puzzle"].includes(r.kosul.kategori));

// Hesap: claude.ai'de oturum açmış ziyaretçinin kimliği; ilerleme kişiye özel kayıtta saklanır.
const Hesap = {
  ref: null, me: null, uzak: false, yaziliyor: false, bekliyor: false, z: 0,
  async bagla() {
    try {
      if (!window.claude || !window.claude.use || !Cihaz.v) return;
      const [db, user] = await Promise.all([window.claude.use("db"), window.claude.use("user")]);
      if (!db || !user) return;
      const me = await user.me();
      if (!me || !me.id) return;
      this.me = me;
      // Her cihazın kendi kaydı var: başka bir cihazın (ana cihazın) oturumu buraya asla yüklenmez.
      this.ref = db.collection("data/users/" + me.id).doc("lumi-" + Cihaz.v.id);
      const snap = await this.ref.get();
      const d = snap.exists ? snap.data() : null;
      if (d && typeof d.json === "string") {
        this.uzak = true;
        const uz = JSON.parse(d.json);
        if ((+d.t || 0) > (Kayit.v.t || 0)) { Kayit.v = Object.assign(Kayit.bos(), uz, { hesap: true }); depo.yaz(Kayit.ANAHTAR, JSON.stringify(Kayit.v)); }
        else Kayit.v.hesap = true;
      }
      steleCiz(); profilCiz();
      if ($("#etkinlik").hidden && $("#uyari").hidden) Yol.ciz();
      if (Kayit.v.hesap) this.yaz();
    } catch (e) { console.warn("hesap", e); }
  },
  yaz() {
    if (!this.ref || !Kayit.v.hesap) return;
    clearTimeout(this.z); this.z = setTimeout(() => this._yaz(), 1500);
  },
  async _yaz() {
    if (this.yaziliyor) { this.bekliyor = true; return; }
    this.yaziliyor = true;
    try { await this.ref.set({ json: JSON.stringify(Kayit.v), t: Kayit.v.t || Date.now() }); this.uzak = true; } catch (e) { console.warn("hesap yaz", e); }
    this.yaziliyor = false;
    if (this.bekliyor) { this.bekliyor = false; this._yaz(); }
  },
};
// ============================================================ CİHAZ KURULUMU
// Her cihaz ilk açılışta kendi kurulumunu yapar ve kendi kimliğini alır. Oturum, profil ve ilerleme
// yalnızca o cihaza aittir; başka cihazda açılan Lumi ana cihazın oturumunu yüklemez.
const Cihaz = {
  ANAHTAR: "lumi-cihaz",
  v: null,
  yukle() { try { const d = JSON.parse(depo.al(this.ANAHTAR) || "null"); this.v = d && d.id ? d : null; } catch { this.v = null; } },
  kaydet() { depo.yaz(this.ANAHTAR, JSON.stringify(this.v)); },
  yeniId() {
    try { if (crypto.randomUUID) return crypto.randomUUID().replace(/-/g, "").slice(0, 16); } catch {}
    let s = ""; for (let i = 0; i < 16; i++) s += Math.floor(Math.random() * 16).toString(16); return s;
  },
  tur() {
    const ua = navigator.userAgent || "", dokunmatik = (navigator.maxTouchPoints || 0) > 1;
    if (/iPad|Tablet/i.test(ua) || (/Android/i.test(ua) && !/Mobile/i.test(ua)) || (/Macintosh/i.test(ua) && dokunmatik)) return "Tablet";
    if (/Mobi|iPhone|Android/i.test(ua)) return "Telefon";
    return "Bilgisayar";
  },
  olustur(ad) { this.v = { id: this.yeniId(), ad: (ad || this.tur()).slice(0, 24), tur: this.tur(), kuruldu: Date.now() }; this.kaydet(); },
  kisaId() { return this.v ? this.v.id.slice(0, 6).toUpperCase() : "—"; },
};
const CIHAZ_TURLERI = [["Tablet", "1f4f1"], ["Telefon", "1f4f1"], ["Bilgisayar", "1f4fa"]];

// Kurulum sihirbazı: 1) cihazı adlandır  2) kurulum (Lumi'nin içerikleri hazırlanır)  3) bu cihazın ayrı oturumu
function kurulumAc(bitince) {
  const u = $("#uyari");
  u.dataset.kilit = "1";
  let ad = Cihaz.tur();
  const kart = h("div", { class: "kart genis kurulum", role: "dialog", "aria-modal": "true", "aria-labelledby": "kurulum-baslik" });
  const adim = (no, ...icerik) => kart.replaceChildren(
    h("div", { class: "kurulum-adimlar", "aria-hidden": "true" }, [1, 2, 3].map(n => h("i", { class: n <= no ? "dolu" : "" }))),
    ...icerik);

  const adim1 = () => {
    const giris = h("input", { class: "giris-k", id: "cihaz-ad", maxlength: "24", value: ad, autocomplete: "off", placeholder: "Örn. Ayşe'nin tableti" });
    giris.addEventListener("input", () => { ad = giris.value; turCiz(); });
    const turlar = h("div", { class: "secimler" });
    const turCiz = () => turlar.replaceChildren(...CIHAZ_TURLERI.map(([t, k]) => h("button", { type: "button", "aria-pressed": giris.value.trim() === t ? "true" : "false",
      onclick: () => { giris.value = ad = t; Ses.efekt("pop"); turCiz(); } }, em(k, 24), " ", t)));
    turCiz();
    const ileri = () => { ad = giris.value.trim() || Cihaz.tur(); adim2(); };
    giris.addEventListener("keydown", e => { if (e.key === "Enter") ileri(); });
    adim(1,
      h("div", { class: "satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Kurulum · Adım 1"), h("h2", { id: "kurulum-baslik", style: "font-size:30px" }, "Bun venit la Lumi!")),
        h("img", { src: "img/lumi_wave.png", alt: "", width: "72", height: "106", style: "width:72px;height:auto;border-radius:16px" })),
      h("p", { class: "tr" }, "Lumi'yi bu cihaza kuralım. Her cihazın kendi kurulumu ve kendi oturumu olur."),
      h("label", { for: "cihaz-ad", style: "display:grid;gap:6px" }, h("b", null, "Bu cihazın adı"), giris),
      turlar,
      h("button", { class: "btn ana", type: "button", onclick: ileri }, "Kurulumu başlat"));
    setTimeout(() => giris.focus(), 60);
  };

  const adim2 = async () => {
    const cubuk = h("i", { style: "width:0%;transition:width .35s" }), yuzde = h("b", { style: "font-family:var(--baslik);font-size:22px" }, "%0");
    const liste = h("ul", { class: "kurulum-liste" });
    adim(2,
      h("div", null, h("span", { class: "kicker" }, "Kurulum · Adım 2"), h("h2", { id: "kurulum-baslik", style: "font-size:30px" }, "Lumi kuruluyor…")),
      h("p", { class: "tr" }, `"${ad}" için hazırlanıyor. Bu birkaç saniye sürer.`),
      h("div", { class: "satir" }, h("div", { class: "cubuk", style: "flex:1;height:16px", role: "progressbar", "aria-label": "Kurulum" }, cubuk), yuzde),
      liste);
    const say = (a) => Array.isArray(a) ? a.length : a && typeof a === "object" ? Object.keys(a).length : 0;
    const adimlar = [
      ["1f511", "Cihaz kimliği oluşturuluyor", () => Cihaz.olustur(ad)],
      ["1f5e3", "Kelimeler ve sesler hazırlanıyor", () => Ses.hazirla("ortak")],
      ["1f524", "Harfler yükleniyor", null],
      ["1f4da", `Hikâyeler hazırlanıyor${V && V.hikayeler ? ` (${say(V.hikayeler)})` : ""}`, null],
      ["1f3ac", `Çizgi filmler ve şarkılar${VIDEOLAR && VIDEOLAR.length ? ` (${VIDEOLAR.length} film)` : ""}`, null],
      ["1f3a8", "Boyama sayfaları ve oyunlar", null],
      ["1f512", "Bu cihaz için ayrı oturum açılıyor", () => { Kayit.v.oturum = false; Kayit.kaydet(); }],
    ];
    for (let i = 0; i < adimlar.length; i++) {
      const [ik, metin, is] = adimlar[i];
      const satir = h("li", { class: "calisiyor" }, em(ik, 24), h("span", null, metin), h("span", { class: "durum", "aria-hidden": "true" }, "…"));
      liste.append(satir);
      try { if (is) await is(); } catch {}
      await bekle(Kayit.v.az_anim ? 150 : 420 + Math.random() * 380);
      satir.className = "tamam"; satir.lastChild.textContent = "✓";
      const p = Math.round((i + 1) / adimlar.length * 100);
      cubuk.style.width = p + "%"; yuzde.textContent = "%" + p;
    }
    Ses.efekt("fanfar");
    await bekle(500);
    adim3();
  };

  const adim3 = () => {
    const bitir = (hedef) => { delete u.dataset.kilit; u.hidden = true; ustCiz(); profilCiz(); steleCiz(); if (bitince) bitince(hedef); };
    adim(3,
      h("div", { class: "satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Kurulum · Tamam"), h("h2", { id: "kurulum-baslik", style: "font-size:30px" }, "Lumi hazır!")),
        h("img", { src: "img/lumi_success.png", alt: "", width: "72", height: "89" })),
      h("div", { class: "cihaz-kimlik" }, em(CIHAZ_TURLERI.find(([t]) => t === Cihaz.v.tur)?.[1] || "1f4f1", 40),
        h("div", { class: "gen" }, h("b", null, Cihaz.v.ad), h("div", { class: "kucuk-not" }, `Cihaz kodu: ${Cihaz.kisaId()}`))),
      h("p", { class: "tr" }, "Bu cihazın oturumu ayrıdır: başka bir cihazdaki hesap, profil ve ilerleme buraya yüklenmez. Bu cihaz için yeni bir hesap ve çocuk profili oluşturun."),
      h("button", { class: "btn ana", type: "button", onclick: () => bitir("kayit") }, "Bu cihazda kayıt ol"),
      h("button", { class: "btn acik", type: "button", onclick: () => bitir("tanitim") }, "Önce Lumi'yi tanı"));
  };

  adim1();
  u.replaceChildren(kart);
  u.hidden = false;
}
function cihazYenidenKurSor() {
  const u = $("#uyari");
  u.replaceChildren(h("div", { class: "kart", role: "dialog", "aria-modal": "true" }, h("h2", { style: "font-size:26px" }, "Bu cihaz yeniden kurulsun mu?"),
    h("p", { class: "tr" }, "Bu cihazdaki hesap, çocuk profili ve tüm ilerleme silinir; cihaz yeni bir kimlikle sıfırdan kurulur. Diğer cihazlar etkilenmez."),
    h("button", { class: "btn ana", type: "button", onclick: () => u.hidden = true }, "Vazgeç"),
    h("button", { class: "btn acik", type: "button", style: "color:var(--kirmizi)", onclick: () => {
      Kayit.v = Object.assign(Kayit.bos(), {}); depo.yaz(Kayit.ANAHTAR, JSON.stringify(Kayit.v));
      Cihaz.v = null; try { localStorage.removeItem(Cihaz.ANAHTAR); } catch {}
      Hesap.ref = null; Kapi.kilitle(); steleCiz(); profilCiz(); ustCiz();
      kurulumAc(hedef => { Yol.git(hedef, {}, false); Hesap.bagla(); });
    } }, "Evet, yeniden kur")));
  u.hidden = false;
}

const AVATARLAR = ["1f98a", "1f430", "1f43c", "1f981", "1f984", "1f42f", "1f438", "1f427"];
function profilCiz() {
  const b = $("#profil-btn"), p = Kayit.v.profil;
  b.className = "profil-btn" + (p ? "" : " yok");
  b.replaceChildren(...(p ? [em(p.avatar, 30), h("span", null, p.ad || "Profil")] : [h("span", null, "Creează profil")]));
  if ($("#giris-btn")) ustCiz();
}
function profilAc() {
  const u = $("#uyari"), p = Object.assign({ ad: "", avatar: AVATARLAR[0], varsta: Kayit.v.varsta }, Kayit.v.profil || {});
  let hesapIste = Kayit.v.hesap || !Kayit.v.profil;
  const ad = h("input", { class: "giris-k", id: "profil-ad", maxlength: "20", placeholder: "Numele copilului", value: p.ad, autocomplete: "off" });
  const av = h("div", { class: "avatarlar", role: "group", "aria-label": "Avatar" });
  const avCiz = () => av.replaceChildren(...AVATARLAR.map(k => h("button", { type: "button", "aria-pressed": p.avatar === k ? "true" : "false", onclick: () => { p.avatar = k; Ses.efekt("pop"); avCiz(); } }, em(k, 48))));
  avCiz();
  const yas = h("div", { class: "secimler" });
  const yasCiz = () => yas.replaceChildren(...[3, 4, 5, 6].map(n => h("button", { type: "button", "aria-pressed": p.varsta === n ? "true" : "false", onclick: () => { p.varsta = n; yasCiz(); } }, `${n} ani`)));
  yasCiz();
  let hesapBlok;
  if (Hesap.me) {
    const kutu = h("input", { type: "checkbox", id: "hesap-kaydet", checked: hesapIste });
    kutu.addEventListener("change", () => hesapIste = kutu.checked);
    hesapBlok = h("div", { style: "display:grid;gap:8px" }, h("b", null, "Hesabına kaydet"),
      h("div", { class: "hesap" }, h("img", { src: Hesap.me.avatarUrl, alt: "" }), h("div", { class: "gen" }, h("b", null, Hesap.me.name || "Hesabın"), h("div", { class: "kucuk-not" }, "claude.ai hesabınla oturum açık")), kutu),
      h("label", { class: "kucuk-not", for: "hesap-kaydet" }, "İşaretliyse bu cihazın profili ve ilerlemesi hesabında yedeklenir. Her cihazın kaydı ayrıdır; başka cihazın oturumu buraya gelmez."));
  } else {
    hesapBlok = h("p", { class: "kucuk-not" }, "Bu görünümde hesap bağlantısı yok; profil ve ilerleme bu tarayıcıda saklanır.");
  }
  const kaydet = () => {
    const yeni = !Kayit.v.profil;
    Kayit.v.profil = { ad: ad.value.trim(), avatar: p.avatar, varsta: p.varsta };
    Kayit.v.varsta = p.varsta;
    Kayit.v.hesap = !!(Hesap.me && hesapIste);
    Kayit.kaydet(); profilCiz(); u.hidden = true; Yol.ciz();
    tost([em(p.avatar, 30), yeni ? `Bun venit${Kayit.v.profil.ad ? ", " + Kayit.v.profil.ad : ""}!` : "Profil salvat"]);
    if (yeni) { Ses.efekt("fanfar"); }
  };
  u.replaceChildren(h("div", { class: "kart genis", role: "dialog", "aria-modal": "true", "aria-labelledby": "profil-baslik", style: "padding:26px;display:flex;flex-direction:column;gap:16px" },
    h("div", { class: "satir" }, h("div", { class: "gen" }, h("h2", { id: "profil-baslik", style: "font-size:30px" }, Kayit.v.profil ? "Profilul meu" : "Creează profil"), h("span", { class: "tr" }, "Çocuğun için profil: ad, avatar ve yaş.")), h("img", { src: "img/lumi_success.png", alt: "", width: "72", height: "89" })),
    h("label", { for: "profil-ad", style: "display:grid;gap:6px" }, h("b", null, "Cum te cheamă?"), ad), h("div", { style: "display:grid;gap:6px" }, h("b", null, "Alege un prieten"), av),
    h("div", { style: "display:grid;gap:6px" }, h("b", null, "Câți ani ai?"), yas), hesapBlok,
    h("div", { class: "dugmeler" }, h("button", { class: "btn ana", type: "button", onclick: kaydet }, Kayit.v.profil ? "Salvează" : "Gata, hai să începem!"),
      h("button", { class: "btn acik", type: "button", onclick: () => u.hidden = true }, Kayit.v.profil ? "Închide" : "Mai târziu"))));
  u.hidden = false;
  setTimeout(() => ad.focus(), 50);
}
function steleCiz() { $("#stele").replaceChildren(em("2b50", 28), h("span", null, Kayit.v.stele)); }

// ============================================================ SES
const Ses = {
  ctx: null, dizin: {}, paketler: [], _p: {}, _t: {}, _e: {}, kaynak: null, _bitti: null, _sira: 0, dongu: { ad: null, k: null, g: null },
  baglam() {
    if (!this.ctx) { const C = window.AudioContext || window.webkitAudioContext; if (C) this.ctx = new C(); }
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
    return this.ctx;
  },
  paket(i) {
    return this._p[i] || (this._p[i] = getir(`ses/${this.paketler[i]}.mp3`).then(r => { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); }).catch(e => { delete this._p[i]; throw e; }));
  },
  hazirla(ad) { const i = this.paketler.indexOf(ad); if (i >= 0) this.paket(i).catch(() => {}); },
  var(m) { return !!this.dizin[(m || "").trim()]; },
  async tampon(m) {
    const k = this.dizin[m.trim()];
    if (!k) return null;
    return this._t[m] || (this._t[m] = (async () => {
      const b = await this.paket(k[0]);
      return await new Promise((ok, red) => this.baglam().decodeAudioData(b.slice(k[1], k[1] + k[2]), ok, red));
    })().catch(e => { delete this._t[m]; throw e; }));
  },
  sus() {
    if (this.kaynak) { try { this.kaynak.onended = null; this.kaynak.stop(); } catch {} this.kaynak = null; }
    try { speechSynthesis.cancel(); } catch {}
    if (this._bitti) { const f = this._bitti; this._bitti = null; f(); }
  },
  async soyle(metin) {
    if (!metin || !Kayit.v.ses_acik) return;
    const ctx = this.baglam();
    this.sus();
    const sira = ++this._sira;
    let t = null;
    try { if (ctx) t = await this.tampon(metin); } catch (e) { console.warn("ses", e); }
    if (sira !== this._sira) return;
    return new Promise(ok => {
      this._bitti = ok;
      const bit = () => { if (this._bitti === ok) { this._bitti = null; ok(); } };
      if (t) {
        const k = ctx.createBufferSource(), g = ctx.createGain();
        k.buffer = t; g.gain.value = Math.max(Kayit.v.ses, .001);
        k.connect(g).connect(ctx.destination);
        k.onended = () => { if (this.kaynak === k) this.kaynak = null; bit(); };
        this.kaynak = k; k.start();
      } else if ("speechSynthesis" in window) {
        const u = new SpeechSynthesisUtterance(metin); u.lang = "ro-RO"; u.rate = .9; u.pitch = 1.2; u.volume = Kayit.v.ses;
        u.onend = u.onerror = bit; speechSynthesis.speak(u);
      } else bit();
    });
  },
  // Doğal sesler (efekt/*.mp3): hayvanlar bir kez çalar, yağmur/yaprak/rüzgâr sayfa boyunca kısık döngüde.
  dogalTampon(ad) {
    return this._e[ad] || (this._e[ad] = getir(`efekt/${ad}.mp3`).then(r => { if (!r.ok) throw new Error(r.status); return r.arrayBuffer(); })
      .then(b => new Promise((ok, red) => this.baglam().decodeAudioData(b, ok, red))).catch(e => { delete this._e[ad]; throw e; }));
  },
  async dogal(ad, guc = .7) {
    if (!ad || !Kayit.v.ses_acik) return;
    const ctx = this.baglam(); if (!ctx) return;
    try {
      const t = await this.dogalTampon(ad), k = ctx.createBufferSource(), g = ctx.createGain();
      k.buffer = t; g.gain.value = Math.max(Kayit.v.ses, .001) * guc; k.connect(g).connect(ctx.destination); k.start();
    } catch (e) { console.warn("doğal ses", e); }
  },
  async ortamBaslat(ad) {
    if (this.dongu.ad === ad) return;
    this.ortamDur();
    if (!ad || !Kayit.v.ses_acik) return;
    const ctx = this.baglam(); if (!ctx) return;
    this.dongu.ad = ad;
    try {
      const t = await this.dogalTampon(ad);
      if (this.dongu.ad !== ad) return;
      const k = ctx.createBufferSource(), g = ctx.createGain();
      k.buffer = t; k.loop = true;
      g.gain.setValueAtTime(0, ctx.currentTime); g.gain.linearRampToValueAtTime(Math.max(Kayit.v.ses, .001) * .3, ctx.currentTime + 1.2);
      k.connect(g).connect(ctx.destination); k.start();
      this.dongu.k = k; this.dongu.g = g;
    } catch (e) { this.dongu.ad = null; }
  },
  ortamDur() {
    const { k, g } = this.dongu, ctx = this.ctx;
    this.dongu = { ad: null, k: null, g: null };
    if (!k || !ctx) return;
    try { g.gain.cancelScheduledValues(ctx.currentTime); g.gain.setValueAtTime(g.gain.value, ctx.currentTime); g.gain.linearRampToValueAtTime(0, ctx.currentTime + .6); k.stop(ctx.currentTime + .7); } catch {}
  },
  // Yumuşak efektler: baloncuk "pop", sevimli "boing", çan, fanfar.
  efekt(ad) {
    if (!Kayit.v.ses_acik) return;
    const ctx = this.baglam(); if (!ctx) return;
    const t0 = ctx.currentTime + .01, s = Math.max(Kayit.v.ses, .001) * .5;
    const ton = (f1, f2, bas, sure, tip = "sine", guc = .5) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = tip; o.frequency.setValueAtTime(f1, t0 + bas); o.frequency.exponentialRampToValueAtTime(f2, t0 + bas + sure);
      g.gain.setValueAtTime(0, t0 + bas); g.gain.linearRampToValueAtTime(guc * s, t0 + bas + .012); g.gain.exponentialRampToValueAtTime(1e-4, t0 + bas + sure);
      o.connect(g).connect(ctx.destination); o.start(t0 + bas); o.stop(t0 + bas + sure + .02);
    };
    if (ad === "pop") ton(500, 900, 0, .09, "sine", .45);
    else if (ad === "boing") { ton(330, 140, 0, .28, "triangle", .5); ton(165, 120, .05, .25, "sine", .3); }
    else if (ad === "dogru") { ton(784, 784, 0, .25); ton(1046, 1046, .09, .35); ton(1318, 1318, .18, .45, "sine", .35); }
    else if (ad === "fanfar") [523, 659, 784, 1046].forEach((f, i) => ton(f, f, i * .11, .5, "triangle", .4));
    else if (ad === "cevir") ton(700, 1100, 0, .12, "sine", .3);
  },
};
document.addEventListener("pointerdown", () => Ses.baglam(), { once: true, capture: true });
const bravo = () => Ses.soyle(rastgele(V.sozler.bravo));
const tekrarDene = () => Ses.soyle(rastgele(V.sozler.tekrar));

// ============================================================ SAYFALAR
const MENU = [["acasa", "Acasă", "1f3e0"], ["cuvinte", "Cuvinte", "1f5e3"], ["litere", "Litere", "1f524"], ["povesti", "Povești", "1f4da"], ["videoclipuri", "Video", "1f3ac"], ["cantece", "Cântece", "1f3b5"], ["jocuri", "Jocuri", "1f9e9"], ["colorare", "Colorare", "1f3a8"]];
const S = {}; // sayfa çizicileri
// Bağlantıyla açılabilen sayfalar (#ad). Diğerleri parametre ister.
const ACIK = ["tanitim", "kayit", "giris"];
const KOK = ["tanitim", "kayit", "giris", "acasa", "cuvinte", "litere", "povesti", "videoclipuri", "cantece", "jocuri", "colorare", "premii", "parinti", "ayarlar"];
// Ayrı sayfalar: her ana bölüm kendi HTML dosyasındadır (LUMI_SAYFALAR: bölüm → dosya).
// Alt görünümler (bir kategori, bir hikâye, bir oyun…) bulunduğu sayfanın içinde açılır.
const SAYFALAR = window.LUMI_SAYFALAR || null, BU_SAYFA = (SAYFALAR && window.LUMI_SAYFA) || null;
function sayfaAdresi(ad, p) {
  if (!SAYFALAR || !SAYFALAR[ad] || ad === BU_SAYFA) return null;
  return SAYFALAR[ad] + (ad === "kayit" && p && p.kilitli ? "?kilitli=1" : "");
}
const Yol = {
  su: { ad: "acasa", p: {} }, gecmis: [],
  git(ad, p = {}, ekle = true) {
    const adres = sayfaAdresi(ad, p);
    if (adres) { location.href = adres; return; }
    Ses.sus(); Ses.ortamDur();
    if (ekle) this.gecmis.push(this.su);
    this.su = { ad, p };
    this.ciz();
    window.scrollTo(0, 0);
  },
  geri() { const o = this.gecmis.pop(); if (o) { this.su = o; this.ciz(); window.scrollTo(0, 0); } else this.git("acasa", {}, false); },
  ciz() {
    const ana = $("#ana"), s = h("div", { class: "sayfa" });
    // Kayıt olmadan yalnızca tanıtım, kayıt ve giriş açılır; diğer her sayfa kayıt formuna yönlenir.
    if (!ACIK.includes(this.su.ad) && !oturumAcik()) this.su = Kayit.v.ebeveyn ? { ad: "giris", p: {} } : { ad: "kayit", p: { kilitli: true } };
    const adres = sayfaAdresi(this.su.ad, this.su.p);
    if (adres) { location.replace(adres); return; }
    (S[this.su.ad] || S.acasa)(s, this.su.p);
    ana.replaceChildren(s);
    const ust = { kategori: "cuvinte", poveste: "povesti", cantec: "cantece", boyama: "colorare", video: "videoclipuri", memorie: "jocuri", premii: "", parinti: "", tanitim: "", kayit: "", giris: "", ayarlar: "" }[this.su.ad] ?? this.su.ad;
    if (!SAYFALAR && KOK.includes(this.su.ad) && location.hash.slice(1) !== this.su.ad) try { history.replaceState(null, "", "#" + this.su.ad); } catch {}
    $("#ayar-btn").setAttribute("aria-current", this.su.ad === "ayarlar" ? "page" : "false");
    sureKontrol();
    for (const b of $("#menu").children) b.setAttribute("aria-current", b.dataset.ad === ust ? "page" : "false");
  },
};
function menuCiz() {
  $("#menu").replaceChildren(...MENU.map(([ad, y, k]) => { const b = h("button", { type: "button", onclick: () => Yol.git(ad) }, em(k, 26), y); b.dataset.ad = ad; return b; }));
}
const geriBtn = (y = "Înapoi") => h("button", { class: "geri", type: "button", onclick: () => Yol.geri() }, "‹ ", y);
const katRenk = id => (V.kategoriler.find(c => c.id === id) || {}).renk || "#8b6ce6";
function tumKelimeler() { return Object.values(V.kelimeler).flat(); }
function gununKelimesi() { const l = tumKelimeler().filter(k => Ses.var(k.ro) && k.img), g = Math.floor(Date.now() / 864e5); return l[(g * 13) % l.length]; }
const yasSorular = f => V.sorular.filter(q => f(q) && (q.yas || 3) <= Kayit.v.varsta);

S.acasa = s => {
  const k = gununKelimesi();
  s.append(h("section", { class: "kahraman" },
    h("div", { class: "yazi" },
      h("span", { class: "kicker" }, Kayit.v.profil && Kayit.v.profil.ad ? `Bună, ${Kayit.v.profil.ad}!` : "Pentru copii de 3–6 ani"),
      h("h1", null, "Învață română ", h("span", null, "jucându-te!")),
      h("p", { class: "tr" }, "Kelimeler, harfler, hikâyeler, şarkılar ve oyunlarla Rumence. Her şey sesli; Lumi her kelimeyi okur."),
      h("div", { class: "dugmeler" }, h("button", { class: "btn ana", type: "button", onclick: () => Yol.git("cuvinte") }, "Hai să începem!"),
        h("button", { class: "btn acik", type: "button", onclick: () => Yol.git("povesti") }, em("1f4d6", 30), "O poveste"))),
    h("div", { class: "lumi-kutu" }, h("img", { class: "lumi", src: "img/lumi_wave.png", alt: "Lumi, vulpița, face cu mâna", width: "433", height: "640" }),
      h("span", { class: "cikartma", style: "left:-24px;top:16%" }, em("1f436", 48)), h("span", { class: "cikartma", style: "right:-18px;top:44%;animation-delay:-1.5s" }, em("1f34e", 44)),
      h("span", { class: "cikartma", style: "left:-8px;bottom:10%;animation-delay:-2.5s" }, em("2b50", 40)))));
  if (!Kayit.v.profil) s.append(h("section", { class: "kart davet" }, h("img", { src: "img/lumi_success.png", alt: "", width: "144", height: "178" }),
    h("div", { class: "gen" }, h("b", null, "Creează un profil pentru copil"), h("span", { class: "tr" }, "İsteğe bağlı ve ücretsiz: çocuğun profili, PIN korumalı ebeveyn paneli, günlük süre sınırı ve saklanan ilerleme.")),
    h("button", { class: "btn ana", type: "button", onclick: () => Kayit.v.ebeveyn ? profilAc() : Yol.git("kayit") }, Kayit.v.ebeveyn ? "Creează profil" : "Ücretsiz kayıt ol")));
  if (k) s.append(h("section", { class: "kart gunun" }, em(k.img, 96),
    h("div", { class: "gen" }, h("span", { class: "kicker" }, "Cuvântul zilei"), h("b", null, k.ro), h("span", { class: "tr" }, "Türkçesi: " + k.tr)), hoparlor(k.ro, 64)));
  const B = [["cuvinte", "Cuvinte", "Kelimeler", "1f5e3", "#ffe3c2", `${tumKelimeler().length} cuvinte · ${V.kategoriler.length} teme`],
    ["litere", "Litere", "Harfler", "1f524", "#dff0ff", `${V.harfler.length} litere, cu Ă Â Î Ș Ț`], ["povesti", "Povești", "Hikâyeler", "1f4da", "#efe6ff", `${V.hikayeler.length} povești citite de Lumi`],
    ["cantece", "Cântece", "Şarkılar", "1f3b5", "#ffe4ef", `${V.sarkilar.length} cântece cu versuri`], ["jocuri", "Jocuri", "Oyunlar", "1f9e9", "#dcf6e8", "Memorie, numere, logică, forme"],
    ["colorare", "Colorare", "Boyama", "1f3a8", "#fff3c4", `${V.boyama.length} desene de colorat`]];
  if (VIDEOLAR.length) s.append(h("section", { class: "vitrin" }, h("div", { style: "display:grid;gap:12px;align-content:start" }, h("span", { class: "kicker" }, "Nou · Videoclipuri"), h("h2", null, "Desene animate cu Lumi"),
      h("p", null, `${VIDEOLAR.length} video: renkler, sayılar, hayvanlar, alfabe ve çizgi film hikâyeler. Her kelime iki kez söylenir, çocuk tekrar eder.`),
      h("div", null, h("button", { class: "btn sari", type: "button", onclick: () => Yol.git("videoclipuri") }, "▶ Vezi toate"))),
    h("div", { class: "mini" }, VIDEOLAR.filter((_, i) => i % 4 === 0).slice(0, 4).map(x => h("button", { type: "button", "aria-label": x.ro, onclick: () => Film.video(x) }, videoKapak(x))))));
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("h2", { style: "font-size:36px" }, "Ce facem azi?"), h("span", { class: "tr" }, "Bugün ne yapalım?"))),
    h("div", { class: "izgara bolumler" }, B.map(([ad, y, tr, kod, renk, say]) => h("button", { class: "kart bolum dokun", type: "button", style: `background:${renk}`, onclick: () => Yol.git(ad) },
      h("h2", null, y), h("span", { class: "tr" }, tr), h("span", { class: "say" }, say), em(kod, 92)))));
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("h2", { style: "font-size:30px" }, "Teme de cuvinte"), h("span", { class: "tr" }, "Kelime konuları"))),
    h("div", { class: "serit" }, V.kategoriler.filter(c => V.kelimeler[c.id]).map(c => h("button", { type: "button", onclick: () => Yol.git("kategori", { id: c.id }) }, em(c.img, 36), c.ad))));
};

S.cuvinte = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Cuvinte"), h("h1", { class: "sayfa-baslik" }, "Alege o temă"),
    h("p", { class: "tr" }, "Bir konu seç: kelimeleri dinle, sonra oyunla pekiştir."))));
  s.append(h("div", { class: "izgara" }, V.kategoriler.filter(c => V.kelimeler[c.id]).map(c => {
    const n = V.kelimeler[c.id].length, o = Kayit.ogrenilenSay(c.id);
    return h("button", { class: "kart kat-kart dokun", type: "button", style: `background:${acikRenk(c.renk)}`, onclick: () => Yol.git("kategori", { id: c.id }) },
      em(c.img, 64), h("b", null, c.ad), h("span", { class: "tr" }, c.tr), h("span", { class: "ilerleme" }, o ? `⭐ ${Math.min(o, n)} / ${n} învățate` : `${n} cuvinte`));
  })));
};

S.kategori = (s, p) => {
  const c = V.kategoriler.find(x => x.id === p.id), l = V.kelimeler[c.id] || [], qs = V.sorular.filter(q => q.kategori === c.id);
  Ses.hazirla("k_" + c.id);
  const ogr = new Set(Kayit.v.ogrenilen[c.id] || []);
  const kartlar = l.map(k => {
    const b = h("button", { class: "kart kelime dokun", type: "button", style: "position:relative" }, kelimeGorsel(k, 84), h("b", null, k.ro), h("span", { class: "tr" }, k.tr),
      ogr.has(k.id) ? h("span", { class: "ogrendi", title: "Învățat" }, em("2b50", 22)) : null);
    b.addEventListener("click", async () => { b.classList.remove("zipla"); void b.offsetWidth; b.classList.add("zipla"); b.classList.add("calar"); await Ses.soyle(k.ro); b.classList.remove("calar"); });
    return b;
  });
  let caliyor = 0;
  const hepsi = h("button", { class: "btn acik", type: "button" }, "▶ Ascultă toate");
  hepsi.addEventListener("click", async () => {
    const no = ++caliyor;
    hepsi.textContent = "■ Stop"; hepsi.onclick = () => { caliyor++; Ses.sus(); };
    for (let i = 0; i < kartlar.length && no === caliyor && kartlar[i].isConnected; i++) {
      kartlar[i].classList.add("calar"); kartlar[i].scrollIntoView({ block: "nearest", behavior: "smooth" });
      await Ses.soyle(l[i].ro); kartlar[i].classList.remove("calar"); await bekle(350);
    }
    hepsi.onclick = null; hepsi.textContent = "▶ Ascultă toate";
  });
  s.append(geriBtn("Toate temele"), h("section", { class: "bant", style: `background:${acikRenk(c.renk, .7)}` }, em(c.img, 110),
    h("div", { class: "gen" }, h("h1", null, c.ad), h("span", { class: "tr", style: "font-size:19px" }, `${c.tr} · ${l.length} cuvinte`),
      h("div", { class: "dugmeler" }, qs.length ? h("button", { class: "btn ana", type: "button", onclick: () => Joc.quiz(yasSorular(q => q.kategori === c.id), c.ad, c.id) }, em("1f3ae", 30), "Joacă") : null,
        videoBul(c.id) ? h("button", { class: "btn sari", type: "button", onclick: () => Film.video(videoBul(c.id)) }, em("1f3ac", 28), "Video") : null, hepsi))),
    h("p", { class: "tr" }, "Bir karta dokun, Lumi okusun."), h("div", { class: "izgara kelimeler" }, kartlar));
};

S.litere = (s, p) => {
  Ses.hazirla("k_litere");
  const RENK = ["#ff8a3d", "#2f6fdb", "#8b6ce6", "#2fae6c", "#e9575a", "#e8a312", "#0fa3b1"];
  let sec = V.harfler[p.i || 0];
  const detay = h("section", { class: "kart harf-detay" });
  const ciz = () => {
    const r = RENK[V.harfler.indexOf(sec) % RENK.length];
    detay.replaceChildren(h("div", { class: "buyuk", style: `color:${r}` }, sec.mare, h("span", null, sec.mic)),
      h("div", { style: "display:flex;flex-direction:column;gap:10px;align-items:inherit" }, h("div", { class: "satir", style: "flex-wrap:wrap" }, em(sec.img, 90), h("div", null, h("b", null, sec.kelime), h("span", { class: "tr" }, sec.cumle))),
        h("div", { class: "dugmeler" }, h("button", { class: "btn sari kucuk", type: "button", onclick: () => harfOku(sec) }, "▶ Ascultă"),
          videoBul("litere") ? h("button", { class: "btn acik kucuk", type: "button", onclick: () => Film.video(videoBul("litere")) }, em("1f3ac", 24), "Video: alfabetul") : null)));
    for (const b of izgara.children) b.setAttribute("aria-pressed", b._h === sec ? "true" : "false");
  };
  const harfOku = async x => { await Ses.soyle(x.mare); await bekle(200); await Ses.soyle(x.cumle); Kayit.ogren("litere", x.id); };
  const izgara = h("div", { class: "izgara alfabe" }, V.harfler.map((x, i) => {
    const b = h("button", { class: "harf dokun", type: "button", style: `background:${RENK[i % RENK.length]}` }, x.mare, h("small", null, x.mic));
    b._h = x;
    b.addEventListener("click", () => { sec = x; ciz(); harfOku(x); });
    return b;
  }));
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Litere"), h("h1", { class: "sayfa-baslik" }, "Alfabetul român"), h("p", { class: "tr" }, "31 harf. Bir harfe dokun: Lumi harfi ve örnek kelimeyi okur.")),
    h("button", { class: "btn ana", type: "button", onclick: () => Joc.quiz(yasSorular(q => q.kategori === "litere"), "Litere", "litere") }, em("1f3ae", 30), "Joacă cu literele")), detay, izgara);
  ciz();
};

// ============================================================ GEOMETRİK HİKÂYE ÇİZİMLERİ
// Her sahne tek SVG: gökyüzü + zemin. Karakterler ve nesneler zemin çizgisine eşit aralıkla dizilir,
// gökteki öğeler (güneş, bulut, yıldız…) üst sırada. Her şey daire, kare, elips ve üçgenden kurulur.
const Geo = (() => {
  const KOYU = "#3b2f4a", BEYAZ_KENAR = ' stroke="#e3dcef" stroke-width="2"';
  const c = (x, y, r, f, ek = "") => `<circle cx="${x}" cy="${y}" r="${r}" fill="${f}"${ek}/>`;
  const e = (x, y, rx, ry, f, ek = "") => `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${f}"${ek}/>`;
  const r = (x, y, w, hh, rr, f, ek = "") => `<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="${rr}" fill="${f}"${ek}/>`;
  const p = (d, f, ek = "") => `<path d="${d}" fill="${f}"${ek}/>`;
  const cz = (d, s, w = 4) => `<path d="${d}" fill="none" stroke="${s}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
  const halka = (x, y, rr, s, w = 3) => `<circle cx="${x}" cy="${y}" r="${rr}" fill="none" stroke="${s}" stroke-width="${w}"/>`;
  const g = (tr, ic) => `<g transform="${tr}">${ic}</g>`;
  // Oynayan parça: bacak (bs/bd), kol (ks/kd), baş, kuyruk, göz… Her biri CSS ile kendi ekseninde döner.
  const P = (sinif, ic) => `<g class="${sinif}">${ic}</g>`;
  const yaz = (x, y, t, boy, f) => `<text x="${x}" y="${y}" text-anchor="middle" font-family="Baloo 2, Nunito, sans-serif" font-weight="800" font-size="${boy}" fill="${f}">${t}</text>`;
  function yildizD(x, y, R) {
    let d = "";
    for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? R * .46 : R; d += (i ? "L" : "M") + (x + Math.cos(a) * rr).toFixed(1) + " " + (y + Math.sin(a) * rr).toFixed(1); }
    return d + "z";
  }
  const yildiz = (x, y, R, f) => p(yildizD(x, y, R), f);
  const kalpD = (s = 1) => `M0 ${14 * s}C${-22 * s} ${0} ${-24 * s} ${-18 * s} ${-12 * s} ${-22 * s}C${-6 * s} ${-24 * s} 0 ${-18 * s} 0 ${-14 * s}C0 ${-18 * s} ${6 * s} ${-24 * s} ${12 * s} ${-22 * s}C${24 * s} ${-18 * s} ${22 * s} 0 0 ${14 * s}z`;

  // Yüz: gözler, ağız, yanaklar; ruh hâline göre değişir. ay = ağzın yüz merkezine uzaklığı.
  function yuz(x, y, s, mod = "mutlu", gr = KOYU, ay = 10) {
    const dx = 13 * s, gy = y - 4 * s, my = y + ay * s;
    let o = "";
    if (mod === "uyku" || mod === "uykulu") o += cz(`M${x - dx - 5 * s} ${gy} q${5 * s} ${4 * s} ${10 * s} 0 M${x + dx - 5 * s} ${gy} q${5 * s} ${4 * s} ${10 * s} 0`, gr, 2.6 * s);
    else o += P("goz", c(x - dx, gy, 5.5 * s, gr) + c(x + dx, gy, 5.5 * s, gr) + c(x - dx + 2 * s, gy - 2 * s, 1.9 * s, "#fff") + c(x + dx + 2 * s, gy - 2 * s, 1.9 * s, "#fff"));
    if (mod === "uzgun") o += cz(`M${x - 7 * s} ${my + 3 * s} q${7 * s} ${-7 * s} ${14 * s} 0`, gr, 2.6 * s) + e(x - dx - 1 * s, gy + 10 * s, 2.6 * s, 4.2 * s, "#5fb3f0");
    else if (mod === "cok_mutlu") o += p(`M${x - 9 * s} ${my - 2 * s}h${18 * s}a${9 * s} ${9 * s} 0 0 1 ${-18 * s} 0z`, "#7a2e3a") + c(x, my + 4 * s, 3.2 * s, "#ff8fa3");
    else if (mod === "saskin" || mod === "uykulu") o += e(x, my + 1 * s, 4 * s, 5 * s, "#7a2e3a");
    else if (mod === "uyku" || mod === "dusunceli") o += r(x - 5 * s, my, 10 * s, 2.6 * s, 1.3 * s, gr);
    else if (mod === "hasta") o += cz(`M${x - 6 * s} ${my + 2 * s} q${6 * s} ${-4 * s} ${12 * s} 0`, gr, 2.4 * s) + r(x + 6 * s, my - 2 * s, 16 * s, 4 * s, 2 * s, "#e9575a", ` transform="rotate(-18 ${x + 6 * s} ${my})"`);
    else if (mod === "dil") o += cz(`M${x - 8 * s} ${my - 1 * s} q${8 * s} ${8 * s} ${16 * s} 0`, gr, 2.6 * s) + e(x + 3 * s, my + 4 * s, 3.5 * s, 3 * s, "#ff8fa3");
    else o += cz(`M${x - 8 * s} ${my - 1 * s} q${8 * s} ${8 * s} ${16 * s} 0`, gr, 2.6 * s);
    if (mod === "hasta") o += e(x - dx - 5 * s, y + 4 * s, 6 * s, 3.6 * s, "#ff6b6b", ' opacity=".55"') + e(x + dx + 5 * s, y + 4 * s, 6 * s, 3.6 * s, "#ff6b6b", ' opacity=".55"');
    else o += e(x - dx - 5 * s, y + 4 * s, 5 * s, 3.2 * s, "#ff9eb0", ' opacity=".7"') + e(x + dx + 5 * s, y + 4 * s, 5 * s, 3.2 * s, "#ff9eb0", ' opacity=".7"');
    return o;
  }
  // Ayakta duran sevimli gövde: yuvarlak köşeli kare + iki bacak + iki kol.
  const govde = (renk, koyu, karin, ek = "") =>
    P("bs", r(-26, -22, 18, 22, 7, koyu)) + P("bd", r(8, -22, 18, 22, 7, koyu))
    + P("ks", r(-44, -64, 16, 34, 8, renk, ek)) + P("kd", r(28, -64, 16, 34, 8, renk, ek))
    + r(-33, -70, 66, 58, 24, renk, ek) + (karin ? e(0, -40, 20, 18, karin) : "");

  // ---------- karakterler (ayak tabanı y=0)
  const lumi = m =>
    P("kuyruk", e(46, -44, 15, 30, "#f5b324", ' transform="rotate(38 46 -44)"') + e(60, -62, 9, 13, "#fff1cf", ' transform="rotate(38 60 -62)"'))
    + P("bs", r(-24, -24, 18, 24, 8, "#e9a11c") + e(-15, -2, 11, 5, "#fff1cf") + P("giy giy-cizme", r(-27, -22, 24, 22, 6, "#e9575a") + r(-30, -7, 29, 8, 4, "#c84447") + r(-25, -22, 20, 5, 2, "#ff8a8c")))
    + P("bd", r(6, -24, 18, 24, 8, "#e9a11c") + e(15, -2, 11, 5, "#fff1cf") + P("giy giy-cizme", r(3, -22, 24, 22, 6, "#e9575a") + r(1, -7, 29, 8, 4, "#c84447") + r(5, -22, 20, 5, 2, "#ff8a8c")))
    + P("ks", r(-46, -68, 16, 34, 8, "#2f6fdb") + c(-38, -34, 8, "#fff1cf") + P("giy giy-manusi", c(-38, -33, 10, "#ff8a3d") + r(-50, -40, 9, 10, 4, "#ff8a3d") + r(-47, -26, 18, 5, 2, "#ffffff")))
    + P("kd", r(30, -68, 16, 34, 8, "#2f6fdb") + c(38, -34, 8, "#fff1cf") + P("giy giy-manusi", c(38, -33, 10, "#ff8a3d") + r(41, -40, 9, 10, 4, "#ff8a3d") + r(29, -26, 18, 5, 2, "#ffffff")))
    + r(-34, -76, 68, 62, 24, "#2f6fdb") + r(-26, -74, 7, 42, 3, "#ffc94a") + r(19, -74, 7, 42, 3, "#ffc94a") + yildiz(0, -44, 11, "#ffc94a")
    + r(-30, -88, 60, 22, 11, "#2a62c4")
    + P("giy giy-fular", r(-36, -94, 72, 17, 8, "#e9575a") + r(-24, -94, 6, 17, 0, "#ffffff") + r(4, -94, 6, 17, 0, "#ffffff") + r(10, -86, 15, 46, 7, "#e9575a") + r(10, -58, 15, 5, 0, "#ffffff") + r(10, -68, 15, 5, 0, "#ffffff"))
    + P("bas", P("giy giy-gluga", c(0, -112, 49, "#2f6fdb") + r(-49, -112, 98, 26, 13, "#2f6fdb")) + P("kulak-s", p("M-38 -116 L-34 -160 L-8 -138z", "#f5b324") + p("M-32 -122 L-30 -150 L-14 -137z", "#ff9eb0"))
      + P("kulak-d", p("M38 -116 L34 -160 L8 -138z", "#f5b324") + p("M32 -122 L30 -150 L14 -137z", "#ff9eb0"))
      + c(0, -112, 38, "#f5b324") + p("M-10 -150 L0 -162 L6 -148z", "#f5b324")
      + P("giy giy-gluga", p("M-47 -114 Q0 -180 47 -114 Q0 -150 -47 -114z", "#2a62c4") + c(0, -158, 8, "#ffc94a"))
      + e(0, -98, 24, 16, "#fff1cf") + e(0, -104, 5, 3.6, "#7a4a2a") + yuz(0, -110, 1.05, m, "#5a3412"))
    + P("giy giy-umbrela", r(36, -208, 5, 182, 2, "#6b4226") + cz("M38 -28 q0 14 -11 14", "#6b4226", 5)
      + P("semsiye-tepe", p("M-44 -206 a82 66 0 0 1 164 0 q-20.5 -13 -41 0 q-20.5 -13 -41 0 q-20.5 -13 -41 0 q-20.5 -13 -41 0z", "#e9575a")
        + p("M-3 -206 q20.5 -13 41 0 L38 -272z", "#ff8a8c") + p("M79 -206 q20.5 -13 41 0 L38 -272z", "#ff8a8c") + r(35, -284, 7, 14, 3, "#6b4226")));
  const iepure = m =>
    P("kuyruk", c(34, -28, 10, "#ffffff", BEYAZ_KENAR)) + govde("#f1ecf7", "#d9d1e6", "#ffffff", BEYAZ_KENAR)
    + P("bas", P("kulak-s", r(-30, -178, 16, 64, 8, "#f1ecf7", BEYAZ_KENAR) + r(-26, -170, 8, 48, 4, "#ffb3c1")) + P("kulak-d", r(14, -178, 16, 64, 8, "#f1ecf7", BEYAZ_KENAR) + r(18, -170, 8, 48, 4, "#ffb3c1"))
      + c(0, -104, 34, "#f1ecf7", BEYAZ_KENAR) + e(0, -99, 4, 3, "#ff8fa3") + cz("M-4 -96 l-16 -3 M-4 -94 l-16 3 M4 -96 l16 -3 M4 -94 l16 3", "#d9d1e6", 1.5) + yuz(0, -106, .95, m));
  const ayi = (a, k, b) => m =>
    govde(a, k, b) + P("bas", c(-26, -132, 12, a) + c(-26, -132, 6, b) + c(26, -132, 12, a) + c(26, -132, 6, b)
      + c(0, -104, 36, a) + e(0, -93, 16, 12, b) + e(0, -98, 5, 3.5, KOYU) + yuz(0, -106, .95, m, KOYU, 10.5));
  const urs = ayi("#a8754b", "#8a5c38", "#e3c49d");
  const ursulet = m => g("scale(.66)", ayi("#dcaa70", "#bd8a52", "#f6dfbd")(m) + c(0, -74, 7, "#e9575a") + c(-9, -74, 6, "#e9575a") + c(9, -74, 6, "#e9575a"));
  const vaca = m =>
    P("kuyruk", cz("M30 -40 q18 6 14 30", "#5b4a68", 4) + c(44, -10, 5, KOYU))
    + govde("#ffffff", "#5b4a68", null, BEYAZ_KENAR) + e(-14, -46, 9, 7, KOYU) + e(16, -30, 8, 6, KOYU) + r(-10, -26, 20, 10, 5, "#ffb3c1")
    + P("bas", e(-24, -138, 5, 10, "#f3d9b5", ' transform="rotate(-25 -24 -138)"') + e(24, -138, 5, 10, "#f3d9b5", ' transform="rotate(25 24 -138)"')
      + P("kulak-s", e(-38, -112, 13, 6, "#ffffff", BEYAZ_KENAR)) + P("kulak-d", e(38, -112, 13, 6, "#ffffff", BEYAZ_KENAR))
      + c(0, -104, 34, "#ffffff", BEYAZ_KENAR) + e(14, -120, 10, 8, KOYU) + e(0, -82, 22, 13, "#ffb3c1") + c(-7, -84, 2.6, "#c2697a") + c(7, -84, 2.6, "#c2697a")
      + yuz(0, -110, .9, m, KOYU, 34));
  const porc = m =>
    P("kuyruk", cz("M33 -30 q10 -2 8 -10 q-2 -6 -8 -2", "#f28da3", 3)) + govde("#ffb3c1", "#f28da3", "#ffd1dc")
    + P("bas", P("kulak-s", p("M-30 -126 L-18 -142 L-12 -122z", "#f28da3")) + P("kulak-d", p("M30 -126 L18 -142 L12 -122z", "#f28da3"))
    + c(0, -104, 34, "#ffb3c1") + e(0, -94, 13, 9, "#f28da3") + c(-4, -94, 2.4, "#c2697a") + c(4, -94, 2.4, "#c2697a") + yuz(0, -112, .9, m, KOYU, 28));
  const cal = m =>
    P("kuyruk", r(30, -58, 12, 44, 6, "#6b4226", ' transform="rotate(-20 36 -58)"')) + govde("#c68a4e", "#a06a36", "#e3c49d")
    + P("bas", p("M-14 -134 L-8 -152 L-2 -134z", "#c68a4e") + p("M14 -134 L8 -152 L2 -134z", "#c68a4e")
    + r(-10, -150, 20, 30, 10, "#6b4226") + r(18, -132, 12, 50, 6, "#6b4226") + e(0, -104, 28, 38, "#c68a4e") + e(0, -78, 20, 14, "#e3c49d") + c(-7, -78, 2.4, "#8a5c38") + c(7, -78, 2.4, "#8a5c38")
    + yuz(0, -112, .85, m, KOYU, 42));
  const gaina = () =>
    P("bs", cz("M-6 -14 v14 M-12 0 h12", "#ffb300", 3.5)) + P("bd", cz("M8 -14 v14 M2 0 h12", "#ffb300", 3.5))
    + P("kuyruk", p("M-26 -44 L-44 -64 L-40 -36z", "#efe9f5")) + e(0, -34, 30, 26, "#ffffff", BEYAZ_KENAR) + P("ks", e(-8, -32, 14, 10, "#efe9f5"))
    + P("bas", c(14, -64, 18, "#ffffff", BEYAZ_KENAR) + c(8, -84, 6, "#e9575a") + c(17, -86, 6, "#e9575a") + p("M30 -66 L42 -62 L30 -58z", "#ffb300") + e(28, -53, 3, 5, "#e9575a") + P("goz", c(19, -68, 3, KOYU)));
  const broasca = () =>
    e(-30, -4, 14, 6, "#58b056") + e(30, -4, 14, 6, "#58b056") + e(0, -28, 38, 28, "#6cc56a") + e(0, -20, 24, 15, "#b6e6a4")
    + c(-20, -54, 14, "#6cc56a") + c(20, -54, 14, "#6cc56a") + P("goz", c(-20, -56, 8, "#fff") + c(20, -56, 8, "#fff") + c(-19, -56, 4, KOYU) + c(21, -56, 4, KOYU))
    + cz("M-16 -36 q16 12 32 0", "#2f7a33", 3);
  const peste = () =>
    P("kuyruk-su", p("M26 0 L52 -18 L52 18z", "#ff8a3d")) + e(0, 0, 34, 22, "#ff8a3d") + e(4, 0, 5, 19, "#ffc94a") + p("M-2 -20 L12 -32 L14 -18z", "#ff7a2a")
    + c(-16, -4, 5.5, "#fff") + c(-17, -4, 2.8, KOYU);
  const delfin = () =>
    P("kuyruk-su", p("M40 -4 L64 -20 L58 2 L64 20z", "#6fa6dc")) + p("M-6 -16 L8 -38 L16 -14z", "#6fa6dc") + e(0, 0, 48, 20, "#7fb2e5") + e(-6, 7, 36, 10, "#d6e9fb")
    + e(-50, 4, 13, 6, "#7fb2e5") + c(-30, -4, 3, KOYU) + cz("M-58 6 q6 4 12 2", KOYU, 2);
  // Dinozorlar: yavru Dino (1f996) ve uzun boyunlu annesi (1f995).
  const dinoPui = m =>
    P("kuyruk", p("M18 -34 Q56 -34 70 -8 Q46 -16 18 -16z", "#4fbf80"))
    + P("bs", r(-22, -22, 16, 22, 7, "#3aa868") + e(-14, -2, 10, 4, "#2f8f57")) + P("bd", r(6, -22, 16, 22, 7, "#3aa868") + e(14, -2, 10, 4, "#2f8f57"))
    + p("M-16 -62 l6 -11 l6 11z M-2 -65 l6 -12 l6 12z M12 -61 l6 -10 l6 10z", "#ffb347")
    + e(0, -38, 32, 27, "#6cd39a") + e(-3, -32, 19, 17, "#dff7cf")
    + P("ks", e(-27, -44, 7, 11, "#4fbf80", ' transform="rotate(25 -27 -44)"')) + P("kd", e(25, -44, 7, 11, "#4fbf80", ' transform="rotate(-25 25 -44)"'))
    + P("bas", p("M-8 -108 l5 -10 l5 10z M2 -110 l5 -11 l5 11z", "#ffb347") + c(0, -84, 27, "#6cd39a") + e(0, -72, 17, 10, "#dff7cf") + c(-12, -100, 6, "rgba(255,255,255,.25)")
      + yuz(0, -88, .78, m, KOYU, 12));
  const dinoMama = m => g("translate(-26 0)",
    P("kuyruk", p("M80 -96 Q150 -96 176 -24 Q146 -52 80 -58z", "#5aa3d6"))
    + P("bs", r(-14, -54, 26, 54, 11, "#3f86bd") + r(56, -54, 26, 54, 11, "#3f86bd")) + P("bd", r(8, -54, 26, 54, 11, "#4a93c9") + r(78, -54, 26, 54, 11, "#4a93c9"))
    + e(40, -88, 78, 48, "#6bb3e4") + e(34, -66, 54, 22, "#d3ecfb") + c(62, -114, 9, "#4a93c9") + c(84, -98, 7, "#4a93c9") + c(28, -122, 7, "#4a93c9")
    + P("bas", p("M-26 -114 Q-52 -170 -54 -222 L-24 -222 Q-20 -168 4 -124z", "#6bb3e4") + p("M-46 -150 l-10 -4 l9 -6z M-44 -180 l-10 -4 l9 -6z", "#3f86bd")
      + e(-40, -232, 38, 28, "#6bb3e4") + e(-40, -218, 24, 12, "#d3ecfb") + c(-40, -262, 6, "#3f86bd") + c(-54, -256, 5, "#3f86bd")
      + yuz(-40, -236, .82, m, KOYU, 13)));
  // Oamenii: aynı gövde, farklı saç, giysi ve ekler.
  const sacKep = f => p("M-29 -108 a29 29 0 0 1 58 0 q-14 -10 -29 -8 q-15 -2 -29 8z", f);
  const gozluk = () => halka(-10.4, -107, 8, KOYU, 2.5) + halka(10.4, -107, 8, KOYU, 2.5) + cz("M-2.4 -107 h4.8", KOYU, 2.5);
  const insan = o => m => {
    let s = o.tip === "uzun" ? P("bas", r(-32, -124, 64, 70, 26, o.sac)) : "";
    s += P("bs", r(-18, -24, 14, 24, 6, o.alt) + r(-20, -6, 18, 6, 3, KOYU)) + P("bd", r(4, -24, 14, 24, 6, o.alt) + r(2, -6, 18, 6, 3, KOYU))
      + P("ks", r(-40, -74, 14, 38, 7, o.giysi, o.kenar || "") + c(-33, -36, 7, o.ten)) + P("kd", r(26, -74, 14, 38, 7, o.giysi, o.kenar || "") + c(33, -36, 7, o.ten) + (o.el || ""))
      + r(-28, -80, 56, 64, 20, o.giysi, o.kenar || "") + (o.govde || "");
    let b = c(0, -106, 28, o.ten);
    if (o.tip === "kisa" || o.tip === "uzun") b += sacKep(o.sac);
    if (o.tip === "topuz") b += c(0, -140, 12, o.sac) + sacKep(o.sac);
    if (o.tip === "ikiTopuz") b += c(-30, -122, 11, o.sac) + c(30, -122, 11, o.sac) + sacKep(o.sac);
    if (o.tip === "kel") b += c(-27, -108, 8, "#e6e3ee") + c(27, -108, 8, "#e6e3ee");
    s += P("bas", b + yuz(0, -104, .8, m) + (o.ekBas || "")) + (o.ek || "");
    return o.olcek ? g(`scale(${o.olcek})`, s) : s;
  };
  const KISI = {
    femeie: insan({ ten: "#f6d2b0", sac: "#6b4226", tip: "uzun", giysi: "#ff8fb1", alt: "#c2507a" }),
    fata: insan({ ten: "#f6d2b0", sac: "#3b2f4a", tip: "ikiTopuz", giysi: "#ffc94a", alt: "#2f6fdb", olcek: .82 }),
    copil: insan({ ten: "#e8b98f", sac: "#5a3412", tip: "kisa", giysi: "#ff8a3d", alt: "#3b4a6b", olcek: .8 }),
    barbat: insan({ ten: "#e8b98f", sac: "#3b2f4a", tip: "kisa", giysi: "#2f6fdb", alt: "#3b4a6b" }),
    bunic: insan({ ten: "#f6d2b0", sac: "#e6e3ee", tip: "kel", giysi: "#8d6e63", alt: "#5d4037",
      ekBas: e(-7, -94, 8, 4, "#e6e3ee") + e(7, -94, 8, 4, "#e6e3ee") + gozluk(), el: r(38, -40, 5, 40, 2, "#8a5c38") + cz("M40 -40 q0 -10 -10 -10", "#8a5c38", 5) }),
    profesoara: insan({ ten: "#f6d2b0", sac: "#8a5c38", tip: "topuz", giysi: "#8b6ce6", alt: "#5b45a8", ekBas: gozluk(), el: r(28, -48, 22, 28, 3, "#e9575a") + r(31, -46, 3, 24, 1, "#fff") }),
    profesor: insan({ ten: "#e8b98f", sac: "#3b2f4a", tip: "kisa", giysi: "#2fae6c", alt: "#3b4a6b", ekBas: gozluk(), el: r(28, -48, 22, 28, 3, "#2f6fdb") + r(31, -46, 3, 24, 1, "#fff") }),
    doctor: insan({ ten: "#f6d2b0", sac: "#3b2f4a", tip: "kisa", giysi: "#ffffff", alt: "#5fb3f0", kenar: BEYAZ_KENAR,
      govde: r(8, -62, 14, 4, 1, "#e9575a") + r(13, -67, 4, 14, 1, "#e9575a") + cz("M-12 -80 q-4 26 10 30 q12 2 10 -14", "#5b6b84", 3) + c(-2, -48, 4, "#5b6b84") }),
  };

  // ---------- gökyüzü öğeleri (merkez 0,0)
  const gunes = () => {
    let s = "";
    for (let i = 0; i < 8; i++) s += r(-4, -50, 8, 16, 4, "#ffb300", ` transform="rotate(${i * 45})"`);
    return P("isin", c(0, 0, 50, "rgba(0,0,0,0)") + s) + c(0, 0, 30, "#ffc94a") + yuz(0, 2, .7, "mutlu", "#a0620a");
  };
  const bulut = (f = "#ffffff") => c(-22, 6, 20, f) + c(0, -6, 26, f) + c(24, 6, 18, f) + r(-42, 4, 84, 22, 11, f);
  const damla = (x, y, s = 1) => p(`M${x} ${y - 8 * s}q${6 * s} ${8 * s} ${6 * s} ${12 * s}a${6 * s} ${6 * s} 0 0 1 ${-12 * s} 0q0 ${-4 * s} ${6 * s} ${-12 * s}z`, "#5fb3f0");
  const ay = ctx => c(0, 0, 32, "#ffe08a") + c(15, -9, 27, ctx.gok);
  const yaprak = f => e(0, 0, 18, 9, f, ' transform="rotate(-30)"') + cz("M-14 8 L14 -8", "rgba(0,0,0,.2)", 2);
  const GOK = {
    "2600": gunes, "1f305": gunes,
    "1f324": () => g("translate(16 -12) scale(.8)", gunes()) + g("translate(-6 12)", bulut()),
    "2601": () => P("bulut-g", bulut()), "1f327": () => P("bulut-g", bulut("#c4cfdf") + P("damla-d", damla(-22, 44)) + P("damla-d d2", damla(0, 52)) + P("damla-d d3", damla(22, 44))),
    "1f319": ay, "1f315": () => c(0, 0, 32, "#fff3c4") + c(-10, -6, 6, "#f1e2a3") + c(9, 10, 4.5, "#f1e2a3"),
    "2b50": () => P("parla", yildiz(0, 0, 28, "#ffc94a") + c(-6, -6, 3, "#fff6d6")),
    "2744": () => cz("M0 -26V26M-22 -13 22 13M-22 13 22 -13", "#8fc9ff", 5) + c(0, 0, 6, "#cfe8ff"),
    "1f680": () => g("rotate(24)", p("M-30 22 L-16 -2 L-16 30z", "#e9575a") + p("M30 22 L16 -2 L16 30z", "#e9575a") + P("alev", p("M-9 30 L0 56 L9 30z", "#ff8a3d") + p("M-4 30 L0 44 L4 30z", "#ffd95e"))
      + r(-16, -30, 32, 64, 16, "#f4f1f8", BEYAZ_KENAR) + p("M-16 -14 Q0 -60 16 -14z", "#e9575a") + c(0, -2, 9, "#5fb3f0", ' stroke="#ffffff" stroke-width="4"')),
    "1fa90": () => c(0, 0, 26, "#b388ff") + `<ellipse cx="0" cy="0" rx="46" ry="11" fill="none" stroke="#ffc94a" stroke-width="5" transform="rotate(-16)"/>` + c(-8, -8, 5, "#cbb0ff"),
    "2728": () => P("parla", yildiz(-18, 6, 16, "#ffd95e")) + P("parla d2", yildiz(16, -12, 11, "#ffe9a3")) + P("parla d3", yildiz(18, 18, 7, "#ffd95e")),
    "1f3b6": () => c(-16, 18, 9, "#8b6ce6") + c(16, 12, 9, "#8b6ce6") + r(-9, -20, 4, 38, 2, "#8b6ce6") + r(23, -26, 4, 38, 2, "#8b6ce6") + p("M-9 -20 L27 -26 L27 -16 L-9 -10z", "#8b6ce6"),
    "1f49b": () => P("atis", p(kalpD(1.6), "#ffc94a")), "1f493": () => p(kalpD(1.6), "#e9575a") + cz("M-34 -20 l-8 -4 M34 -20 l8 -4", "#e9575a", 3),
    "2753": () => c(0, 0, 28, "#ffffff", BEYAZ_KENAR) + yaz(0, 15, "?", 44, "#8b6ce6"),
    "1f4a4": () => yaz(-14, 10, "Z", 34, "#5f7fdc") + yaz(10, -4, "z", 26, "#7f9be6") + yaz(26, -16, "z", 18, "#9fb5ee"),
    "1fae7": () => halka(-14, 6, 16, "#8fc9ff", 3) + halka(14, -12, 11, "#8fc9ff", 3) + halka(20, 16, 7, "#8fc9ff", 3) + c(-20, 0, 3, "#ffffff"),
    "1f4a7": () => damla(0, 0, 2.4), "1f4a6": () => damla(-16, 0, 1.4) + damla(4, -12, 1.2) + damla(16, 8, 1.4),
    "1f343": () => g("translate(-12 0)", yaprak("#6cc56a")) + g("translate(16 -14) scale(.7)", yaprak("#58b056")),
    "1f342": () => g("translate(-12 0)", yaprak("#ff8a3d")) + g("translate(16 -14) scale(.7)", yaprak("#e8a312")),
    "1f41d": () => P("kanat", e(-6, -16, 10, 13, "rgba(255,255,255,.9)", BEYAZ_KENAR) + e(8, -16, 10, 13, "rgba(255,255,255,.9)", BEYAZ_KENAR))
      + e(0, 0, 22, 15, "#ffc94a") + r(-8, -14, 6, 28, 3, KOYU) + r(4, -14, 6, 28, 3, KOYU) + c(16, -3, 2.6, KOYU) + p("M-22 0 L-30 -3 L-30 3z", KOYU),
    "1f388": () => P("salin", cz("M0 26 q-8 14 0 30", "#9e9ab0", 2) + e(0, -4, 22, 28, "#e9575a") + p("M-5 26 L5 26 L0 20z", "#c84447") + e(-8, -14, 5, 8, "#ff9a9c")),
    "1f389": () => p("M-20 30 L4 -6 L16 12z", "#8b6ce6") + c(10, -24, 5, "#ffc94a") + c(26, -8, 4, "#e9575a") + r(-8, -30, 6, 6, 1, "#2fae6c", ' transform="rotate(20)"') + c(30, -30, 3.5, "#5fb3f0"),
    "1f381": () => r(-28, -24, 56, 46, 6, "#8b6ce6") + r(-4, -24, 8, 46, 2, "#ffc94a") + r(-28, -6, 56, 8, 2, "#ffc94a") + c(-9, -30, 9, "#ffc94a") + c(9, -30, 9, "#ffc94a"),
  };

  // ---------- zemindeki yapılar ve nesneler (taban y=0)
  const agac = (yaprakR = "#4caf6a") => r(-10, -72, 20, 72, 6, "#8a5c38") + P("salin", c(0, -112, 44, yaprakR) + c(-34, -86, 30, "#43a35f") + c(34, -86, 30, "#43a35f") + c(-14, -124, 10, "rgba(255,255,255,.18)") + c(-20, -100, 5, "#e9575a") + c(22, -118, 5, "#e9575a"));
  const ev = (duvar = "#ffd7a8", cati = "#e9575a") => r(-60, -112, 120, 112, 8, duvar) + p("M-74 -106 L0 -168 L74 -106z", cati) + r(-14, -58, 28, 58, 12, "#8a5c38") + c(8, -28, 3, "#ffc94a")
    + r(-48, -90, 24, 24, 4, "#bfe3ff") + r(24, -90, 24, 24, 4, "#bfe3ff") + r(-37, -90, 2, 24, 0, "#fff") + r(35, -90, 2, 24, 0, "#fff");
  const semsiye = f => cz("M0 -84 V-8 q0 10 -10 10", "#6b4226", 4) + p("M-46 -78 a46 40 0 0 1 92 0 q-11.5 -8 -23 0 q-11.5 -8 -23 0 q-11.5 -8 -23 0 q-11.5 -8 -23 0z", f) + p("M-23 -78 q11.5 -8 23 0 L0 -118z", "rgba(255,255,255,.35)");
  const YER = {
    "1f333": [120, () => agac()], "1f33f": [60, () => e(-12, -20, 8, 18, "#6cc56a", ' transform="rotate(-25 -12 -20)"') + e(12, -24, 8, 20, "#58b056", ' transform="rotate(20 12 -24)"') + e(0, -30, 7, 22, "#7bd178")],
    "1f331": [60, () => e(0, 0, 22, 7, "#8a5c38") + r(-2, -34, 4, 34, 2, "#4caf6a") + e(-12, -38, 12, 6, "#6cc56a", ' transform="rotate(-25 -12 -38)"') + e(12, -42, 12, 6, "#6cc56a", ' transform="rotate(25 12 -42)"')],
    "1f33b": [70, () => P("salin", r(-3, -96, 6, 96, 3, "#4caf6a") + e(-14, -40, 14, 6, "#58b056", ' transform="rotate(-25 -14 -40)"') + (() => { let s = ""; for (let i = 0; i < 10; i++) s += e(0, -126, 8, 18, "#ffc94a", ` transform="rotate(${i * 36} 0 -110)"`); return s; })() + c(0, -110, 14, "#8a5c38") + c(-4, -114, 3, "#a87449"))],
    "1f3e0": [160, () => ev()], "1f3e1": [190, () => ev("#c9e7ff", "#8b6ce6") + r(70, -30, 40, 30, 4, "none") + r(66, -34, 6, 34, 2, "#f3d9b5") + r(84, -34, 6, 34, 2, "#f3d9b5") + r(102, -34, 6, 34, 2, "#f3d9b5") + r(62, -26, 50, 5, 2, "#f3d9b5") + c(-82, -18, 18, "#58b056") + c(-70, -26, 14, "#6cc56a")],
    "1f3eb": [190, () => r(-80, -122, 160, 122, 6, "#ffe08a") + p("M-92 -118 L0 -170 L92 -118z", "#e9575a") + c(0, -136, 13, "#ffffff") + cz("M0 -144 V-136 H6", KOYU, 2.5)
      + r(-16, -58, 32, 58, 6, "#8a5c38") + r(-66, -96, 26, 24, 4, "#bfe3ff") + r(-30, -96, 26, 24, 4, "#bfe3ff") + r(4, -96, 26, 24, 4, "#bfe3ff") + r(40, -96, 26, 24, 4, "#bfe3ff")
      + r(-66, -50, 26, 24, 4, "#bfe3ff") + r(40, -50, 26, 24, 4, "#bfe3ff") + r(-2, -208, 3, 40, 1, "#9e9ab0") + p("M1 -208 L26 -200 L1 -192z", "#2f6fdb")],
    "1f3e5": [170, () => r(-70, -130, 140, 130, 8, "#ffffff", BEYAZ_KENAR) + r(-70, -130, 140, 18, 8, "#5fb3f0") + r(-10, -104, 20, 52, 3, "#e9575a") + r(-26, -88, 52, 20, 3, "#e9575a") + r(-16, -46, 32, 46, 6, "#bfe3ff") + r(-56, -96, 22, 22, 4, "#bfe3ff") + r(34, -96, 22, 22, 4, "#bfe3ff")],
    "1f3f0": [130, () => r(-56, -70, 112, 70, 6, "#f1c27d") + r(-60, -104, 30, 104, 4, "#e8b76c") + r(30, -104, 30, 104, 4, "#e8b76c") + r(-60, -112, 9, 10, 2, "#e8b76c") + r(-39, -112, 9, 10, 2, "#e8b76c") + r(30, -112, 9, 10, 2, "#e8b76c") + r(51, -112, 9, 10, 2, "#e8b76c")
      + p("M-14 0 V-30 a14 14 0 0 1 28 0 V0z", "#c8955a") + r(-46, -150, 3, 40, 1, "#9e9ab0") + p("M-43 -150 L-22 -142 L-43 -134z", "#e9575a")],
    "1f6dd": [150, () => r(-56, -110, 8, 110, 3, "#2f6fdb") + r(-30, -110, 8, 110, 3, "#2f6fdb") + r(-56, -84, 34, 6, 2, "#5fb3f0") + r(-56, -56, 34, 6, 2, "#5fb3f0") + r(-56, -28, 34, 6, 2, "#5fb3f0")
      + r(-60, -116, 46, 10, 4, "#ff8a3d") + p("M-22 -110 C20 -100 30 -10 74 -6 L74 4 C20 0 10 -86 -22 -96z", "#ffc94a")],
    "1f3a0": [150, () => r(-60, -18, 120, 18, 6, "#8b6ce6") + r(-4, -130, 8, 112, 3, "#ffc94a") + r(-44, -110, 4, 92, 2, "#e3dcef") + r(40, -110, 4, 92, 2, "#e3dcef")
      + p("M-70 -110 L0 -160 L70 -110z", "#e9575a") + p("M-35 -110 L0 -160 L0 -110z", "#ffffff") + p("M35 -110 L0 -160 L0 -110z", "#ffd1dc") + r(-56, -64, 28, 18, 8, "#ffffff", BEYAZ_KENAR) + r(28, -74, 28, 18, 8, "#ffffff", BEYAZ_KENAR) + c(0, -164, 6, "#ffc94a")],
    "1f3d6": [120, () => semsiye("#ff8a3d") + e(28, -2, 26, 6, "#5fb3f0")], "2614": [110, () => semsiye("#8b6ce6")], "2602": [110, () => semsiye("#e9575a")],
    "26c4": [100, () => c(0, -30, 32, "#ffffff", BEYAZ_KENAR) + c(0, -82, 24, "#ffffff", BEYAZ_KENAR) + r(-20, -110, 40, 8, 3, KOYU) + r(-13, -132, 26, 24, 4, KOYU) + r(-22, -64, 44, 9, 4, "#e9575a")
      + c(-8, -88, 3, KOYU) + c(8, -88, 3, KOYU) + p("M0 -82 L18 -78 L0 -75z", "#ff8a3d") + c(0, -40, 3.5, KOYU) + c(0, -26, 3.5, KOYU) + cz("M-30 -50 l-24 -18 M30 -50 l24 -18", "#8a5c38", 4)],
    "1f6cf": [170, () => r(-80, -70, 12, 70, 4, "#a87449") + r(68, -50, 12, 50, 4, "#a87449") + r(-76, -40, 152, 30, 8, "#c68a4e") + r(-70, -54, 140, 18, 8, "#ffffff", BEYAZ_KENAR) + r(-66, -66, 40, 16, 8, "#ffffff", BEYAZ_KENAR) + r(-20, -58, 92, 22, 10, "#8b6ce6") + c(30, -50, 4, "#ffc94a") + c(50, -44, 4, "#ffc94a")],
    "1f36a": [70, () => c(0, -28, 28, "#d9a066") + c(-10, -36, 4, "#6b4226") + c(8, -40, 3.5, "#6b4226") + c(10, -22, 4, "#6b4226") + c(-8, -18, 3, "#6b4226") + c(1, -30, 3, "#6b4226")],
    "1f955": [60, () => p("M-12 -58 L12 -58 L0 0z", "#ff8a3d") + r(-8, -46, 9, 2.5, 1, "#e06f22") + r(-2, -30, 7, 2.5, 1, "#e06f22") + e(-7, -70, 4, 12, "#4caf6a", ' transform="rotate(-20 -7 -70)"') + e(6, -70, 4, 12, "#4caf6a", ' transform="rotate(20 6 -70)"') + e(0, -74, 4, 13, "#58b056")],
    "26bd": [60, () => c(0, -26, 26, "#ffffff", BEYAZ_KENAR) + p(yildizD(0, -26, 10).replace(/L/g, " L"), KOYU) + c(-17, -38, 4, KOYU) + c(18, -36, 4, KOYU) + c(-14, -10, 4, KOYU) + c(15, -10, 4, KOYU)],
    "1f95b": [50, () => r(-14, -58, 28, 58, 8, "#ffffff", BEYAZ_KENAR) + r(-9, -70, 18, 14, 4, "#5fb3f0") + r(-14, -36, 28, 16, 0, "#bfe3ff") + c(0, -28, 4, "#ffffff")],
    "1f36f": [60, () => r(-22, -46, 44, 46, 12, "#ffb300") + r(-24, -56, 48, 12, 5, "#8a5c38") + p("M-12 -44 q0 12 4 12 q4 0 4 -12z", "#ffd36b") + r(-14, -30, 28, 14, 4, "#fff3c4")],
    "1f382": [90, () => r(-38, -44, 76, 44, 10, "#ffd1dc") + r(-38, -44, 76, 14, 7, "#ffffff") + c(-24, -30, 4, "#e9575a") + c(0, -30, 4, "#e9575a") + c(24, -30, 4, "#e9575a")
      + r(-16, -66, 5, 22, 2, "#5fb3f0") + r(-2.5, -70, 5, 26, 2, "#ffc94a") + r(11, -66, 5, 22, 2, "#8b6ce6") + e(-13.5, -72, 3.5, 6, "#ff8a3d") + e(0, -76, 3.5, 6, "#ff8a3d") + e(13.5, -72, 3.5, 6, "#ff8a3d")],
    "1f370": [70, () => p("M-30 0 L30 0 L30 -36 L-30 -16z", "#ffe08a") + p("M-30 -16 L30 -36 L30 -44 L-30 -22z", "#ffffff") + r(-30, -8, 60, 4, 0, "#ff9eb0") + c(18, -48, 8, "#e9575a")],
    "1f366": [60, () => p("M-15 -36 L15 -36 L0 0z", "#e8b06a") + cz("M-8 -28 L4 -10 M6 -30 L-4 -16", "#c98d4a", 2) + c(0, -44, 16, "#ff9eb0") + c(0, -62, 12, "#fff1cf") + c(2, -76, 4, "#e9575a")],
    "1f353": [50, () => p("M-20 -36 q20 -10 40 0 q-4 26 -20 36 q-16 -10 -20 -36z", "#e9575a") + c(-8, -24, 1.8, "#ffe08a") + c(6, -26, 1.8, "#ffe08a") + c(0, -14, 1.8, "#ffe08a") + p("M-14 -38 L0 -46 L14 -38 L0 -32z", "#4caf6a")],
    "1f34c": [70, () => p("M-30 -40 q10 40 56 30 q-40 -6 -48 -36z", "#ffd95e") + r(-34, -46, 8, 10, 3, "#8a5c38")],
    "1f347": [60, () => [[-12, -18], [0, -18], [12, -18], [-6, -30], [6, -30], [-12, -42], [0, -42], [12, -42], [0, -6]].map(([x, y]) => c(x, y, 8, "#8b6ce6")).join("") + r(-2, -60, 4, 12, 2, "#8a5c38") + e(10, -54, 10, 5, "#4caf6a")],
    "1f34e": [60, () => c(0, -26, 26, "#e9575a") + c(-9, -34, 6, "#ff8a8c") + r(-2, -62, 4, 14, 2, "#8a5c38") + e(10, -58, 10, 5, "#4caf6a", ' transform="rotate(-20 10 -58)"')],
    "1f30b": [170, () => p("M-84 0 L-26 -112 L26 -112 L84 0z", "#9c7b6b") + p("M0 -112 L26 -112 L84 0 L0 0z", "rgba(0,0,0,.1)")
      + p("M-26 -112 L26 -112 L16 -96 L8 -106 L-2 -90 L-10 -104 L-18 -94z", "#ff8a3d") + p("M-10 -104 L-2 -90 L4 -100 L8 -84 L-8 -92z", "#ffc94a")
      + P("fum", c(-6, -132, 14, "#d9d4e3")) + P("fum d2", c(8, -138, 12, "#e6e2ee")) + P("fum d3", c(0, -128, 10, "#cfc9dc"))],
    "1f334": [110, () => P("salin", [0, 1, 2, 3, 4, 5, 6].map(j => r(-11 + j * 2.6, -30 - j * 26, 22, 30, 7, j % 2 ? "#a0703f" : "#8a5c38")).join("")
      + [-160, -125, -90, -55, -20, 15].map((a, j) => e(48, 0, 52, 12, j % 2 ? "#3fae5a" : "#2f9a4c", ` transform="translate(16 -208) rotate(${a})"`)).join("") + c(16, -206, 9, "#6b4226") + c(28, -200, 7, "#6b4226"))],
    "ou-crac": [60, () => P("tremur", e(0, -30, 23, 30, "#fff8ec", BEYAZ_KENAR) + c(-8, -44, 4, "#a5d98a") + c(9, -24, 5, "#a5d98a") + c(-6, -16, 3, "#a5d98a")
      + cz("M-14 -40 L-6 -32 L2 -42 L8 -34 L14 -40", "#8a7a6a", 2.5) + e(-7, -40, 5, 8, "#ffffff"))],
    "ou-crapat": [70, () => p("M-26 -28 L-17 -38 L-8 -26 L1 -38 L10 -26 L19 -38 L26 -28 Q26 0 0 0 Q-26 0 -26 -28z", "#fff8ec", BEYAZ_KENAR) + c(-10, -14, 4, "#a5d98a") + c(10, -10, 3, "#a5d98a")
      + p("M34 -2 Q34 -20 46 -24 L50 -16 L56 -24 Q64 -16 60 -2z", "#fff8ec", BEYAZ_KENAR)],
    "1f95a": [50, () => e(0, -26, 20, 26, "#fff8ec", BEYAZ_KENAR) + e(-6, -34, 5, 8, "#ffffff")],
    "1f392": [70, () => r(-26, -64, 52, 64, 18, "#e9575a") + r(-18, -32, 36, 24, 8, "#ff8a8c") + cz("M-14 -64 q14 -20 28 0", "#c84447", 5) + r(-4, -26, 8, 4, 2, "#ffc94a")],
    "1f58d": [40, () => r(-9, -60, 18, 52, 3, "#8b6ce6") + p("M-9 -60 L0 -78 L9 -60z", "#6b4fc8") + r(-9, -48, 18, 5, 0, "#ffffff") + r(-9, -20, 18, 5, 0, "#ffffff")],
    "1f3a8": [80, () => p("M-36 -24 a36 26 0 1 1 52 22 q-10 -10 -18 0 q-10 10 -34 -22z", "#e3c49d") + c(-18, -34, 6, "#e9575a") + c(-2, -42, 6, "#ffc94a") + c(16, -36, 6, "#2f6fdb") + c(22, -20, 6, "#2fae6c") + r(28, -70, 6, 40, 3, "#8a5c38", ' transform="rotate(30 31 -50)"')],
    "1f372": [80, () => e(0, -32, 36, 9, "#ffb74d") + p("M-36 -32 a36 30 0 0 0 72 0z", "#e9575a") + r(-20, -4, 40, 6, 3, "#c84447") + cz("M-12 -48 q-6 -8 0 -16 M4 -50 q-6 -8 0 -16 M18 -48 q-6 -8 0 -16", "#c4cfdf", 3)],
    "1f375": [60, () => cz("M18 -26 a9 9 0 1 1 0 -2", "#ffffff", 5) + r(-20, -38, 40, 38, 12, "#ffffff", BEYAZ_KENAR) + e(0, -38, 18, 4, "#c98d4a") + cz("M-6 -48 q-6 -8 0 -16 M8 -50 q-6 -8 0 -16", "#c4cfdf", 3)],
    "1f9e9": [70, () => r(-28, -56, 26, 26, 4, "#e9575a") + r(2, -56, 26, 26, 4, "#2f6fdb") + r(-28, -26, 26, 26, 4, "#ffc94a") + r(2, -26, 26, 26, 4, "#2fae6c") + c(0, -43, 6, "#e9575a") + c(-15, -28, 6, "#2f6fdb") + c(15, -28, 6, "#ffc94a")],
    "1f4da": [80, () => r(-34, -18, 68, 18, 3, "#2f6fdb") + r(-30, -36, 62, 18, 3, "#e9575a") + r(-36, -52, 66, 16, 3, "#2fae6c") + r(-28, -12, 4, 6, 1, "#fff") + r(20, -30, 4, 6, 1, "#fff")],
    "1f4e6": [80, () => r(-32, -52, 64, 52, 4, "#d9a066") + r(-32, -52, 64, 10, 2, "#c48a52") + r(-5, -52, 10, 24, 1, "#e9cfa6")],
    "1f56f": [40, () => r(-8, -44, 16, 44, 4, "#ffffff", BEYAZ_KENAR) + r(-1, -50, 2, 6, 1, KOYU) + e(0, -58, 5, 9, "#ffb300") + e(0, -56, 2.5, 5, "#fff3c4")],
    "1f462": [70, () => r(-30, -46, 22, 46, 6, "#e9575a") + r(-30, -12, 30, 12, 6, "#e9575a") + r(4, -46, 22, 46, 6, "#e9575a") + r(4, -12, 30, 12, 6, "#e9575a") + r(-30, -46, 22, 8, 4, "#c84447") + r(4, -46, 22, 8, 4, "#c84447")],
    "1f9e3": [70, () => cz("M-30 -50 q15 -12 30 0 t30 0", "#e9575a", 14) + r(14, -50, 14, 46, 6, "#e9575a") + r(14, -16, 14, 5, 0, "#ffffff") + r(14, -30, 14, 5, 0, "#ffffff")],
    "1f9e4": [80, () => r(-34, -50, 26, 40, 12, "#2f6fdb") + r(-40, -36, 12, 18, 6, "#2f6fdb") + r(-34, -14, 26, 14, 4, "#ffffff") + r(8, -50, 26, 40, 12, "#2f6fdb") + r(28, -36, 12, 18, 6, "#2f6fdb") + r(8, -14, 26, 14, 4, "#ffffff")],
    "1faa8": [70, () => e(0, -18, 32, 20, "#a7a2ba") + e(-8, -26, 10, 5, "#c5c1d4")],
    "26aa": [60, () => c(0, -22, 22, "#ffffff", BEYAZ_KENAR) + c(-7, -29, 5, "#f4f9ff")],
    "1f525": [70, () => r(-30, -12, 60, 10, 5, "#8a5c38", ' transform="rotate(12)"') + r(-30, -12, 60, 10, 5, "#a87449", ' transform="rotate(-12)"') + p("M0 -70 q26 26 18 50 q-6 14 -18 14 q-12 0 -18 -14 q-8 -24 18 -50z", "#ff8a3d") + p("M0 -44 q12 14 8 26 q-3 6 -8 6 q-5 0 -8 -6 q-4 -12 8 -26z", "#ffd95e")],
    "1f50d": [60, () => r(6, -30, 10, 32, 5, "#8a5c38", ' transform="rotate(-40 11 -14)"') + c(-6, -46, 20, "#cfe8ff") + halka(-6, -46, 20, "#5b6b84", 6)],
    "1fa7a": [70, () => cz("M-20 -60 v20 q0 22 20 22 q20 0 20 -22 v-20", "#5b6b84", 5) + c(-20, -62, 5, KOYU) + c(20, -62, 5, KOYU) + cz("M0 -18 v8 q0 10 14 10", "#5b6b84", 5) + c(20, -4, 9, "#c4cfdf") + c(20, -4, 4, "#8a97ad")],
    "35-20e3": [70, () => r(-30, -60, 60, 60, 14, "#2f6fdb") + yaz(0, -14, "5", 50, "#ffffff")],
  };
  // Hediye kutusu zeminde durur.
  YER["1f381"] = [70, () => g("translate(0 -22)", GOK["1f381"]())]; delete GOK["1f381"];
  const MOD = { "1f642": "mutlu", "1f604": "cok_mutlu", "1f606": "cok_mutlu", "1f60a": "mutlu", "1f622": "uzgun", "1f614": "uzgun", "1f634": "uyku", "1f971": "uykulu",
    "1f633": "saskin", "1f60b": "dil", "1f912": "hasta", "1f914": "dusunceli", "1f973": "cok_mutlu", "1f917": "mutlu", "1f91d": "mutlu", "1f44b": "mutlu", "1f4a4": "uyku" };
  // Ruh hâli işaretleri: bazıları göğe bir işaret de ekler (sarılma → kalp, uyku → Zzz).
  const MOD_ISARET = { "1f917": "1f49b", "1f91d": "1f49b", "1f4a4": "1f4a4", "1f634": "1f4a4", "1f973": "1f389", "1f914": "2753" };
  const KAR = { lumi: [110, lumi], "1f996": [96, dinoPui], "1f995": [210, dinoMama], "1f430": [90, iepure], "1f43b": [100, urs], "1f9f8": [70, ursulet], "1f42e": [110, vaca], "1f437": [100, porc], "1f434": [100, cal],
    "1f414": [80, gaina], "1f438": [90, broasca], "1f469": [90, KISI.femeie], "1f467": [80, KISI.fata], "1f9d2": [70, KISI.copil], "1f468": [90, KISI.barbat], "1f474": [100, KISI.bunic],
    "1f469-200d-1f3eb": [90, KISI.profesoara], "1f9d1-200d-1f3eb": [90, KISI.profesor], "1f9d1-200d-2695-fe0f": [90, KISI.doctor] };
  const SU = { "1f420": peste, "1f42c": delfin };
  const ORTAM_KOD = ["1f30a", "1f3de", "1fa9f", "1f308"];

  function ortamBul(k) {
    const var_ = (...l) => l.some(x => k.includes(x));
    if (var_("1f680", "1fa90")) return "uzay";
    if (var_("1f30a", "1f3d6", "1f420", "1f42c", "1f3f0")) return "deniz";
    if (var_("2744", "26c4", "26aa", "1f9e3", "1f9e4")) return "kar";
    if (var_("1f6cf", "1f9f8", "1fa9f", "1f4da", "1f9e9", "1f4e6", "1f382", "1f370", "1f56f", "1f372", "1f375", "1f381")) return "ic";
    if (var_("1f319", "1f315", "1f634", "1f4a4")) return "gece";
    return "acik";
  }
  const NOKTALAR = [[60, 40], [150, 90], [240, 30], [330, 70], [430, 26], [520, 84], [610, 40], [700, 76], [760, 30], [110, 160], [390, 150], [660, 170], [210, 200], [560, 210]];
  function zemin(ortam, renk, pencere) {
    let s = "", gok = renk, taban = 372;
    if (ortam === "uzay" || ortam === "gece") {
      gok = ortam === "uzay" ? "#1f2147" : "#2a3263";
      s += r(0, 0, 800, 450, 0, gok) + NOKTALAR.map(([x, y], i) => c(x, y, i % 3 ? 1.8 : 2.8, "#ffffff", ' opacity=".75"')).join("");
      s += ortam === "uzay" ? r(0, 370, 800, 80, 0, "#a7a2ba") + e(160, 410, 40, 10, "#928da8") + e(560, 400, 56, 12, "#928da8") + e(700, 430, 28, 7, "#928da8")
        : e(200, 440, 340, 90, "#3f6b4f") + e(640, 450, 320, 90, "#365f45") + r(0, 380, 800, 70, 0, "#3f6b4f");
      taban = 382;
    } else if (ortam === "deniz") {
      gok = "#cfeaff";
      s += r(0, 0, 800, 450, 0, gok) + r(0, 286, 800, 90, 0, "#5fb3f0") + cz("M0 300 q25 -10 50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0 t50 0", "rgba(255,255,255,.7)", 4)
        + r(0, 366, 800, 84, 0, "#f6dca0") + e(120, 372, 160, 14, "#f6dca0") + e(600, 370, 200, 12, "#f6dca0");
      taban = 412;
    } else if (ortam === "kar") {
      gok = "#e6f2ff";
      s += r(0, 0, 800, 450, 0, gok) + e(220, 400, 360, 70, "#f4f9ff") + e(650, 410, 300, 70, "#ffffff") + r(0, 380, 800, 70, 0, "#ffffff")
        + NOKTALAR.map(([x, y]) => c(x, y + 20, 3.5, "#ffffff")).join("");
      taban = 392;
    } else if (ortam === "ic") {
      s += r(0, 0, 800, 450, 0, renk) + r(0, 360, 800, 90, 0, "#e8c9a0") + r(0, 352, 800, 10, 0, "#ffffff") + [120, 300, 480, 660].map(x => r(x, 362, 2, 88, 0, "#d9b588")).join("");
      if (pencere) { const ic = pencere === "gece" ? "#2a3263" : "#cfeaff"; gok = ic; s += r(250, 36, 300, 200, 18, "#ffffff") + r(262, 48, 276, 176, 10, ic) + r(398, 48, 4, 176, 0, "#ffffff") + r(262, 134, 276, 4, 0, "#ffffff") + r(240, 232, 320, 12, 6, "#f3d9b5"); }
      else s += r(560, 70, 120, 90, 8, "#ffffff") + r(568, 78, 104, 74, 4, "#ffe9b0") + c(620, 112, 18, "#f5b324") + p("M606 100 L604 82 L614 96z M634 100 L636 82 L626 96z", "#f5b324");
      taban = 390;
    } else {
      s += r(0, 0, 800, 450, 0, renk) + e(180, 420, 330, 90, "#b5e19c") + e(650, 430, 300, 80, "#a5d98a") + r(0, 372, 800, 78, 0, "#9bd67e");
      taban = 380;
    }
    return { s, gok, taban };
  }
  function gokkusagi(taban) {
    return ["#e9575a", "#ff8a3d", "#ffc94a", "#2fae6c", "#2f6fdb", "#8b6ce6"].map((f, i) => `<path d="M${120 + i * 18} ${taban} A${280 - i * 18} ${250 - i * 18} 0 0 1 ${680 - i * 18} ${taban}" fill="none" stroke="${f}" stroke-width="18" opacity=".85"/>`).join("");
  }

  // Kodları sahneye çevirir. kapak: kitap kapağı için dar (4:3) ve Lumi'li.
  // Kodları türlere ayırır: zemindeki karakter/nesneler, gök öğeleri, sudakiler; yüz ifadelerini karakterlere uygular.
  function ayir(kodlar, metin = "", kapak = false) {
    const k = kodlar.slice();
    if (kapak && k[0] === "2614") k.push("1f327");
    const ortam = ortamBul(k);
    const yer = [], gok = [], su = [];
    let son = null, bekleyen = null;
    for (const x of k) {
      if (MOD[x]) {
        if (son) son.mod = MOD[x]; else bekleyen = MOD[x];
        if (MOD_ISARET[x] && GOK[MOD_ISARET[x]] && !gok.some(q => q.k === MOD_ISARET[x])) gok.push({ k: MOD_ISARET[x] });
        continue;
      }
      if (ORTAM_KOD.includes(x)) continue;
      if (KAR[x]) { const o = { k: x, tur: "kar", w: KAR[x][0], f: KAR[x][1], mod: bekleyen || "mutlu" }; bekleyen = null; son = o; yer.push(o); }
      else if (SU[x]) (ortam === "deniz" ? su : gok).push({ k: x, f: SU[x] });
      else if (GOK[x]) gok.push({ k: x });
      else if (YER[x]) yer.push({ k: x, tur: "nesne", w: YER[x][0], f: YER[x][1] });
      else yer.push({ k: x, tur: "nesne", w: 70, f: () => r(-28, -56, 56, 56, 16, "#ffffff", BEYAZ_KENAR) + yildiz(0, -28, 16, "#ffc94a") });
    }
    const lumiVar = yer.some(o => o.k === "lumi");
    if (!lumiVar && (kapak || bekleyen || /Lumi/.test(metin) || !yer.some(o => o.tur === "kar"))) {
      const o = { k: "lumi", tur: "kar", w: KAR.lumi[0], f: lumi, mod: bekleyen || "mutlu" };
      yer.splice(Math.floor(yer.length / 2), 0, o);
    }
    return { k, ortam, yer, gok, su };
  }
  function sahneSvg(kodlar, { renk = "#E8F5E9", metin = "", kapak = false } = {}) {
    const { k, ortam, yer, gok, su } = ayir(kodlar, metin, kapak);
    const ic = ortam === "ic" ? (gok.length || k.includes("1fa9f") ? (k.some(x => ["1f319", "1f315", "2b50", "1f4a4"].includes(x)) ? "gece" : "gun") : null) : null;
    const z = zemin(ortam, renk, ic);
    const [x0, gen] = kapak ? [130, 540] : [40, 720];
    let s = z.s + (k.includes("1f308") ? gokkusagi(z.taban) : "");
    // Göğün sırası: tek öğe sağ üst köşede, birden fazlası eşit aralıkla.
    const gx0 = ic ? 270 : x0, ggen = ic ? 260 : gen, gy = ic ? 136 : 92, gs = Math.min(1, ggen / (gok.length * 100));
    gok.forEach((o, i) => {
      const x = gok.length === 1 && !ic ? x0 + gen * .84 : gx0 + ggen * (i + 1) / (gok.length + 1);
      const f = GOK[o.k] || o.f;
      s += g(`translate(${x.toFixed(1)} ${gy}) scale(${(gs * (kapak ? 1.1 : 1)).toFixed(2)})`, `<g class="gp" style="animation-delay:${(.15 + i * .1).toFixed(2)}s"><g class="suzul" style="animation-delay:${(-i * .7).toFixed(1)}s">${f(z)}</g></g>`);
    });
    su.forEach((o, i) => {
      const x = x0 + gen * (i + 1) / (su.length + 1);
      s += g(`translate(${x.toFixed(1)} 330)`, `<g class="gp" style="animation-delay:${(.2 + i * .1).toFixed(2)}s"><g class="suzul">${o.f()}</g></g>`);
    });
    // Zemin sırası: toplam genişliğe göre ölçek, öğeler eşit boşlukla, hepsi aynı taban çizgisinde.
    for (const o of yer) o.b = o.tur === "nesne" && o.w <= 90 ? 1.55 : 1;
    const top = yer.reduce((a, o) => a + o.w * o.b, 0), olc = Math.min(kapak ? 1.25 : 1.15, (gen - 20 * (yer.length + 1)) / Math.max(1, top));
    const bosluk = (gen - top * olc) / (yer.length + 1);
    let x = x0 + bosluk;
    yer.forEach((o, i) => {
      const cx = x + o.w * o.b * olc / 2;
      x += o.w * o.b * olc + bosluk;
      const golge = e(0, 2, o.w * .38, 7, "rgba(40,30,70,.13)");
      if (o.tur === "kar") {
        // Kenara yakın olan kendi kenarından, ortadakiler en yakın kenardan yürüyerek gelir; uyuyan yerinde durur.
        const yurur = !kapak && o.mod !== "uyku", tur = o.k === "lumi" ? "lumi" : o.k === "1f438" ? "hop" : "x";
        const ses = SES[o.k] ? ` data-ses="${SES[o.k]}"` : "";
        s += `<g transform="translate(${cx.toFixed(1)} ${z.taban}) scale(${(olc * o.b).toFixed(3)})" class="sesli" data-kar="${o.k}"${ses}>`
          + `<g class="kar kar-${tur}${yurur ? " yuru" : ""}" style="--dx:${cx < 400 ? -(cx + 120).toFixed(0) : (920 - cx).toFixed(0)}px;--g:${(.15 + i * .45).toFixed(2)}s">${golge}<g class="nefes">${o.f(o.mod)}</g></g></g>`;
      } else s += g(`translate(${cx.toFixed(1)} ${z.taban}) scale(${(olc * o.b).toFixed(3)})`, golge + `<g class="gp" style="animation-delay:${(i * .12).toFixed(2)}s">${o.f()}</g>`);
    });
    const vb = kapak ? "100 0 600 450" : "0 0 800 450";
    return `<svg class="geo" viewBox="${vb}" preserveAspectRatio="xMidYMid ${kapak ? "slice" : "meet"}" role="img" xmlns="http://www.w3.org/2000/svg">${s}</svg>`;
  }
  // Hayvan sesleri (sayfa açılınca bir kez, dokununca yine) ve ortam sesleri (sayfa boyunca döngü).
  const SES = { "1f42e": "inek", "1f437": "domuz", "1f414": "tavuk", "1f438": "kurbaga", "1f995": "bum" };
  function dogalSes(sf, st) {
    const k = sf.sahne || [], var_ = (...l) => l.some(x => k.includes(x));
    let tek = (k.find(x => SES[x]) && SES[k.find(x => SES[x])]) || null;
    if (tek === "bum" && !/bum/i.test(sf.metin || "")) tek = null;
    const ortam = var_("1f327", "1f4a6", "2614") || (st && st.id === "ploaia" && var_("1f4a7")) ? "yagmur"
      : var_("1f343", "1f342") ? "yaprak" : var_("1f333", "2744", "26c4") ? "ruzgar" : null;
    return { tek, ortam };
  }
  const dugum = html => { const t = document.createElement("template"); t.innerHTML = html; return t.content.firstChild; };
  return {
    sahne: (sf, metin) => dugum(sahneSvg(sf.sahne || [], { renk: sf.zemin || "#E8F5E9", metin: metin || sf.metin || "" })),
    kapak: (kod, renk) => dugum(sahneSvg([kod], { renk, kapak: true })),
    dogalSes,
    ayir,
    ikon(k) {
      const o = ayir([k], "x").yer.find(q => q.k === k);
      const ic = o ? (o.tur === "kar" ? o.f("mutlu") : o.f()) : GOK[k] ? GOK[k]({ gok: "#ffffff" }) : null;
      return ic ? `<g class="kar">${ic}</g>` : null;
    },
    gokCiz: (k, ctx) => GOK[k] ? GOK[k](ctx) : SU[k] ? SU[k]() : "",
    suCiz: k => SU[k] ? SU[k]() : "",
    araclar: { c, e, r, p, cz, g, P, yildiz },
  };
})();

// ============================================================ ÇİZGİ FİLM (Desen animat)
// Hikâye kendi kendine oynar; her sayfa bir sahne. Arka plan katmanlı ve canlı (dağlar, ağaçlar, dönen güneş,
// kayan bulutlar, sallanan çiçekler); karakterler yürüyerek gelir ve hiç durmaz: zıplar, el sallar, dans eder, gezinir.
// Altta karaoke altyazı, üstte isim etiketi, konuşma balonu ve büyük ünlem yazıları.
const Film = (() => {
  const { c, e, r, p, cz, g, yildiz } = Geo.araclar;
  const W = 1280, H = 720, TABAN = 604;
  const rnd = (i, s = 1) => { const x = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return x - Math.floor(x); };
  const RENKLER = ["#ff5fa2", "#ffc94a", "#2fd3a0", "#4fa3ff", "#ff8a3d", "#b388ff"];
  // [gök üst, gök alt, uzak dağ, yakın dağ, zemin, zemin açık]
  const PALET = {
    acik: ["#ff9f73", "#ffd9a6", "#a78be8", "#8a68d8", "#6cc24f", "#8fdc66"],
    yagmur: ["#8ea3c4", "#d4deec", "#9a8ccc", "#7d6bb8", "#63b14c", "#86cc62"],
    gece: ["#1b2154", "#3b3c8a", "#4d3f94", "#3a2f7a", "#2d6648", "#3f8a5c"],
    uzay: ["#110e30", "#2a1e62", "#4a3690", "#3a2a7a", "#a7a2ba", "#c5c1d4"],
    deniz: ["#62bdfb", "#d2f0ff", "#a78be8", "#8a68d8", "#f1cf86", "#f8e2ad"],
    kar: ["#8ec5ff", "#e8f4ff", "#b9aef0", "#9c8fe0", "#eef6ff", "#ffffff"],
  };
  // Metinde adı geçen karakter için isim etiketi.
  const ISIM = [["lumi", /\bLumi\b/, "Lumi", "#f5a623"], ["1f996", /\bDino\b/, "Dino", "#2fae6c"], ["1f995", /mama/i, "Mama lui Dino", "#3f86bd"], ["1f430", /iepura/i, "Iepurașul", "#8b6ce6"], ["1f43b", /urs/i, "Ursulețul", "#a8754b"],
    ["1f9f8", /urs/i, "Ursulețul", "#dcaa70"], ["1f42e", /vac/i, "Vaca", "#5b4a68"], ["1f437", /porc/i, "Porcul", "#f28da3"], ["1f414", /găin/i, "Găina", "#e9575a"],
    ["1f434", /\bcal(ul)?\b/i, "Calul", "#a06a36"], ["1f438", /brosc/i, "Broscuța", "#2fae6c"], ["1f474", /bunic/i, "Bunicul", "#8d6e63"],
    ["1f469-200d-1f3eb", /educatoare|doamna/i, "Educatoarea", "#8b6ce6"], ["1f9d1-200d-1f3eb", /profesor|educator/i, "Profesorul", "#2fae6c"],
    ["1f9d1-200d-2695-fe0f", /doctor/i, "Doctorul", "#2f6fdb"], ["1f469", /mama|mami/i, "Mama", "#ff5fa2"], ["1f468", /tata|tati/i, "Tata", "#2f6fdb"],
    ["1f467", /fetiț|prieten/i, "Prietena", "#ffb300"], ["1f9d2", /copil|prieten/i, "Prietenul", "#ff8a3d"]];

  // ---------- arka plan katmanları
  const bulutSekil = f => c(-40, 8, 30, f) + c(0, -12, 40, f) + c(42, 6, 28, f) + r(-70, 4, 140, 34, 17, f);
  const cam = (x, y, s, f, kar) => g(`translate(${x} ${y}) scale(${s})`, `<g class="f-salin" style="animation-delay:-${(rnd(x) * 3).toFixed(2)}s">`
    + r(-9, -40, 18, 40, 3, "#7a4e2d") + p("M-62 -30 L0 -120 L62 -30z", f) + p("M0 -120 L62 -30 L0 -30z", "rgba(0,0,0,.12)")
    + p("M-50 -82 L0 -164 L50 -82z", f) + p("M0 -164 L50 -82 L0 -82z", "rgba(0,0,0,.12)") + p("M-36 -130 L0 -200 L36 -130z", f) + p("M0 -200 L36 -130 L0 -130z", "rgba(0,0,0,.12)")
    + (kar ? p("M-16 -170 L0 -200 L16 -170z", "#ffffff") + p("M-24 -118 L0 -164 L24 -118z", "rgba(255,255,255,.8)") : "") + "</g>");
  const yuvarlakAgac = (x, y, s, f) => g(`translate(${x} ${y}) scale(${s})`, `<g class="f-salin" style="animation-delay:-${(rnd(x, 3) * 3).toFixed(2)}s">`
    + r(-11, -80, 22, 80, 5, "#7a4e2d") + c(0, -126, 52, f) + c(-40, -96, 36, f) + c(40, -96, 36, f) + p("M0 -178 a52 52 0 0 1 0 104z", "rgba(0,0,0,.1)") + c(-18, -140, 12, "rgba(255,255,255,.2)") + "</g>");
  const palmiye = (x, y, s) => {
    let govde = "";
    for (let j = 0; j < 7; j++) govde += r(-10 + j * 2.4, -28 - j * 26, 20, 28, 6, j % 2 ? "#a0703f" : "#8a5c38");
    let yap = "";
    for (const a of [-160, -125, -90, -55, -20, 15]) yap += e(52, 0, 56, 12, a % 2 ? "#3fae5a" : "#2f9a4c", ` transform="translate(17 -210) rotate(${a})"`);
    return g(`translate(${x} ${y}) scale(${s})`, `<g class="f-salin" style="animation-delay:-${(rnd(x, 5) * 3).toFixed(2)}s">${govde}${yap}${c(17, -210, 10, "#6b4226")}</g>`);
  };
  const cicek = (x, y, i) => {
    const f = RENKLER[i % RENKLER.length];
    return g(`translate(${x.toFixed(0)} ${y.toFixed(0)})`, `<g class="f-salin" style="animation-delay:-${(rnd(i, 7) * 3).toFixed(2)}s">` + r(-1.5, -22, 3, 22, 1, "#3f8f3a")
      + [0, 72, 144, 216, 288].map(a => c(Math.cos(a * Math.PI / 180) * 7, -24 + Math.sin(a * Math.PI / 180) * 7, 6, f)).join("") + c(0, -24, 4.5, "#fff3c4") + "</g>");
  };
  const ot = (x, y, f) => g(`translate(${x.toFixed(0)} ${y.toFixed(0)})`, p("M-10 0 L-6 -20 L-2 0z M-3 0 L1 -26 L5 0z M4 0 L9 -18 L12 0z", f));
  const zeminYol = y => `M0 ${y} Q 200 ${y - 26} 400 ${y - 4} T 800 ${y - 2} T 1280 ${y - 12} V 720 H 0 Z`;

  function arka(ortam, renk, pencere) {
    if (ortam === "ic") return oda(renk, pencere);
    const [g1, g2, d1, d2, z1, z2] = PALET[ortam] || PALET.acik;
    let s = `<defs><linearGradient id="f-gok" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${g1}"/><stop offset="1" stop-color="${g2}"/></linearGradient></defs>`
      + r(-60, -60, W + 120, H + 120, 0, "url(#f-gok)");
    if (ortam === "gece" || ortam === "uzay") {
      for (let i = 0; i < 46; i++) s += `<g class="f-yanson" style="animation-delay:-${(rnd(i, 4) * 3).toFixed(2)}s">${c((rnd(i) * W).toFixed(0), (rnd(i, 2) * 400).toFixed(0), (1.4 + rnd(i, 3) * 2.6).toFixed(1), "#ffffff")}</g>`;
      s += g("translate(1070 140)", c(0, 0, 90, "#fff7d6", ' opacity=".12"') + c(0, 0, 58, "#fff3c4") + c(-18, -14, 11, "#f1e2a3") + c(16, 16, 8, "#f1e2a3") + c(20, -20, 5, "#f1e2a3"));
      if (ortam === "uzay") s += g("translate(230 170)", c(0, 0, 46, "#ff8fb1") + `<ellipse cx="0" cy="0" rx="80" ry="18" fill="none" stroke="#ffd95e" stroke-width="8" transform="rotate(-14)"/>` + c(-14, -14, 9, "#ffb3c8"));
    } else if (ortam !== "yagmur") {
      let isin = "";
      for (let i = 0; i < 14; i++) isin += p("M-16 -96 L0 -158 L16 -96z", "#fff1b8", ` opacity=".75" transform="rotate(${(i * 360 / 14).toFixed(1)})"`);
      s += g("translate(1075 150)", `<g class="f-don">${isin}</g>` + c(0, 0, 112, "#fff4c2", ' opacity=".3"') + c(0, 0, 70, "#ffd95e") + c(0, 0, 54, "#ffe37a")
        + c(-20, -6, 7, "#a0620a") + c(20, -6, 7, "#a0620a") + cz("M-16 18 q16 14 32 0", "#a0620a", 5) + e(-38, 12, 9, 6, "#ffb07a") + e(38, 12, 9, 6, "#ffb07a"));
    }
    const bulutRenk = ortam === "yagmur" ? "#c3cee0" : ortam === "gece" || ortam === "uzay" ? "rgba(255,255,255,.12)" : "#ffffff";
    if (ortam !== "uzay") for (let i = 0; i < 5; i++) {
      const sure = 70 + i * 22;
      s += `<g class="f-bulut" style="animation-duration:${sure}s;animation-delay:-${(rnd(i, 9) * sure).toFixed(1)}s">${g(`translate(0 ${70 + i * 42}) scale(${(.7 + rnd(i, 8) * .7).toFixed(2)})`, bulutSekil(bulutRenk))}</g>`;
    }
    if (ortam === "deniz") {
      s += r(0, 420, W, 170, 0, "#3fa7f0") + r(0, 420, W, 10, 0, "#7fd0ff");
      let d = "M-200 450"; for (let i = 0; i < 18; i++) d += " q40 -18 80 0 t80 0";
      s += `<g class="f-dalga">${p(d + " V 470 H -200z", "#8fd8ff")}</g><g class="f-dalga yavas" style="opacity:.6">${p(d.replace("M-200 450", "M-200 500") + " V 520 H -200z", "#62c0ff")}</g>`;
      s += palmiye(90, 600, 1.15) + palmiye(1190, 610, 1.05);
    } else if (ortam === "uzay") {
      s += e(220, 600, 260, 70, "#8f89a8") + e(980, 610, 300, 60, "#8f89a8");
    } else {
      for (let i = 0; i < 7; i++) { const x = i * 220 - 80, hh = 230 + rnd(i, 11) * 120, w = 340; s += p(`M${x} 560 L${x + w / 2} ${560 - hh} L${x + w} 560z`, d1) + p(`M${x + w / 2} ${560 - hh} L${x + w} 560 L${x + w / 2} 560z`, "rgba(0,0,0,.07)") + (ortam === "kar" ? p(`M${x + w / 2 - 34} ${560 - hh + 54} L${x + w / 2} ${560 - hh} L${x + w / 2 + 34} ${560 - hh + 54} L${x + w / 2 + 12} ${560 - hh + 44} L${x + w / 2} ${560 - hh + 58} L${x + w / 2 - 12} ${560 - hh + 44}z`, "#ffffff") : ""); }
      for (let i = 0; i < 6; i++) { const x = i * 260 - 140 + rnd(i, 12) * 60, hh = 150 + rnd(i, 13) * 80, w = 300; s += p(`M${x} 580 L${x + w / 2} ${580 - hh} L${x + w} 580z`, d2) + p(`M${x + w / 2} ${580 - hh} L${x + w} 580 L${x + w / 2} 580z`, "rgba(0,0,0,.08)"); }
      const yesil = ortam === "gece" ? "#2f7a50" : ortam === "kar" ? "#4f9f74" : "#3fae5a", yesil2 = ortam === "gece" ? "#28694a" : "#2f9a4c";
      for (let i = 0; i < 9; i++) { const x = 40 + i * 150 + rnd(i, 14) * 50, y = 590 + rnd(i, 15) * 10; s += i % 3 === 1 ? yuvarlakAgac(x, y, .8 + rnd(i, 16) * .3, i % 2 ? yesil : yesil2) : cam(x, y, .75 + rnd(i, 17) * .35, i % 2 ? yesil : yesil2, ortam === "kar"); }
    }
    s += p(zeminYol(600), z2) + p(zeminYol(616), z1);
    if (ortam === "acik" || ortam === "yagmur" || ortam === "gece") {
      for (let i = 0; i < 26; i++) { const x = rnd(i, 21) * W, y = 630 + rnd(i, 22) * 80; s += i % 2 ? cicek(x, y, i) : ot(x, y, ortam === "gece" ? "#24573b" : "#4f9f3a"); }
    } else if (ortam === "uzay") for (let i = 0; i < 6; i++) s += e(rnd(i, 23) * W, 650 + rnd(i, 24) * 50, 34 + rnd(i, 25) * 30, 9, "#928da8");
    else if (ortam === "deniz") for (let i = 0; i < 8; i++) s += g(`translate(${(rnd(i, 26) * W).toFixed(0)} ${(650 + rnd(i, 27) * 50).toFixed(0)})`, p("M-10 0 a10 10 0 0 1 20 0z", i % 2 ? "#ff9eb0" : "#ffffff") + r(-10, -1, 20, 3, 1, "rgba(0,0,0,.08)"));
    return s;
  }
  function oda(renk, pencere) {
    let s = r(0, 0, W, H, 0, renk || "#fff3e0");
    for (let i = 0; i < 17; i++) s += r(i * 80, 0, 36, 560, 0, "rgba(255,255,255,.28)");
    const gece = pencere === "gece";
    s += r(470, 64, 340, 260, 22, "#ffffff") + r(484, 78, 312, 232, 12, gece ? "#232a5c" : "#9fdcff");
    if (gece) for (let i = 0; i < 10; i++) s += `<g class="f-yanson" style="animation-delay:-${(rnd(i, 31) * 3).toFixed(2)}s">${c((500 + rnd(i, 32) * 280).toFixed(0), (95 + rnd(i, 33) * 190).toFixed(0), 2.4, "#ffffff")}</g>`;
    else s += `<g class="f-bulut" style="animation-duration:40s">${g("translate(0 150) scale(.5)", bulutSekil("#ffffff"))}</g>`;
    s += r(636, 78, 8, 232, 0, "#ffffff") + r(484, 190, 312, 8, 0, "#ffffff")
      + p("M440 50 h70 q-10 140 20 290 h-90z", "#ff8fb1") + p("M840 50 h-70 q10 140 -20 290 h90z", "#ff8fb1") + r(430, 40, 420, 16, 8, "#c2507a");
    s += r(110, 110, 160, 130, 12, "#ffffff") + r(122, 122, 136, 106, 8, "#ffe9b0") + c(190, 182, 30, "#f5b324") + p("M166 168 L162 136 L182 158z M214 168 L218 136 L198 158z", "#f5b324") + e(190, 190, 16, 11, "#fff1cf") + c(180, 176, 4, KOYU_F) + c(200, 176, 4, KOYU_F);
    s += r(960, 250, 230, 14, 5, "#a87449") + r(978, 196, 22, 54, 3, "#e9575a") + r(1002, 206, 20, 44, 3, "#2f6fdb") + r(1024, 190, 24, 60, 3, "#2fae6c") + r(1050, 214, 18, 36, 3, "#ffc94a") + c(1130, 232, 18, "#ff8a3d");
    s += r(0, 552, W, 16, 0, "#ffffff") + r(0, 566, W, 154, 0, "#e3b98a");
    for (let i = 0; i < 10; i++) s += r(i * 140 + 40, 566, 3, 154, 0, "#d1a575");
    s += e(640, 668, 420, 44, "#ffb3c1", ' opacity=".75"') + e(640, 668, 360, 32, "#ffd1dc", ' opacity=".8"');
    return s;
  }
  const KOYU_F = "#3b2f4a";
  // Önde yağan şeyler: yağmur, kar, yaprak.
  function onKatman(ortam, kodlar) {
    let s = "";
    const var_ = (...l) => l.some(x => kodlar.includes(x));
    if (ortam === "yagmur" || var_("1f327", "1f4a6", "2614")) for (let i = 0; i < 70; i++) s += `<g class="f-yag" style="animation-delay:-${(rnd(i, 41) * 1).toFixed(2)}s;animation-duration:${(.7 + rnd(i, 42) * .4).toFixed(2)}s">${r((rnd(i, 43) * (W + 200) - 100).toFixed(0), (rnd(i, 44) * -200).toFixed(0), 3, 26, 1.5, "rgba(120,170,230,.7)", ' transform="rotate(12)"')}</g>`;
    if (var_("2744") || (ortam === "kar" && var_("26c4", "26aa"))) for (let i = 0; i < 50; i++) s += `<g class="f-kar" style="animation-delay:-${(rnd(i, 45) * 6).toFixed(2)}s;animation-duration:${(5 + rnd(i, 46) * 4).toFixed(1)}s">${c((rnd(i, 47) * W).toFixed(0), -20, (3 + rnd(i, 48) * 4).toFixed(1), "#ffffff")}</g>`;
    if (var_("1f343", "1f342")) for (let i = 0; i < 14; i++) s += `<g class="f-yaprak" style="animation-delay:-${(rnd(i, 49) * 7).toFixed(2)}s;animation-duration:${(6 + rnd(i, 50) * 4).toFixed(1)}s">${e((rnd(i, 51) * W).toFixed(0), -30, 14, 7, var_("1f342") ? (i % 2 ? "#ff8a3d" : "#e8a312") : (i % 2 ? "#6cc56a" : "#4caf6a"))}</g>`;
    return s;
  }

  // ---------- film durumu ve zaman çizelgesi
  let F = null;
  const zamanla = (ms, f) => F.olaylar.push({ t: F.zaman + ms, f, n: F.sahneNo });
  function sinifVer(el, s, ms) { el.classList.remove(s); void el.getBoundingClientRect(); el.classList.add(s); setTimeout(() => el.classList.remove(s), ms); }
  const konum = a => a.el.setAttribute("transform", `translate(${a.x.toFixed(1)} ${a.y}) scale(${(a.s * a.yon).toFixed(3)} ${a.s.toFixed(3)})`);
  const gecici = el => { el.classList.add("f-gecici"); F.ui.append(el); return el; };

  function oynat(st) { baslat({ st, n: st.sayfalar.length, ses: "p_" + st.id, giris, sahne: hikayeSahne, bitis }); }
  function baslat(cfg) {
    Ses.hazirla(cfg.ses);
    const kok = h("div", { class: "film" });
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("class", "geo f-svg"); svg.setAttribute("preserveAspectRatio", "xMidYMid slice");
    const ui = h("div", { class: "f-ui" });
    const perde = h("div", { class: "f-perde" }, RENKLER.slice(0, 5).map(f => h("i", { style: `background:${f}` })));
    const dugme = (ik, et, f) => h("button", { class: "f-btn", type: "button", "aria-label": et, title: et, onclick: ev => { ev.stopPropagation(); f(); } }, ik);
    const oynatB = dugme("❚❚", "Pauză", () => durdur(!F.durdu));
    const ilerleme = h("div", { class: "f-ilerleme" }, h("i"));
    const kontrol = h("div", { class: "f-kontrol" }, dugme("⏮", "Înapoi", () => git(F.i - 1)), oynatB, dugme("⏭", "Înainte", () => git(F.i + 1)), dugme("⛶", "Ecran complet", tamEkran), dugme("✕", "Închide", () => Joc.kapat()));
    const sahne = h("div", { class: "f-sahne" }, svg, ui, ilerleme, kontrol, perde);
    kok.append(sahne);
    sahne.addEventListener("click", ev => {
      const el = ev.target.closest && ev.target.closest("[data-a]");
      if (!el || !F) return;
      const a = F.aktor[+el.dataset.a];
      if (!a) return;
      if (a.ses) Ses.dogal(a.ses, .8); else Ses.efekt("pop");
      sinifVer(a.ic, "a-zipla", 1300);
    });
    Joc.ac([kok]);
    F = { st: cfg.st, n: cfg.n, cfg, sahneEl: sahne, giy: {}, nesne: [], i: -1, zaman: 0, son: performance.now(), olaylar: [], durdu: false, no: Joc.no, sahneNo: 0, aktor: [], karaoke: null, kok, svg, ui, perde, oynatB, ilerleme, isimler: new Set(), kaydedildi: false };
    document.addEventListener("keydown", tus);
    requestAnimationFrame(dongu);
    git(-1);
  }
  function tus(ev) {
    if (!F) return;
    if (ev.key === " ") { ev.preventDefault(); durdur(!F.durdu); }
    else if (ev.key === "ArrowRight") git(F.i + 1);
    else if (ev.key === "ArrowLeft") git(F.i - 1);
  }
  function tamEkran() {
    try { if (!document.fullscreenElement) F.kok.requestFullscreen().catch(() => {}); else document.exitFullscreen().catch(() => {}); } catch {}
  }
  function durdur(d) {
    if (!F) return;
    F.durdu = d;
    F.kok.classList.toggle("durdu", d);
    F.oynatB.textContent = d ? "▶" : "❚❚";
    F.oynatB.setAttribute("aria-label", d ? "Pornește" : "Pauză");
    if (d) { Ses.sus(); Ses.ortamDur(); } else git(F.i);
  }
  function kapanis() { document.removeEventListener("keydown", tus); Ses.ortamDur(); try { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); } catch {} F = null; }
  function dongu(now) {
    if (!F) return;
    if (Joc.no !== F.no || !F.kok.isConnected) { kapanis(); return; }
    const dt = Math.min(60, now - F.son); F.son = now;
    if (!F.durdu) {
      F.zaman += dt;
      const hazir = F.olaylar.filter(o => o.t <= F.zaman);
      F.olaylar = F.olaylar.filter(o => o.t > F.zaman);
      for (const o of hazir) if (F && o.n === F.sahneNo) o.f();
      if (F) { guncelle(dt); karaokeGuncelle(); }
    }
    requestAnimationFrame(dongu);
  }
  function git(i) {
    if (!F) return;
    i = Math.max(-1, Math.min(F.n, i));
    F.sahneNo++; F.olaylar = []; F.durdu = false; F.kok.classList.remove("durdu"); F.oynatB.textContent = "❚❚";
    Ses.sus();
    const n = F.sahneNo;
    F.perde.className = "f-perde kapan";
    setTimeout(() => {
      if (!F || F.sahneNo !== n) return;
      F.i = i; sahneKur(i);
      F.perde.className = "f-perde acil";
    }, 450);
  }

  // ---------- aktörler
  function aktorKur(liste, { y = TABAN, x0 = 110, gen = 1060, enFazla = 1.5, girer = true } = {}) {
    for (const o of liste) o.b = o.tur === "nesne" && o.w <= 90 ? 1.5 : 1;
    const top = liste.reduce((a, o) => a + o.w * o.b, 0), olc = Math.min(enFazla, (gen - 40 * (liste.length + 1)) / Math.max(1, top));
    const bosluk = (gen - top * olc) / (liste.length + 1);
    let x = x0 + bosluk, s = "", j = 0;
    const aktorler = [], nesneler = [];
    liste.forEach((o, i) => {
      const cx = x + o.w * o.b * olc / 2;
      x += o.w * o.b * olc + bosluk;
      const golge = e(0, 3, o.w * .38, 8, "rgba(40,30,70,.16)");
      if (o.tur === "kar") {
        const a = { k: o.k, mod: o.mod, ev: cx, hedef: cx, x: girer && o.mod !== "uyku" ? (cx < W / 2 ? -140 - j * 90 : W + 140 + j * 90) : cx, y, s: olc, yon: 1, hiz: 270,
          plan: [], bekle: F.zaman + 150 + j * 420, sonraki: F.zaman + 3200 + Math.random() * 2500, ses: SES_F[o.k] || null, uyku: o.mod === "uyku", uzgun: o.mod === "uzgun" };
        const idx = F.aktor.length + aktorler.length;
        const tur = o.k === "lumi" ? "lumi" : o.k === "1f438" ? "hop" : o.k === "1f414" ? "tavuk" : "x";
        const giy = o.k === "lumi" && F.giy ? Object.keys(F.giy).filter(k => F.giy[k]).map(k => " g-" + k).join("") : "";
        s += `<g data-a="${idx}" class="sesli" transform="translate(${a.x} ${y}) scale(${olc} ${olc})"><g class="kar kar-${tur}${giy}" style="--g:0s">${golge}<g class="nefes">${o.f(o.mod)}</g></g></g>`;
        aktorler.push(a); j++;
      } else {
        nesneler.push({ k: o.k, x: cx, i });
        s += `<g data-n="${i}" transform="translate(${cx.toFixed(1)} ${y}) scale(${(olc * o.b).toFixed(3)})">` + golge + `<g class="f-belir" style="animation-delay:${(.5 + i * .15).toFixed(2)}s"><g class="f-salin">${o.f()}</g></g></g>`;
      }
    });
    return { s, aktorler, nesneler };
  }
  const SES_F = { "1f42e": "inek", "1f437": "domuz", "1f414": "tavuk", "1f438": "kurbaga", "1f995": "bum" };
  function aktorBagla(aktorler) {
    const bas = F.aktor.length;
    aktorler.forEach((a, j) => { a.el = F.svg.querySelector(`[data-a="${bas + j}"]`); a.ic = a.el.firstElementChild; F.aktor.push(a); konum(a); });
  }
  function guncelle(dt) {
    for (const a of F.aktor) {
      if (F.zaman < a.bekle) continue;
      if (Math.abs(a.x - a.hedef) > .5) {
        const yon = Math.sign(a.hedef - a.x), adim = a.hiz * dt / 1000;
        a.x = Math.abs(a.hedef - a.x) <= adim ? a.hedef : a.x + yon * adim;
        a.yon = yon;
        if (!a.yur) { a.yur = true; a.ic.classList.add("yuruyor"); }
        if (a.x === a.hedef) { a.yur = false; a.ic.classList.remove("yuruyor"); a.yon = 1; if (a.plan.length) a.hedef = a.plan.shift(); else if (a.varinca) { const f = a.varinca; a.varinca = null; f(); } }
        konum(a);
      } else if (F.zaman > a.sonraki && !a.uyku && !a.gorev) {
        eylem(a);
        a.sonraki = F.zaman + 2600 + Math.random() * 3000;
      }
    }
  }
  function eylem(a, zorla) {
    const secim = zorla || (a.tercih && Math.random() < .7 ? a.tercih : null) || (a.uzgun ? "bak" : a.k === "1f438" ? rastgele(["zipla", "gez"]) : a.k === "lumi" ? rastgele(["salla", "zipla", "gez", "dans", "bak", "salla"]) : rastgele(["zipla", "gez", "bak", "dans", "salla"]));
    if (secim === "gez") {
      const d = (Math.random() < .5 ? -1 : 1) * (70 + Math.random() * 70);
      a.hedef = Math.max(90, Math.min(W - 90, a.ev + d)); a.plan = [a.ev]; a.hiz = 170;
    } else sinifVer(a.ic, "a-" + secim, secim === "dans" ? 2100 : 1700);
    if (secim === "zipla" && a.k === "lumi" && F.balto) sinifVer(F.balto, "sicra", 1400);
  }
  // Lumi eşyaya yürür, eğilir, alır ve giyer. Kapüşonu iki eliyle başına çeker; şemsiyeyi alıp açar.
  function yuru(a, x, cb) {
    a.hedef = Math.max(80, Math.min(W - 80, x)); a.plan = []; a.hiz = 240; a.varinca = cb || null;
    if (Math.abs(a.hedef - a.x) <= .5 && cb) { a.varinca = null; zamanla(60, cb); }
  }
  function giyin(a, adimlar) {
    a.gorev = true;
    const sonraki = () => {
      if (!F) return;
      const ad = adimlar.shift();
      if (!ad) {
        a.gorev = false; yuru(a, a.ev, () => eylem(a, "zipla"));
        F.gorevVar = false;
        if (F.gorevSonra) { const f = F.gorevSonra; F.gorevSonra = null; zamanla(1600, f); }
        return;
      }
      const n = ad.k && F.nesne.find(q => q.k === ad.k && !q.alindi);
      const giy = () => {
        if (n && n.el) { n.alindi = true; const ic = n.el.querySelector(".f-belir"); if (ic) ic.classList.add("f-alindi"); const gl = n.el.querySelector("ellipse"); if (gl) gl.style.opacity = 0; }
        F.giy[ad.tur] = true; a.ic.classList.add("g-" + ad.tur); Ses.efekt("pop");
        if (ad.tur === "umbrela") zamanla(650, () => { F.giy["umbrela-acik"] = true; a.ic.classList.add("g-umbrela-acik"); Ses.efekt("cevir"); });
        zamanla(ad.tur === "umbrela" ? 1400 : 900, sonraki);
      };
      if (ad.tur === "gluga") { sinifVer(a.ic, "a-gluga", 1200); zamanla(560, giy); return; }
      if (n) yuru(a, n.x + (ad.tur === "umbrela" ? -46 : 0), () => { sinifVer(a.ic, "a-egil", 900); zamanla(480, giy); });
      else giy();
    };
    sonraki();
  }
  // Güneş çıkınca şemsiye kapanır, kapüşon iner.
  function soyun(a) {
    a.gorev = true;
    a.ic.classList.remove("g-umbrela-acik"); F.giy["umbrela-acik"] = false; Ses.efekt("cevir");
    zamanla(700, () => { a.ic.classList.remove("g-umbrela"); F.giy.umbrela = false; sinifVer(a.ic, "a-gluga", 1200); });
    zamanla(1300, () => { a.ic.classList.remove("g-gluga"); F.giy.gluga = false; a.gorev = false; eylem(a, "zipla"); });
  }
  function kutla() { for (const a of F.aktor) if (!a.uyku && !a.uzgun) setTimeout(() => F && eylem(a, rastgele(["zipla", "dans"])), Math.random() * 400); }

  // ---------- yazılar: isim etiketi, balon, ünlem, karaoke altyazı
  function isimGoster(ad, renk) { const el = gecici(h("div", { class: "f-isim", style: `background:${renk}` }, ad)); setTimeout(() => el.classList.add("git"), 3200); setTimeout(() => el.remove(), 3800); }
  function balon(metin, a) {
    if (!a) return;
    const el = gecici(h("div", { class: "f-balon", style: `left:${(a.ev / W * 100).toFixed(1)}%;top:${((a.y - 178 * a.s) / H * 100).toFixed(1)}%` }, metin));
    setTimeout(() => el.remove(), 4200);
  }
  function unlem(metin, sol) { const el = gecici(h("div", { class: "f-pop" + (sol ? " sol" : "") }, metin)); setTimeout(() => el.classList.add("git"), 2400); setTimeout(() => el.remove(), 2900); }
  function altYazi(metin, sure) {
    const kelimeler = metin.split(/\s+/).filter(Boolean);
    const agirlik = kelimeler.map(k => k.length + 2), toplam = agirlik.reduce((a, b) => a + b, 0);
    let birikim = 0;
    const spanlar = kelimeler.map((k, j) => { const sp = h("span", null, k); sp._t = birikim / toplam * sure * 1000; birikim += agirlik[j]; return [sp, " "]; });
    const el = gecici(h("div", { class: "f-alt" }, spanlar));
    F.karaoke = { el, bas: F.zaman, spanlar: spanlar.map(x => x[0]) };
  }
  function karaokeGuncelle() {
    const k = F.karaoke; if (!k) return;
    const t = F.zaman - k.bas;
    for (const sp of k.spanlar) sp.classList.toggle("on", sp._t <= t);
  }
  async function anlat(metin, sonra, yazili = true) {
    const n = F.sahneNo;
    let sure = 0;
    try { const t = await Ses.tampon(metin); if (t) sure = t.duration; } catch {}
    if (!F || F.sahneNo !== n || F.durdu) return;
    if (!sure) sure = Math.max(2.2, metin.length * .075);
    if (yazili) altYazi(metin, sure);
    Ses.soyle(metin);
    zamanla(sure * 1000 + 250, kutla);
    if (sonra) zamanla(sure * 1000 + 1700, sonra);
  }

  // ---------- sahneler
  function sahneKur(i) {
    F.aktor = []; F.karaoke = null;
    for (const el of F.ui.querySelectorAll(".f-gecici")) el.remove();
    const n = F.n;
    F.ilerleme.firstChild.style.width = `${((i + 1) / (n + 1)) * 100}%`;
    if (i < 0) return F.cfg.giris();
    if (i >= n) return F.cfg.bitis();
    return F.cfg.sahne(i);
  }
  // Önceki sayfalarda giyilenler (ileri sarılsa da Lumi çizmeleriyle gelsin).
  function oncekiGiy(st, i) {
    const g2 = {};
    for (const sf of st.sayfalar.slice(0, i)) {
      const k = sf.sahne || [], m = sf.metin;
      if (/cizm/i.test(m) && k.includes("1f462")) g2.cizme = true;
      if (/fular/i.test(m) && k.includes("1f9e3")) g2.fular = true;
      if (/mănuș|manus/i.test(m) && k.includes("1f9e4")) g2.manusi = true;
      if (/umbrel/i.test(m) && (k.includes("2602") || k.includes("2614"))) g2.gluga = g2.umbrela = g2["umbrela-acik"] = true;
      if (g2.umbrela && k.some(x => ["1f324", "2600", "1f305"].includes(x))) g2.gluga = g2.umbrela = g2["umbrela-acik"] = false;
    }
    return g2;
  }
  function hikayeSahne(i) {
    const st = F.st, sf = st.sayfalar[i], kod = sf.sahne || [];
    F.giy = oncekiGiy(st, i);
    const a = Geo.ayir(kod, sf.metin);
    let ortam = a.ortam;
    // Yağmur hikâye boyunca sürer: yağmur başlayan sayfadan güneş çıkana kadar gök gri ve yağışlı.
    let yagiyor = false;
    for (const q of st.sayfalar.slice(0, i + 1)) {
      const k2 = q.sahne || [];
      if (k2.some(x => ["1f327", "1f4a6", "2614"].includes(x)) || /plou|ploai/i.test(q.metin)) yagiyor = true;
      if (k2.some(x => ["1f324", "2600", "1f305", "1f308"].includes(x))) yagiyor = false;
    }
    if (ortam === "acik" && yagiyor) ortam = "yagmur";
    const pencere = ortam === "ic" ? (kod.some(x => ["1f319", "1f315", "2b50", "1f4a4"].includes(x)) ? "gece" : "gun") : null;
    let s = `<g class="f-kamera">${arka(ortam, sf.zemin, pencere)}</g>`;
    const gokRenk = (PALET[ortam] || PALET.acik)[0];
    const gok = a.gok.filter(o => !(["2600", "1f305"].includes(o.k) && ["acik", "deniz", "kar"].includes(ortam)) && !(["1f319", "1f315"].includes(o.k) && ["gece", "uzay"].includes(ortam)));
    gok.forEach((o, j) => {
      const [x, y, sc] = ortam === "ic" ? [484 + 312 * (j + 1) / (gok.length + 1), 200, .9] : [160 + 760 * (j + 1) / (gok.length + 1), 175 + (j % 2) * 40, 1.45];
      s += g(`translate(${x.toFixed(0)} ${y}) scale(${sc})`, `<g class="f-belir" style="animation-delay:${(.4 + j * .15).toFixed(2)}s"><g class="suzul" style="animation-delay:-${j * .7}s">${Geo.gokCiz(o.k, { gok: ortam === "ic" ? (pencere === "gece" ? "#232a5c" : "#9fdcff") : gokRenk })}</g></g>`);
    });
    a.su.forEach((o, j) => { s += g(`translate(${(200 + 880 * (j + 1) / (a.su.length + 1)).toFixed(0)} 505) scale(1.5)`, `<g class="f-yuz" style="animation-delay:-${j * 1.3}s">${Geo.suCiz(o.k)}</g>`); });
    const { s: as, aktorler, nesneler } = aktorKur(a.yer);
    const lumiYeri = aktorler.find(x => x.k === "lumi");
    if (lumiYeri && kod.includes("1f4a6")) {
      // Su birikintisi: Lumi zıpladıkça su sıçrar.
      const bx = lumiYeri.ev;
      s += e(bx, TABAN + 6, 120, 18, "#5fb3f0", ' opacity=".9"') + e(bx - 30, TABAN + 2, 40, 5, "#bfe3ff", ' opacity=".8"') + e(bx + 200, TABAN + 10, 70, 12, "#5fb3f0", ' opacity=".8"')
        + `<g class="f-sicra">${[-70, -40, -12, 16, 44, 72].map((d, j) => `<g class="damlacik" style="--dx:${d * .9}px">${e(bx + d, TABAN - 4, 6, 9, "#7fc8ff")}</g>`).join("")}</g>`;
    }
    s += as + onKatman(ortam, yagiyor ? kod.concat("1f327") : kod);
    F.svg.innerHTML = s;
    aktorBagla(aktorler);
    F.nesne = nesneler.map(n => Object.assign(n, { el: F.svg.querySelector(`[data-n="${n.i}"]`) }));
    F.balto = kod.includes("1f4a6") ? F.svg.querySelector(".f-sicra") : null;
    F.gorevVar = false; F.gorevSonra = null;
    const lumiA = F.aktor.find(x => x.k === "lumi");
    if (lumiA) {
      if (F.balto) lumiA.tercih = "zipla";
      const varN = k => F.nesne.some(n => n.k === k);
      const adim = [];
      if (/cizm/i.test(sf.metin) && varN("1f462")) adim.push({ tur: "cizme", k: "1f462" });
      if (/fular/i.test(sf.metin) && varN("1f9e3")) adim.push({ tur: "fular", k: "1f9e3" });
      if (/mănuș|manus/i.test(sf.metin) && varN("1f9e4")) adim.push({ tur: "manusi", k: "1f9e4" });
      const sk = ["2602", "2614"].find(varN);
      if (/umbrel/i.test(sf.metin) && sk) { if (!F.giy.gluga) adim.push({ tur: "gluga" }); adim.push({ tur: "umbrela", k: sk }); }
      if (adim.length) { F.gorevVar = true; zamanla(1600, () => giyin(lumiA, adim)); }
      if (F.giy.umbrela && kod.some(x => ["1f324", "2600", "1f305"].includes(x))) zamanla(2600, () => soyun(lumiA));
    }
    // Ses ve yazılar
    const dogal = Geo.dogalSes(sf, st);
    Ses.ortamBaslat(dogal.ortam);
    const isim = ISIM.find(([k, re]) => !F.isimler.has(k) && F.aktor.some(x => x.k === k) && re.test(sf.metin));
    if (isim) { F.isimler.add(isim[0]); zamanla(1100, () => isimGoster(isim[2], isim[3])); }
    const sesli = F.aktor.find(x => x.ses);
    if (dogal.tek) zamanla(1500, () => { Ses.dogal(dogal.tek); if (sesli) sinifVer(sesli.ic, "a-zipla", 1300); });
    const anlatBas = dogal.tek ? 3000 : 1700;
    const alinti = (sf.metin.match(/„([^”"]+)[”"]/) || [])[1];
    const konusan = sesli || F.aktor.find(x => x.k !== "lumi") || F.aktor[0];
    if (alinti) zamanla(anlatBas + 200, () => balon(alinti, konusan));
    const kisa = sf.metin.split(/(?<=[.!?])\s+/).find(c2 => /!$/.test(c2) && c2.split(/\s+/).length <= 3 && !/„/.test(c2));
    // İsim etiketiyle üst üste binmesin: etiket varken ünlem, etiket kaybolunca çıkar.
    if (kisa) zamanla(isim ? Math.max(anlatBas + 500, 5000) : anlatBas + 500, () => unlem(kisa));
    zamanla(anlatBas, () => anlat(sf.metin, () => { if (F.gorevVar) F.gorevSonra = () => git(F.i + 1); else git(F.i + 1); }));
  }
  function morZemin() {
    let s = `<defs><radialGradient id="f-mor" cx=".5" cy=".4" r=".8"><stop offset="0" stop-color="#7b4ee8"/><stop offset="1" stop-color="#2f1880"/></radialGradient></defs>` + r(0, 0, W, H, 0, "url(#f-mor)");
    for (let i = 0; i < 40; i++) s += `<g class="f-yanson" style="animation-delay:-${(rnd(i, 61) * 3).toFixed(2)}s">${c((rnd(i, 62) * W).toFixed(0), (rnd(i, 63) * H).toFixed(0), (1.5 + rnd(i, 64) * 2.5).toFixed(1), "#ffffff")}</g>`;
    return s + p(zeminYol(650), "rgba(255,255,255,.08)");
  }
  const logo = () => g("translate(640 360) scale(.85)", `<g class="f-don yavas">${r(-170, -170, 340, 340, 46, "#ff8a3d")}</g><g class="f-don ters">${p("M0 -150 L150 0 L0 150 L-150 0z", "#4fa3ff")}</g>`
    + p("M-86 64 L0 -96 L86 64z", "#2fd3a0") + r(-34, -10, 68, 68, 12, "#ffd23f"));
  function harfler(metin, sinif) {
    return h("div", { class: sinif }, [...metin].map((ch, j) => h("span", { style: `--i:${j};color:${RENKLER[j % RENKLER.length]}` }, ch === " " ? " " : ch)));
  }
  function hikayeKarakterleri(st) {
    const l = ["lumi"];
    for (const sf of st.sayfalar) for (const o of Geo.ayir(sf.sahne || [], "").yer) if (o.tur === "kar" && !l.includes(o.k)) l.push(o.k);
    return l.slice(0, 5);
  }
  function giris() {
    const st = F.st;
    F.giy = {};
    let s = morZemin() + logo();
    const liste = hikayeKarakterleri(st).slice(0, 3).map(k => Object.assign(Geo.ayir([k === "lumi" ? "1f642" : k], "").yer.find(o => o.k === k) || {}, {}));
    const { s: as, aktorler } = aktorKur(liste.filter(o => o.f), { y: 690, x0: 200, gen: 880, enFazla: 1.15 });
    F.svg.innerHTML = s + as;
    aktorBagla(aktorler);
    gecici(harfler(st.baslik, "f-baslik"));
    zamanla(2200, () => F.aktor.forEach(a => eylem(a, "salla")));
    zamanla(900, () => anlat(st.baslik, null, false));
    zamanla(5200, () => git(0));
  }
  function bitis() {
    const st = F.st;
    let s = morZemin();
    for (let i = 0; i < 60; i++) s += `<g class="f-konfeti" style="animation-delay:-${(rnd(i, 71) * 4).toFixed(2)}s;animation-duration:${(3 + rnd(i, 72) * 3).toFixed(1)}s">${r((rnd(i, 73) * W).toFixed(0), -30, 12, 18, 3, RENKLER[i % RENKLER.length])}</g>`;
    const liste = hikayeKarakterleri(st).map(k => Geo.ayir([k], "").yer.find(o => o.k === k)).filter(Boolean);
    const { s: as, aktorler } = aktorKur(liste, { y: 560, x0: 100, gen: 1080, enFazla: 1.25 });
    F.svg.innerHTML = s + as;
    aktorBagla(aktorler);
    gecici(harfler("Sfârșit!", "f-baslik"));
    if (!F.kaydedildi) { F.kaydedildi = true; Kayit.etkinlik("povesti"); Kayit.ogren("povesti", st.id); Kayit.stea(2); }
    zamanla(2300, () => { Ses.soyle("Bravo!"); kutla(); });
    const dans = () => { kutla(); zamanla(2400, dans); };
    zamanla(3000, dans);
    zamanla(1800, () => gecici(h("div", { class: "f-son" },
      h("button", { class: "btn sari", type: "button", onclick: () => git(-1) }, "▶ Încă o dată"),
      st.sorular && st.sorular.length ? h("button", { class: "btn ana", type: "button", onclick: () => Joc.quiz(st.sorular.map((q, j) => ({ id: st.id + j, tip: "sec", soru: q.soru, secenekler: q.secenekler, dogru: q.dogru })), st.baslik, null, () => Kayit.stea(1)) }, "Întrebări") : null,
      h("button", { class: "btn acik", type: "button", onclick: () => Joc.kapat() }, "Gata"))));
  }
  // ---------- kelime videoları: her kelime bir sahne; Lumi iki kez okur, arada çocuk tekrar eder.
  const VIDEO_ADET = { culori: 11, numere: 10, animale: 14, mancare: 14, saluturi: 10, forme: 9, emotii: 12, transport: 12 };
  function videoOgeleri(x) {
    if (x.kategori === "litere") return V.harfler.map(hf => ({ img: hf.img, harf: `${hf.mare} ${hf.mic}`, ro: hf.kelime, tr: hf.cumle, soz: [hf.mare, hf.cumle] }));
    return (V.kelimeler[x.kategori] || []).slice(0, VIDEO_ADET[x.kategori] || 12).map(k => ({ k, ro: k.ro, tr: k.tr, soz: [k.ro, k.ro] }));
  }
  function video(x) {
    if (x.tur === "poveste") { const st = V.hikayeler.find(q => "h_" + q.id === x.id); if (st) return oynat(st); }
    const kat = V.kategoriler.find(c => c.id === x.kategori) || { id: x.kategori, ad: x.ro, tr: x.tr, renk: "#ff8a3d", img: "1f524" };
    const og = videoOgeleri(x);
    baslat({ n: og.length, ses: "k_" + x.kategori, giris: () => kelimeGiris(x, og), sahne: i => kelimeSahne(og[i], i, kat), bitis: () => kelimeBitis(x) });
  }
  const hayvanBul = img => img ? Geo.ayir([img], "").yer.find(q => q.k === img && q.tur === "kar") : null;
  const lumiOge = () => Geo.ayir(["lumi"], "").yer.find(q => q.k === "lumi");
  function kelimeGiris(x, og) {
    const liste = [lumiOge(), ...og.map(o => hayvanBul(o.k && o.k.img)).filter(Boolean).slice(0, 2)];
    const { s: as, aktorler } = aktorKur(liste, { y: 690, x0: 200, gen: 880, enFazla: 1.15 });
    F.svg.innerHTML = morZemin() + logo() + as;
    aktorBagla(aktorler);
    gecici(harfler(x.ro, "f-baslik"));
    gecici(h("div", { class: "f-altbaslik" }, `${x.tr} · ${og.length} ${x.kategori === "litere" ? "litere" : "cuvinte"}`));
    zamanla(900, () => anlat(x.kategori === "culori" ? "Ce culoare este aceasta?" : x.ro, null, false));
    zamanla(2000, () => F.aktor.forEach(a => eylem(a, "salla")));
    zamanla(5200, () => git(0));
  }
  function kelimeSahne(o, i, kat) {
    const ortam = kat.id === "mancare" ? "ic" : ["acik", "acik", "kar", "acik", "deniz"][i % 5];
    const hayvan = hayvanBul(o.k && o.k.img);
    const liste = [lumiOge()];
    if (hayvan) liste.push(hayvan);
    const { s: as, aktorler } = aktorKur(liste, { x0: 40, gen: hayvan ? 640 : 400, enFazla: 1.45 });
    if (i > 0) aktorler[0].x = aktorler[0].ev;
    F.svg.innerHTML = `<g class="f-kamera">${arka(ortam, acikRenk(kat.renk, .8), "gun")}</g>` + as;
    aktorBagla(aktorler);
    const px = Math.max(80, Math.round(F.sahneEl.clientWidth * .15));
    const resim = o.harf ? h("div", { class: "f-kart-harf" }, o.harf, h("span", { class: "f-kart-em" }, em(o.img, Math.round(px * .5)))) : kelimeGorsel(o.k, px);
    gecici(h("div", { class: "f-kart", style: `--r:${acikRenk(kat.renk, .45)}` }, h("div", { class: "f-kart-ust" }, resim), h("b", null, o.ro), h("small", null, o.tr)));
    gecici(h("div", { class: "f-sayac" }, `${i + 1} / ${F.n}`));
    const lumi = F.aktor[0], ses = hayvan && SES_F[hayvan.k];
    if (ses) zamanla(900, () => Ses.dogal(ses));
    zamanla(ses ? 2600 : 900, () => anlat(o.soz[0], () => {
      unlem("Spune și tu!", true); eylem(lumi, "salla");
      zamanla(1500, () => anlat(o.soz[1] || o.soz[0], () => git(F.i + 1)));
    }));
  }
  function kelimeBitis(x) {
    let s = morZemin();
    for (let i = 0; i < 60; i++) s += `<g class="f-konfeti" style="animation-delay:-${(rnd(i, 71) * 4).toFixed(2)}s;animation-duration:${(3 + rnd(i, 72) * 3).toFixed(1)}s">${r((rnd(i, 73) * W).toFixed(0), -30, 12, 18, 3, RENKLER[i % RENKLER.length])}</g>`;
    const liste = [lumiOge(), ...videoOgeleri(x).map(o => hayvanBul(o.k && o.k.img)).filter(Boolean).slice(0, 4)];
    const { s: as, aktorler } = aktorKur(liste, { y: 560, x0: 100, gen: 1080, enFazla: 1.25 });
    F.svg.innerHTML = s + as;
    aktorBagla(aktorler);
    gecici(harfler("Bravo!", "f-baslik"));
    if (!F.kaydedildi) { F.kaydedildi = true; Kayit.etkinlik("video"); Kayit.ogren("video", x.id); Kayit.stea(1); }
    zamanla(1200, () => { Ses.soyle("Felicitări! Ai terminat!"); kutla(); });
    const dans = () => { kutla(); zamanla(2400, dans); };
    zamanla(3000, dans);
    const kid = x.kategori, qs = yasSorular(q => q.kategori === kid);
    zamanla(1800, () => gecici(h("div", { class: "f-son" },
      h("button", { class: "btn sari", type: "button", onclick: () => git(-1) }, "▶ Încă o dată"),
      qs.length ? h("button", { class: "btn ana", type: "button", onclick: () => Joc.quiz(qs, x.ro, kid) }, "Joacă") : null,
      h("button", { class: "btn acik", type: "button", onclick: () => Joc.kapat() }, "Gata"))));
  }
  return { oynat, video, git: i => git(i) };
})();

S.povesti = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Povești"), h("h1", { class: "sayfa-baslik" }, "Povești cu Lumi"), h("p", { class: "tr" }, "Bir hikâyeye dokun: çizgi film gibi oynar, Lumi okur. Sonunda küçük sorular var."))));
  const okunan = new Set(Kayit.v.ogrenilen.povesti || []);
  s.append(h("div", { class: "izgara hikayeler" }, V.hikayeler.map(st => {
    const z = (st.sayfalar[0] || {}).zemin || "#efe6ff";
    return h("button", { class: "kart kapak dokun", type: "button", "aria-label": st.baslik + " – desen animat", onclick: () => Film.oynat(st) },
      h("div", { class: "resim", style: `background:${z}` }, Geo.kapak(st.kapak_img, z), h("span", { class: "oynat-rozet", "aria-hidden": "true" }, "▶")),
      h("div", { class: "alt" }, h("b", null, st.baslik), h("span", { class: "tr", style: "font-size:14px" }, `${st.sayfalar.length} pagini` + (okunan.has(st.id) ? " · ✓ citită" : ""))));
  })));
};

S.poveste = (s, p) => {
  const st = V.hikayeler.find(x => x.id === p.id);
  Ses.hazirla("p_" + st.id);
  let i = 0, otomatik = true;
  const sahne = h("div", { class: "sahne geo-sahne" }), metin = h("p"), noktalar = h("div", { class: "noktalar" });
  sahne.addEventListener("click", e => {
    const el = e.target.closest && e.target.closest(".sesli");
    if (!el) return;
    if (el.dataset.ses) Ses.dogal(el.dataset.ses, .8); else Ses.efekt("pop");
    el.classList.remove("cal"); void el.getBoundingClientRect(); el.classList.add("cal");
  });
  const ses = hoparlor("", 60);
  const onceki = h("button", { class: "btn acik", type: "button", "aria-label": "Pagina anterioară", onclick: () => git(i - 1) }, "‹");
  const sonraki = h("button", { class: "btn ana", type: "button", onclick: () => git(i + 1) }, "Mai departe ›");
  const oto = h("input", { type: "checkbox", id: "oto-oku", checked: true });
  oto.addEventListener("change", () => otomatik = oto.checked);
  const git = n => {
    if (n < 0) return;
    if (n >= st.sayfalar.length) { Ses.sus(); son(); return; }
    i = n;
    const sf = st.sayfalar[i];
    sahne.style.background = sf.zemin || "#efe6ff";
    sahne.replaceChildren(Geo.sahne(sf));
    metin.textContent = sf.metin;
    ses.replaceWith(ses2(sf.metin));
    noktalar.replaceChildren(...st.sayfalar.map((_, j) => h("i", { class: j === i ? "on" : "" })));
    onceki.disabled = i === 0; onceki.style.visibility = i === 0 ? "hidden" : "";
    sonraki.textContent = i === st.sayfalar.length - 1 ? (st.sorular && st.sorular.length ? "Întrebări ›" : "Gata! ›") : "Mai departe ›";
    Ses.efekt("cevir");
    const dogal = Geo.dogalSes(sf, st);
    Ses.ortamBaslat(dogal.ortam);
    if (dogal.tek) setTimeout(() => { if (sahne.isConnected && i === n) Ses.dogal(dogal.tek); }, 300);
    if (otomatik) setTimeout(() => { if (sahne.isConnected && i === n) Ses.soyle(sf.metin); }, dogal.tek ? 2600 : 350);
  };
  let sesBtn = ses;
  const ses2 = m => { const b = hoparlor(m, 60); sesBtn.replaceWith(b); sesBtn = b; return b; };
  const son = () => {
    const bitir = () => { Kayit.etkinlik("povesti"); Kayit.ogren("povesti", st.id); Kayit.stea(2); };
    if (st.sorular && st.sorular.length) Joc.quiz(st.sorular.map((q, j) => ({ id: st.id + j, tip: "sec", soru: q.soru, secenekler: q.secenekler, dogru: q.dogru })), st.baslik, null, bitir);
    else { bitir(); Joc.kutla("Poveste terminată!", 2); }
  };
  s.append(geriBtn("Toate poveștile"), h("div", { class: "okuyucu" },
    h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Poveste"), h("h1", { style: "font-size:clamp(30px,5vw,44px)" }, st.baslik)),
      h("div", { class: "satir", style: "flex-wrap:wrap" }, h("button", { class: "btn ana kucuk", type: "button", onclick: () => Film.oynat(st) }, "▶ Desen animat"),
        h("label", { class: "satir tr", for: "oto-oku", style: "gap:8px;cursor:pointer" }, oto, "Citește singur"))),
    sahne, h("div", { class: "kart sayfa-metin" }, metin, ses), h("div", { class: "gezinti" }, onceki, noktalar, sonraki)));
  sesBtn = ses;
  git(0);
};

S.cantece = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Cântece"), h("h1", { class: "sayfa-baslik" }, "Cântă cu Lumi"), h("p", { class: "tr" }, "Şarkıyı aç, sözler hece hece yanar. Birlikte söyleyin!"))));
  s.append(h("div", { class: "izgara", style: "--min:300px" }, V.sarkilar.map(x => h("button", { class: "kart sarki-satir dokun", type: "button", onclick: () => Yol.git("cantec", { id: x.id }) },
    h("span", { style: "font-size:54px;line-height:1" }, x.emoji), h("div", { class: "gen" }, h("b", null, x.baslik), h("span", { class: "tr", style: "font-size:14px" }, `${Math.round(x.sure)} secunde · ${x.satirlar.length} versuri`))))));
};

S.cantec = (s, p) => {
  const x = V.sarkilar.find(q => q.id === p.id);
  const audio = h("audio", { src: x.ses, preload: "auto" });
  const oyn = h("button", { class: "oynat", type: "button", "aria-label": "Pornește" });
  const IKON = { play: '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8z"/></svg>', pause: '<svg viewBox="0 0 24 24"><path d="M6 4h4v16H6zm8 0h4v16h-4z"/></svg>' };
  oyn.innerHTML = IKON.play;
  const cubuk = h("i"), sozler = h("div", { class: "sozler" });
  const satirlar = x.zamanlama.map(z => {
    const pp = h("p", null, ...z.heceler.map((hc, j) => { const sp = h("span", null, hc[2]); sp._t = hc[0]; return [sp, j < z.heceler.length - 1 && needsSpace(z.metin, z.heceler, j) ? " " : ""]; }));
    pp._t = z.t; sozler.append(pp); return pp;
  });
  function needsSpace(metin, hc, j) {
    // Hece dizisini metinle hizalayıp kelime sınırını bulur.
    const once = hc.slice(0, j + 1).map(q => q[2]).join("");
    let k = 0, n = 0; for (; k < metin.length && n < once.length; k++) if (metin[k] !== " ") n++;
    return metin[k] === " ";
  }
  let kare = 0;
  const guncelle = () => {
    const t = audio.currentTime;
    cubuk.style.width = (t / (audio.duration || x.sure) * 100) + "%";
    let su = null;
    for (const pp of satirlar) if (pp._t <= t + .05) su = pp;
    for (const pp of satirlar) {
      pp.classList.toggle("su", pp === su);
      for (const sp of pp.querySelectorAll("span")) sp.classList.toggle("on", pp === su && sp._t <= t + .05);
    }
    if (!audio.paused) kare = requestAnimationFrame(guncelle);
  };
  audio.addEventListener("play", () => { oyn.innerHTML = IKON.pause; cancelAnimationFrame(kare); guncelle(); });
  audio.addEventListener("pause", () => { oyn.innerHTML = IKON.play; });
  audio.addEventListener("ended", () => { oyn.innerHTML = IKON.play; Kayit.etkinlik("muzica"); Kayit.stea(1); tost([em("1f3b5", 30), "Bravo! Ai cântat tot cântecul."]); });
  oyn.addEventListener("click", () => { Ses.sus(); if (audio.paused) audio.play().catch(() => {}); else audio.pause(); });
  const bas = Yol.su;
  const izle = setInterval(() => { if (Yol.su !== bas) { audio.pause(); clearInterval(izle); } }, 400);
  s.append(geriBtn("Toate cântecele"), h("section", { class: "kart calar-kutu", style: "max-width:860px;width:100%;margin:0 auto" },
    h("div", { class: "satir", style: "gap:20px" }, oyn, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Cântec"), h("h1", { style: "font-size:clamp(30px,5vw,46px)" }, x.baslik)), h("span", { style: "font-size:64px;line-height:1" }, x.emoji)),
    h("div", { class: "cubuk" }, cubuk), sozler, audio));
};

let VIDEOLAR = [];
const videoBul = kat => VIDEOLAR.find(x => x.kategori === kat);
const sureYaz = sn => `${Math.floor(sn / 60)}:${String(Math.round(sn % 60)).padStart(2, "0")}`;
const OYNAT_SVG = '<svg viewBox="0 0 24 24"><path d="M7 4v16l13-8z"/></svg>';
// Video kapağı: hikâyede geometrik sahne, kelime videosunda konunun rengi ve simgesi.
function videoKapak(x) {
  if (x.tur === "poveste") { const st = V.hikayeler.find(q => "h_" + q.id === x.id); const z = st ? (st.sayfalar[0] || {}).zemin : "#efe6ff"; return h("div", { class: "v-kapak", style: `background:${z}` }, Geo.kapak(x.kapak_img, z)); }
  const c = V.kategoriler.find(q => q.id === x.kategori) || { renk: "#ff8a3d", img: "1f524" };
  return h("div", { class: "v-kapak", style: `background:linear-gradient(135deg, ${acikRenk(c.renk, .35)}, ${acikRenk(c.renk, .75)})` }, em(c.img || "1f524", 96));
}
function videoKarti(x) {
  const ok = h("span", { class: "oynat-k" }); ok.innerHTML = OYNAT_SVG;
  const izlendi = (Kayit.v.ogrenilen.video || []).includes(x.id);
  const say = x.tur === "poveste" ? "desen animat" : x.kategori === "litere" ? `${V.harfler.length} litere` : `${Math.min((V.kelimeler[x.kategori] || []).length, { culori: 11, numere: 10, animale: 14, mancare: 14, saluturi: 10, forme: 9, emotii: 12, transport: 12 }[x.kategori] || 12)} cuvinte`;
  return h("button", { class: "kart vkart dokun", type: "button", onclick: () => Film.video(x) },
    h("div", { class: "kapak-r" }, videoKapak(x), ok, h("span", { class: "sure" }, say), izlendi ? h("span", { class: "izlendi" }, "✓ Văzut") : null),
    h("div", { class: "alt" }, h("b", null, x.ro), h("span", { class: "tr", style: "font-size:14px" }, x.tr)));
}
S.videoclipuri = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Videoclipuri"), h("h1", { class: "sayfa-baslik" }, "Desene animate cu Lumi"),
    h("p", { class: "tr" }, "Lumi'nin çizgi filmleri. Konu videolarında her kelime iki kez söylenir: çocuk dinler, sonra tekrar eder."))));
  const kel = VIDEOLAR.filter(x => x.tur === "cuvinte"), pov = VIDEOLAR.filter(x => x.tur === "poveste");
  s.append(h("h2", { style: "font-size:30px" }, "Cuvinte noi ", h("span", { class: "tr", style: "font-size:18px;font-family:var(--govde)" }, "· Yeni kelimeler")), h("div", { class: "izgara videolar" }, kel.map(videoKarti)));
  s.append(h("h2", { style: "font-size:30px" }, "Povești animate ", h("span", { class: "tr", style: "font-size:18px;font-family:var(--govde)" }, "· Çizgi film hikâyeler")), h("div", { class: "izgara videolar" }, pov.map(videoKarti)));
};
S.video = s => S.videoclipuri(s);

S.jocuri = s => {
  const yas = h("div", { class: "secimler", role: "group", "aria-label": "Vârsta" }, [3, 4, 5, 6].map(n => h("button", { type: "button", "aria-pressed": Kayit.v.varsta === n ? "true" : "false", onclick: () => { Kayit.v.varsta = n; Kayit.kaydet(); Yol.ciz(); } }, `${n} ani`)));
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Jocuri"), h("h1", { class: "sayfa-baslik" }, "Hai să ne jucăm!"), h("p", { class: "tr" }, "Sorular çocuğun yaşına göre seçilir.")),
    h("div", { style: "display:grid;gap:6px" }, h("span", { class: "tr kucuk-not" }, "Vârsta copilului"), yas)));
  const kart = (kod, b, tr, renk, f) => h("button", { class: "kart oyun-kart dokun", type: "button", style: `background:${renk}`, onclick: f }, em(kod, 76), h("div", null, h("b", null, b), h("span", { class: "tr" }, tr)));
  const dinle = () => yasSorular(q => q.tip === "sec" && q.kelime && !q.gorsel && q.secenekler.every(o => o.img && o.ro)).map(q => Object.assign({}, q, { dinle: true }));
  s.append(h("div", { class: "izgara", style: "--min:280px" },
    kart("1f9e0", "Memorie", "Hafıza: eşini bul", "#efe6ff", () => Yol.git("memorie")),
    kart("1f522", "Numere", "Sayma, toplama, çıkarma", "#dff0ff", () => Joc.quiz(yasSorular(q => q.kategori === "matematica"), "Numere", "matematica")),
    kart("1f50e", "Logică", "Farklı olan, örüntü, sıralama", "#fff3c4", () => Joc.quiz(yasSorular(q => q.kategori === "logica"), "Logică", "logica")),
    kart("1f442", "Ascultă și găsește", "Dinle ve doğru resmi bul", "#ffe4ef", () => Joc.quiz(dinle(), "Ascultă și găsește", "asculta")),
    kart("1f537", "Forme", "Şekiller ve gölgeler", "#ffe3c2", () => Joc.quiz(yasSorular(q => q.kategori === "forme"), "Forme", "forme"))));
};

S.memorie = s => {
  const TEMA = { animale: ["Animale", "1f436"], mancare: ["Mâncare", "1f34e"], lumea: ["Lumea", "1f30d"], emotii: ["Emoții", "1f600"], transport: ["Transport", "1f697"] };
  s.append(geriBtn("Jocuri"), h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Memorie"), h("h1", { class: "sayfa-baslik" }, "Găsește perechile!"), h("p", { class: "tr" }, "Kartları çevir, aynı iki resmi bul. Önce konu, sonra kart sayısı."))));
  for (const [t, [ad, kod]] of Object.entries(TEMA)) {
    const l = V.hafiza.filter(m => m.tema === t);
    s.append(h("section", { class: "kart blok" }, h("div", { class: "satir" }, em(kod, 54), h("h2", { class: "gen" }, ad)),
      h("div", { class: "secimler" }, l.map(m => h("button", { type: "button", onclick: () => Joc.hafiza(m) }, `${m.cift * 2} cărți`)))));
  }
};

S.colorare = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Colorare"), h("h1", { class: "sayfa-baslik" }, "Alege un desen"), h("p", { class: "tr" }, "Bir renk seç, resmin bir bölümüne dokun: o bölüm hemen boyanır."))));
  s.append(h("div", { class: "izgara boyama-liste" }, V.boyama.map(b => h("button", { class: "kart boyama-kart dokun", type: "button", onclick: () => Yol.git("boyama", { id: b.id }) },
    h("img", { src: `boyama/${b.kaynak}_cizgi.png`, alt: "", loading: "lazy", width: "150", height: "150" }), b.ad))));
};

S.boyama = (s, p) => {
  const b = V.boyama.find(x => x.id === p.id);
  const RENKLER = ["#e53935", "#fb8c00", "#fdd835", "#43a047", "#1e88e5", "#8e24aa", "#ec407a", "#8d6e63", "#80deea", "#c5e1a5", "#212121", "#ffffff"];
  let renk = RENKLER[0];
  const tuval = h("canvas", { width: "600", height: "600", "aria-label": b.ad });
  const ctx = tuval.getContext("2d", { willReadFrequently: true });
  let bolge = null, cizgi = null, renkler = {}, gecmis = [];
  const cizSahne = () => {
    if (!bolge) return;
    const img = ctx.createImageData(600, 600), d = img.data;
    const onbellek = {};
    for (let i = 0, j = 0; i < bolge.length; i++, j += 4) {
      const r = bolge[i];
      let c = r ? renkler[r] || "#ffffff" : "#ffffff";
      let rgb = onbellek[c]; if (!rgb) { const n = parseInt(c.slice(1), 16); rgb = onbellek[c] = [n >> 16, (n >> 8) & 255, n & 255]; }
      d[j] = rgb[0]; d[j + 1] = rgb[1]; d[j + 2] = rgb[2]; d[j + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    ctx.globalCompositeOperation = "multiply"; ctx.drawImage(cizgi, 0, 0, 600, 600); ctx.globalCompositeOperation = "source-over";
  };
  const yukle = src => new Promise((ok, red) => { const i = new Image(); i.onload = () => ok(i); i.onerror = red; i.src = yol(src); });
  Promise.all([yukle(`boyama/${b.kaynak}_bolge.png`), yukle(`boyama/${b.kaynak}_cizgi.png`)]).then(([bi, ci]) => {
    const c = document.createElement("canvas"); c.width = c.height = 600;
    const x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(bi, 0, 0, 600, 600);
    const d = x.getImageData(0, 0, 600, 600).data;
    bolge = new Uint16Array(600 * 600);
    for (let i = 0, j = 0; i < bolge.length; i++, j += 4) bolge[i] = d[j] + d[j + 1] * 256;
    cizgi = ci; cizSahne();
  });
  tuval.addEventListener("click", e => {
    if (!bolge) return;
    const r = tuval.getBoundingClientRect(), x = Math.floor((e.clientX - r.left) / r.width * 600), y = Math.floor((e.clientY - r.top) / r.height * 600);
    let id = bolge[y * 600 + x];
    if (!id) { // çizginin üstüne dokunduysa en yakın bölgeyi bul
      for (let d = 1; d < 10 && !id; d++) for (const [dx, dy] of [[d, 0], [-d, 0], [0, d], [0, -d]]) { const q = (y + dy) * 600 + x + dx; if (bolge[q]) { id = bolge[q]; break; } }
    }
    if (!id || renkler[id] === renk) return;
    gecmis.push([id, renkler[id]]); renkler[id] = renk; cizSahne(); Ses.efekt("pop");
  });
  const palet = h("div", { class: "palet", role: "group", "aria-label": "Culori" });
  const pciz = () => palet.replaceChildren(...RENKLER.map(c => h("button", { type: "button", style: `background:${c}`, "aria-label": c, "aria-pressed": c === renk ? "true" : "false", onclick: () => { renk = c; Ses.efekt("pop"); pciz(); } })));
  pciz();
  s.append(geriBtn("Toate desenele"), h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Colorare"), h("h1", { style: "font-size:clamp(32px,5vw,48px)" }, b.ad)), Ses.var(b.ad) ? hoparlor(b.ad) : null),
    h("div", { class: "boyama-alan" }, tuval, h("div", { class: "kart blok" }, h("b", { style: "font-family:var(--baslik);font-size:22px" }, "Culori"), palet,
      h("div", { class: "dugmeler" }, h("button", { class: "btn acik kucuk", type: "button", onclick: () => { const g = gecmis.pop(); if (g) { if (g[1]) renkler[g[0]] = g[1]; else delete renkler[g[0]]; cizSahne(); } } }, "↩︎ Înapoi"),
        h("button", { class: "btn acik kucuk", type: "button", onclick: () => { renkler = {}; gecmis = []; cizSahne(); } }, "Șterge tot")),
      h("button", { class: "btn ana", type: "button", onclick: e => { const [x, y] = merkez(e.currentTarget); patlat(x, y, 20); Ses.efekt("fanfar"); bravo(); Kayit.etkinlik("creativitate"); Kayit.stea(1); } }, "Gata! ⭐"))));
};

S.premii = s => {
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Premiile mele"), h("h1", { class: "sayfa-baslik" }, `${Kayit.v.stele} stele`), h("p", { class: "tr" }, "Yıldızlar ve rozetler. Her etkinlik yıldız kazandırır.")),
    h("img", { src: "img/lumi_success.png", alt: "", width: "144", height: "178", style: "width:120px;height:auto" })));
  s.append(h("div", { class: "izgara rozetler" }, rozetler().map(r => {
    const var_ = Kayit.v.rozetler.includes(r.id), [a, b] = Kayit.rozetDurum(r);
    return h("div", { class: "kart rozet" + (var_ ? "" : " kilitli") }, em(r.img, 64), h("b", null, r.ad), h("small", null, r.aciklama), var_ ? null : h("small", null, `${a} / ${b}`));
  })));
};

// ============================================================ HESAP OTURUMU, EBEVEYN KAPISI, SÜRE
const oturumAcik = () => !!(Kayit.v.ebeveyn && Kayit.v.oturum);
async function pinOzet(pin) {
  const m = "lumi-ebeveyn-v1:" + pin;
  try {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(m));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
  } catch { let x = 7; for (const c of m) x = (x * 31 + c.charCodeAt(0)) | 0; return "z" + x; }
}
// Ebeveyn alanı (panel, ayarlar) kilitli açılır: PIN varsa PIN, yoksa toplama sorusu. 10 dakika açık kalır.
const Kapi = {
  t: 0,
  acik() { return Date.now() - this.t < 10 * 60e3; },
  ac() { this.t = Date.now(); },
  kilitle() { this.t = 0; },
};
function kapiFormu(acilinca) {
  const pinli = !!(Kayit.v.ebeveyn && Kayit.v.ebeveyn.pin);
  const a = 3 + Math.floor(Math.random() * 7), b = 4 + Math.floor(Math.random() * 6);
  const giris = h("input", { class: "giris-k pin-k", id: "kapi-giris", type: pinli ? "password" : "text", inputmode: "numeric", maxlength: pinli ? "4" : "2", autocomplete: "off", "aria-label": pinli ? "Ebeveyn PIN'i" : "Cevap" });
  const hata = h("p", { class: "hata", role: "alert" });
  const dene = async () => {
    const d = giris.value.trim();
    const dogru = pinli ? (await pinOzet(d)) === Kayit.v.ebeveyn.pin : +d === a + b;
    if (dogru) { Kapi.ac(); acilinca(); } else { hata.textContent = pinli ? "PIN yanlış. 4 haneli ebeveyn PIN'ini girin." : "Cevap yanlış, tekrar deneyin."; giris.value = ""; giris.focus(); Ses.efekt("boing"); }
  };
  giris.addEventListener("keydown", e => { if (e.key === "Enter") dene(); });
  setTimeout(() => giris.focus(), 60);
  return h("div", { class: "kapi" }, h("img", { src: "img/lumi_thinking.png", alt: "", width: "210", height: "184" }),
    h("h2", null, "Ebeveyn alanı"),
    h("p", { class: "tr" }, pinli ? "Devam etmek için kayıtta belirlediğiniz 4 haneli PIN'i girin." : `Bu bölüm yetişkinler içindir. ${a} + ${b} kaç eder?`),
    giris, hata, h("button", { class: "btn ana", type: "button", onclick: dene }, "Aç"),
    pinli ? null : h("p", { class: "kucuk-not" }, "Kayıt olursanız bu alanı kendi PIN'inizle korursunuz."));
}
const bugun = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
let sonHareket = Date.now();
["pointerdown", "keydown"].forEach(t => document.addEventListener(t, () => sonHareket = Date.now(), { capture: true, passive: true }));
setInterval(() => {
  if (!V || document.hidden || Date.now() - sonHareket > 180e3) return;
  Kayit.gun().dk++; Kayit.kaydet(); sureKontrol();
}, 60e3);
function sureKontrol() {
  const lim = Kayit.v.sure_limit, g = Kayit.gun();
  if (!lim || Kapi.acik() || g.dk < lim + g.ek) return;
  if (!$("#etkinlik").hidden) Joc.kapat();
  Ses.sus();
  const u = $("#uyari");
  u.dataset.kilit = "1";
  const govde = h("div", { class: "kart", role: "dialog", "aria-modal": "true", style: "text-align:center;align-items:center" },
    h("img", { src: "img/lumi_love.png", alt: "", width: "133", height: "168" }), h("h2", { style: "font-size:30px" }, "Lumi s-a obosit!"),
    h("p", { class: "tr" }, `Bugünkü ${lim} dakikalık oyun süresi doldu. Yarın yine görüşürüz!`),
    h("button", { class: "btn acik kucuk", type: "button", onclick: () => govde.replaceChildren(kapiFormu(() => { g.ek += 15; Kayit.kaydet(); delete u.dataset.kilit; u.hidden = true; tost([em("23f0", 28), "15 dakika eklendi"]); })) }, "Ebeveyn: 15 dakika daha ver"));
  u.replaceChildren(govde); u.hidden = false;
  Ses.soyle("Pa pa! Ne vedem mâine!");
}
function ustCiz() {
  const acik = oturumAcik();
  $("#giris-btn").hidden = acik; $("#kayit-btn").hidden = acik;
  $("#profil-btn").hidden = !acik || !Kayit.v.profil;
  $("#stele").hidden = !acik; $("#parinte-lnk").hidden = !acik; $("#ayar-btn").hidden = !acik;
  document.body.classList.toggle("misafir", !acik);
  const d = $("#duyuru");
  if (d) d.hidden = !!Kayit.v.duyuru_kapali;
}

// ============================================================ TANITIM
S.tanitim = s => {
  if (!Kayit.v.tanitim_goruldu) { Kayit.v.tanitim_goruldu = true; Kayit.kaydet(); }
  const n = { kelime: tumKelimeler().length, kat: V.kategoriler.length, harf: V.harfler.length, hikaye: V.hikayeler.length, sarki: V.sarkilar.length, video: VIDEOLAR.length, boyama: V.boyama.length };
  const acik = oturumAcik();
  const harfler = h("div", { class: "harfler", "aria-hidden": "true" }, [["Ă", "3%", "-8%", 190], ["Ș", "52%", "58%", 160], ["Î", "36%", "-14%", 120], ["Ț", "86%", "4%", 140], ["Â", "16%", "68%", 110]]
    .map(([c, x, y, f]) => h("span", { style: `left:${x};top:${y};font-size:${f}px` }, c)));
  s.append(h("section", { class: "afis" }, harfler,
    h("div", { class: "yazi" },
      h("div", { class: "etiketler" }, ["3–6 yaş", "Reklamsız", "Her kelime sesli"].map(t => h("span", null, t))),
      h("h1", null, "Çocuğunuz Rumenceyi ", h("em", null, "Lumi’yle"), " oynayarak öğrensin"),
      h("p", null, `${n.kelime} kelime, ${n.harf} harf, ${n.hikaye} hikâye, ${n.sarki} şarkı${n.video ? ` ve ${n.video} çizgi film` : ""}. Lumi her kelimeyi Rumence okur; ebeveyn paneli çocuğunuzun ilerlemesini gösterir.`),
      h("div", { class: "dugmeler" },
        h("button", { class: "btn ana", type: "button", onclick: () => Yol.git(acik ? "acasa" : "kayit") }, acik ? "Öğrenmeye devam et" : "Ücretsiz kayıt ol"),
        h("button", { class: "btn acik", type: "button", onclick: () => Yol.git(acik ? "parinti" : "giris") }, acik ? "Ebeveyn paneli" : "Giriş yap"))),
    h("div", { class: "lumi-cam" }, h("span", { class: "baloncuk b1", "aria-hidden": "true" }), h("span", { class: "baloncuk b2", "aria-hidden": "true" }),
      h("img", { class: "lumi", src: "img/lumi_wave.png", alt: "Lumi, vulpița, el sallıyor", width: "433", height: "640" }))));

  s.append(h("section", { class: "rakamlar", "aria-label": "İçerik" }, [[n.kelime, "kelime", `${n.kat} konuda`], [n.harf, "harf", "Ă Â Î Ș Ț dahil"], [n.hikaye, "hikâye", "Lumi okur"], [n.sarki, "şarkı", "hece hece sözler"], [n.video, "video", "Lumi’nin çizgi filmleri"], [n.boyama, "boyama", "dokun ve boya"]]
    .filter(x => x[0] > 0).map(([sayi, ad, alt]) => h("div", null, h("b", null, sayi), h("span", null, ad), h("small", null, alt)))));

  const k = gununKelimesi(), ornek = karistir(tumKelimeler().filter(x => x.img && Ses.var(x.ro) && x !== k)).slice(0, 5);
  s.append(h("section", { class: "kart dene" },
    h("div", { class: "gen" }, h("span", { class: "kicker" }, "Hemen dinleyin"), h("h2", null, "Lumi nasıl konuşuyor?"), h("p", { class: "tr" }, "Bir karta dokunun: Lumi kelimeyi Rumence söyler. Çocuklar kelimeyi duyar, resmi görür, tekrar eder.")),
    h("div", { class: "dene-kartlar" }, [k, ...ornek].filter(Boolean).map(x => {
      const b = h("button", { class: "kelime-cip", type: "button" }, em(x.img, 44), h("span", null, h("b", null, x.ro), h("small", null, x.tr)));
      b.addEventListener("click", async () => { b.classList.add("calar"); await Ses.soyle(x.ro); b.classList.remove("calar"); });
      return b;
    }))));

  const OZ = [["cuvinte", "lumi_animals", 126, 155, "Cuvinte", "Kelimeler", `Hayvanlar, renkler, sayılar, yiyecekler ve ${n.kat} konu daha. Kartlara dokunun, Lumi okusun; sonra oyunla pekiştirin.`],
    ["litere", "lumi_letters", 123, 151, "Litere", "Harfler", "Rumen alfabesinin 31 harfi, her biri örnek kelimeyle. Harf bulma ve yazma oyunları da var."],
    ["povesti", "lumi_reading", 129, 163, "Povești", "Hikâyeler", "Lumi sayfa sayfa okur, okunan kelime vurgulanır. Sonunda resimli sorular gelir."],
    ["cantece", "lumi_love", 133, 168, "Cântece", "Şarkılar", "Şarkılar Lumi’nin sesiyle söylenir; sözler hece hece yanar, birlikte söylersiniz."],
    ["jocuri", "lumi_puzzle", 108, 116, "Jocuri", "Oyunlar", "Hafıza, sayılar, şekiller ve mantık. Sorular çocuğun yaşına göre seçilir."],
    ["colorare", "lumi_drawing", 108, 116, "Colorare", "Boyama", `${n.boyama} çizim: bir renk seçin, resmin bir bölümüne dokunun.`]];
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Neler var?"), h("h2", { class: "bolum-baslik" }, "Altı bölüm, tamamı sesli"))),
    h("div", { class: "izgara ozellikler" }, OZ.map(([ad, img, w, hh, ro, tr, metin]) => h("button", { class: "kart ozellik dokun", type: "button", onclick: () => Yol.git(ad) },
      h("img", { src: `img/${img}.png`, alt: "", width: String(w), height: String(hh), loading: "lazy" }),
      h("div", { class: "gen" }, h("b", null, ro, h("span", null, " · " + tr)), h("p", null, metin))))));

  s.append(h("section", { class: "adim-bolum" }, h("div", null, h("span", { class: "kicker" }, "Nasıl başlanır?"), h("h2", { class: "bolum-baslik" }, "Üç adımda hazır")),
    h("ol", { class: "adim-liste" },
      h("li", null, h("b", null, "Kayıt olun"), h("p", null, "Adınız, e-postanız ve ebeveyn alanını koruyan 4 haneli bir PIN. Bir dakika sürer.")),
      h("li", null, h("b", null, "Çocuğun profilini açın"), h("p", null, "Ad, sevdiği hayvan avatarı ve yaş. Oyun soruları yaşa göre seçilir.")),
      h("li", null, h("b", null, "Birlikte oynayın"), h("p", null, "Günde 10–15 dakika yeter. İlerlemeyi ebeveyn panelinden izleyin.")))));

  s.append(h("section", { class: "ebeveyn-bant" },
    h("div", { style: "display:grid;gap:14px;align-content:start" }, h("span", { class: "kicker" }, "Ebeveynler için"), h("h2", null, "Kontrol sizde"),
      h("p", null, "Ebeveyn paneli PIN ile korunur. Çocuğun hangi gün ne kadar oynadığını, hangi kelimeleri öğrendiğini ve kazandığı rozetleri görürsünüz."),
      h("div", null, h("button", { class: "btn sari", type: "button", onclick: () => Yol.git(acik ? "parinti" : "kayit") }, acik ? "Ebeveyn paneline git" : "Kayıt ol ve paneli aç"))),
    h("ul", { class: "ozellik-liste" },
      h("li", null, em("1f512", 36), h("div", null, h("b", null, "PIN korumalı panel"), h("span", null, "Ayarlar ve panel çocuk tarafından açılamaz."))),
      h("li", null, em("23f0", 36), h("div", null, h("b", null, "Günlük süre sınırı"), h("span", null, "15, 30, 45 ya da 60 dakika. Süre dolunca Lumi vedalaşır."))),
      h("li", null, em("1f4ca", 36), h("div", null, h("b", null, "Haftalık rapor"), h("span", null, "Son 7 günün dakikaları ve etkinlikleri."))),
      h("li", null, em("1f3af", 36), h("div", null, h("b", null, "Yaşa göre zorluk"), h("span", null, "3, 4, 5 ve 6 yaş için ayrı soru havuzu."))))));

  const SSS = [["Neden kayıt gerekiyor?", "Lumi’nin bölümleri ücretsiz bir ebeveyn hesabıyla açılır. Böylece çocuğun ilerlemesi saklanır, ebeveyn alanı PIN ile korunur ve günlük süre sınırı koyabilirsiniz. Kayıt bir dakika sürer."],
    ["Ücretli mi?", "Hayır. Bu site ücretsizdir ve reklam içermez."],
    ["Bilgilerimiz nerede saklanıyor?", "Bu tarayıcıda. claude.ai hesabınızla açtıysanız ve kaydetmeyi seçtiyseniz, hesabınızdaki kişisel alanda da tutulur; başka kimse göremez. E-posta yalnızca giriş için kullanılır, size e-posta gönderilmez."],
    ["Çocuğum hiç Rumence bilmiyor. Olur mu?", "Olur. Her kelimenin Türkçesi yazar, Lumi Rumencesini okur. Ebeveyn açıklamaları Türkçedir; çocuk bölümleri Rumence ve seslidir."],
    ["Telefonda ve tablette çalışır mı?", "Evet, site ekran boyutuna uyar. Lumi’nin Android uygulaması da var."]];
  s.append(h("section", { class: "sss" }, h("h2", { class: "bolum-baslik" }, "Sık sorulanlar"), SSS.map(([q, a]) => h("details", null, h("summary", null, q), h("p", null, a)))));

  if (!acik) s.append(h("section", { class: "kart davet" }, h("img", { src: "img/lumi_success.png", alt: "", width: "144", height: "178" }),
    h("div", { class: "gen" }, h("b", null, "Lumi sizi bekliyor"), h("span", { class: "tr" }, "Ücretsiz hesap açın, çocuğunuzun ilk yıldızını bugün kazanın.")),
    h("button", { class: "btn ana", type: "button", onclick: () => Yol.git("kayit") }, "Kayıt ol")));
};

// ============================================================ KAYIT VE GİRİŞ
function alan(id, etiket, oz = {}, not) {
  const g = h("input", Object.assign({ class: "giris-k", id, name: id }, oz));
  return [h("label", { class: "alan", for: id }, h("b", null, etiket), g, not ? h("span", { class: "kucuk-not" }, not) : null), g];
}
S.kayit = (s, p0 = {}) => {
  if (oturumAcik()) { s.append(h("section", { class: "kart blok", style: "max-width:560px" }, h("h2", null, "Zaten giriş yaptınız"), h("p", null, `${Kayit.v.ebeveyn.eposta} hesabıyla oturum açık.`),
    h("div", { class: "dugmeler" }, h("button", { class: "btn ana kucuk", type: "button", onclick: () => Yol.git("acasa") }, "Ana sayfa"), h("button", { class: "btn acik kucuk", type: "button", onclick: () => Yol.git("parinti") }, "Ebeveyn paneli")))); return; }
  const p = Object.assign({ ad: "", avatar: AVATARLAR[0], varsta: Kayit.v.varsta }, Kayit.v.profil || {});
  const [eAdL, eAd] = alan("k-ad", "Adınız", { maxlength: "40", autocomplete: "name", placeholder: "Örn. Ayşe" });
  const [epL, ep] = alan("k-eposta", "E-posta", { type: "email", maxlength: "80", autocomplete: "email", placeholder: "ornek@eposta.com" }, "Giriş yaparken kullanılır. Size e-posta gönderilmez.");
  const [pinL, pin] = alan("k-pin", "Ebeveyn PIN'i", { type: "password", inputmode: "numeric", maxlength: "4", autocomplete: "new-password", placeholder: "4 rakam" }, "Ebeveyn paneli ve ayarlar bu PIN ile açılır.");
  const [pin2L, pin2] = alan("k-pin2", "PIN tekrar", { type: "password", inputmode: "numeric", maxlength: "4", autocomplete: "new-password", placeholder: "4 rakam" });
  const [cAdL, cAd] = alan("k-cocuk", "Çocuğun adı", { maxlength: "20", autocomplete: "off", placeholder: "Lumi ona adıyla seslenir", value: p.ad });
  const av = h("div", { class: "avatarlar", role: "group", "aria-label": "Avatar" });
  const avCiz = () => av.replaceChildren(...AVATARLAR.map(k => h("button", { type: "button", "aria-pressed": p.avatar === k ? "true" : "false", onclick: () => { p.avatar = k; Ses.efekt("pop"); avCiz(); } }, em(k, 44))));
  avCiz();
  const yas = h("div", { class: "secimler" });
  const yasCiz = () => yas.replaceChildren(...[3, 4, 5, 6].map(n => h("button", { type: "button", "aria-pressed": p.varsta === n ? "true" : "false", onclick: () => { p.varsta = n; yasCiz(); } }, `${n} yaş`)));
  yasCiz();
  const onay = h("input", { type: "checkbox", id: "k-onay" });
  const hesapKutu = Hesap.me ? h("input", { type: "checkbox", id: "k-hesap", checked: true }) : null;
  const hata = h("p", { class: "hata", role: "alert" });
  const form = h("form", { class: "kart kayit-form", novalidate: true },
    h("div", null, h("span", { class: "kicker" }, "Adım 1 · Ebeveyn"), h("h2", null, "Hesabınızı oluşturun")),
    eAdL, epL, h("div", { class: "iki" }, pinL, pin2L),
    h("div", null, h("span", { class: "kicker" }, "Adım 2 · Çocuk"), h("h2", null, "Çocuğun profili")),
    cAdL, h("div", { class: "alan" }, h("b", null, "Bir arkadaş seçin"), av), h("div", { class: "alan" }, h("b", null, "Yaşı"), yas),
    hesapKutu ? h("label", { class: "onay", for: "k-hesap" }, hesapKutu, h("span", null, h("b", null, `${Hesap.me.name || "claude.ai"} hesabıma da kaydet. `), "Bu cihazın ilerlemesi yedeklenir; her cihazın kaydı ayrıdır.")) : null,
    h("label", { class: "onay", for: "k-onay" }, onay, h("span", null, "Bilgilerin bu tarayıcıda saklandığını okudum; çocuğum için ebeveyn olarak kayıt oluyorum.")),
    hata, h("button", { class: "btn ana", type: "submit" }, "Kayıt ol ve başla"),
    h("p", { class: "kucuk-not" }, "Hesabınız var mı? ", h("button", { type: "button", class: "metin-lnk", onclick: () => Yol.git("giris") }, "Giriş yapın")));
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const sorun = !eAd.value.trim() ? [eAd, "Adınızı yazın."] : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ep.value.trim()) ? [ep, "Geçerli bir e-posta yazın (örn. ad@eposta.com)."]
      : !/^\d{4}$/.test(pin.value) ? [pin, "PIN tam 4 rakam olmalı."] : pin.value !== pin2.value ? [pin2, "İki PIN aynı değil."]
      : !onay.checked ? [onay, "Devam etmek için onay kutusunu işaretleyin."] : null;
    if (sorun) { hata.textContent = sorun[1]; sorun[0].focus(); Ses.efekt("boing"); return; }
    Kayit.v.ebeveyn = { ad: eAd.value.trim(), eposta: ep.value.trim().toLowerCase(), pin: await pinOzet(pin.value), tarih: bugun() };
    Kayit.v.profil = { ad: cAd.value.trim(), avatar: p.avatar, varsta: p.varsta };
    Kayit.v.varsta = p.varsta; Kayit.v.oturum = true;
    Kayit.v.hesap = !!(hesapKutu && hesapKutu.checked);
    Kayit.kaydet(); ustCiz(); profilCiz(); Kapi.ac();
    Ses.efekt("fanfar");
    tost([em(p.avatar, 30), `Hoş geldiniz${Kayit.v.ebeveyn.ad ? ", " + Kayit.v.ebeveyn.ad : ""}!`]);
    Yol.git("acasa");
    if (Kayit.v.profil.ad) setTimeout(() => Ses.soyle("Bună, " + Kayit.v.profil.ad + "!"), 400);
  });
  if (p0.kilitli) s.append(h("section", { class: "kart davet" }, em("1f512", 56), h("div", { class: "gen" }, h("b", null, "Önce kayıt olun"), h("span", { class: "tr" }, "Lumi’nin bölümleri ücretsiz bir ebeveyn hesabıyla açılır. Hesabınız varsa giriş yapın.")),
    h("button", { class: "btn acik", type: "button", onclick: () => Yol.git("giris") }, "Giriş yap")));
  s.append(h("div", { class: "kayit-sayfa" }, form,
    h("aside", { class: "kayit-yan" }, h("img", { src: "img/lumi_success.png", alt: "", width: "144", height: "178" }),
      h("h1", null, "Ücretsiz kayıt"), h("p", { class: "tr" }, "Kayıtla birlikte:"),
      h("ul", null, h("li", null, "PIN korumalı ebeveyn paneli"), h("li", null, "Günlük süre sınırı"), h("li", null, "Haftalık ilerleme raporu"), h("li", null, "Yıldızlar ve rozetler saklanır")),
      h("button", { class: "metin-lnk", type: "button", onclick: () => Yol.git("tanitim") }, "‹ Lumi’yi tanıyın"))));
};
S.giris = s => {
  const [epL, ep] = alan("g-eposta", "E-posta", { type: "email", autocomplete: "email", placeholder: "ornek@eposta.com", value: Kayit.v.ebeveyn ? Kayit.v.ebeveyn.eposta : "" });
  const [pinL, pin] = alan("g-pin", "PIN", { type: "password", inputmode: "numeric", maxlength: "4", autocomplete: "current-password", placeholder: "4 rakam" });
  const hata = h("p", { class: "hata", role: "alert" });
  const form = h("form", { class: "kart kayit-form", novalidate: true, style: "max-width:480px;width:100%;margin:0 auto" },
    h("img", { src: "img/lumi_happy.png", alt: "", width: "210", height: "184", style: "width:120px;height:auto;border-radius:22px" }),
    h("div", null, h("span", { class: "kicker" }, "Tekrar hoş geldiniz"), h("h1", { style: "font-size:40px" }, "Giriş yap")),
    epL, pinL, hata, h("button", { class: "btn ana", type: "submit" }, "Giriş yap"),
    h("p", { class: "kucuk-not" }, "Hesabınız yok mu? ", h("button", { type: "button", class: "metin-lnk", onclick: () => Yol.git("kayit") }, "Kayıt olun")),
    h("p", { class: "kucuk-not" }, "Hesap bu cihazda saklanır. Her cihazın kendi oturumu vardır: başka cihazda açtığınız hesap buraya gelmez, bu cihazda ayrıca kayıt olun. PIN'i unuttuysanız: Ayarlar sayfasından hesabı silip yeniden kayıt olabilirsiniz."));
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const eb = Kayit.v.ebeveyn;
    if (!eb) { hata.textContent = "Bu tarayıcıda kayıtlı hesap yok. Önce kayıt olun."; return; }
    if (ep.value.trim().toLowerCase() !== eb.eposta || (await pinOzet(pin.value)) !== eb.pin) { hata.textContent = "E-posta ya da PIN yanlış."; pin.value = ""; pin.focus(); Ses.efekt("boing"); return; }
    Kayit.v.oturum = true; Kayit.kaydet(); ustCiz(); Kapi.ac();
    tost([em((Kayit.v.profil || {}).avatar || "1f98a", 30), `Hoş geldiniz, ${eb.ad}!`]);
    Yol.git("acasa");
  });
  s.append(form);
  setTimeout(() => (ep.value ? pin : ep).focus(), 60);
};
function cikisYap() { Kayit.v.oturum = false; Kapi.kilitle(); Kayit.kaydet(); ustCiz(); tost("Çıkış yapıldı"); Yol.git("tanitim"); }

// ============================================================ EBEVEYN PANELİ
function kapiliSayfa(s, ciz) {
  if (Kapi.acik()) return ciz();
  s.append(h("div", { class: "kart kapi-kart" }, kapiFormu(() => Yol.ciz())));
}
S.parinti = s => kapiliSayfa(s, () => {
  const v = Kayit.v, eb = v.ebeveyn, g = Kayit.gun();
  const gunler = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 6 + i); const k = bugun(d); return [d, v.gunler[k] || { dk: 0, e: 0, s: 0 }]; });
  const hafta = gunler.reduce((a, [, x]) => a + x.dk, 0), haftaE = gunler.reduce((a, [, x]) => a + x.e, 0), enCok = Math.max(5, ...gunler.map(([, x]) => x.dk));
  const GUN = ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt"];
  const kat = V.kategoriler.filter(c => V.kelimeler[c.id]).map(c => [c, Kayit.ogrenilenSay(c.id), V.kelimeler[c.id].length]).filter(x => x[1] > 0).sort((a, b) => b[1] / b[2] - a[1] / a[2]);
  const rz = rozetler().filter(r => v.rozetler.includes(r.id));
  const limit = h("div", { class: "secimler" }, [[0, "Kapalı"], [15, "15 dk"], [30, "30 dk"], [45, "45 dk"], [60, "60 dk"]].map(([n, y]) =>
    h("button", { type: "button", "aria-pressed": v.sure_limit === n ? "true" : "false", onclick: () => { v.sure_limit = n; Kayit.kaydet(); Yol.ciz(); } }, y)));
  const kalan = v.sure_limit ? Math.max(0, v.sure_limit + g.ek - g.dk) : null;
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Ebeveyn paneli"), h("h1", { class: "sayfa-baslik" }, eb ? `Merhaba, ${eb.ad}` : "Ebeveyn paneli"),
    h("p", { class: "tr" }, v.profil && v.profil.ad ? `${v.profil.ad} için son 7 gün ve toplam ilerleme.` : "Çocuğunuzun son 7 günü ve toplam ilerlemesi.")),
    h("div", { class: "dugmeler" }, h("button", { class: "btn acik kucuk", type: "button", onclick: () => Yol.git("ayarlar") }, "Ayarlar"),
      h("button", { class: "btn acik kucuk", type: "button", onclick: () => { Kapi.kilitle(); Yol.git("acasa"); } }, "Kilitle ve çık"))));
  if (!eb) s.append(h("section", { class: "kart davet" }, em("1f512", 64), h("div", { class: "gen" }, h("b", null, "Paneli PIN ile koruyun"), h("span", { class: "tr" }, "Kayıt olun: çocuğunuz paneli ve ayarları açamaz, ilerleme hesabınızda saklanır.")),
    h("button", { class: "btn ana", type: "button", onclick: () => Yol.git("kayit") }, "Kayıt ol")));
  s.append(h("div", { class: "ozet" },
    h("div", { class: "kart" }, h("span", null, "Bugün"), h("b", null, g.dk, h("small", null, " dk")), h("small", null, `${g.e} etkinlik`)),
    h("div", { class: "kart" }, h("span", null, "Son 7 gün"), h("b", null, hafta, h("small", null, " dk")), h("small", null, `${haftaE} etkinlik`)),
    h("div", { class: "kart" }, h("span", null, "Yıldız"), h("b", null, v.stele), h("small", null, `${rz.length} rozet`)),
    h("div", { class: "kart" }, h("span", null, "Öğrenilen kelime"), h("b", null, Kayit.ogrenilenSay()), h("small", null, `${tumKelimeler().length} kelimeden`))));
  s.append(h("div", { class: "ebeveyn" },
    h("div", { style: "display:grid;gap:20px;min-width:0" },
      h("section", { class: "kart blok" }, h("h2", null, "Haftalık kullanım"), h("p", null, "Günlük dakika. Çocuk 3 dakika hareketsiz kalırsa sayaç durur."),
        h("div", { class: "grafik", role: "img", "aria-label": `Son 7 günde toplam ${hafta} dakika` }, gunler.map(([d, x], i) => h("div", { class: "sutun" + (i === 6 ? " bugun" : "") },
          h("small", { class: "deger" }, x.dk), h("i", { style: `height:${Math.max(2, x.dk / enCok * 100)}%` }), h("small", null, i === 6 ? "Bugün" : GUN[d.getDay()]))))),
      h("section", { class: "kart blok" }, h("h2", null, "Konu ilerlemesi"),
        kat.length ? h("div", { style: "display:grid;gap:8px" }, kat.map(([c, a, b]) => h("div", { class: "satir" }, em(c.img, 28), h("span", { class: "kat-ad" }, c.tr), h("div", { class: "cubuk gen" }, h("i", { style: `width:${Math.min(1, a / b) * 100}%;background:${c.renk}` })), h("b", { class: "kat-say" }, `${Math.min(a, b)}/${b}`))))
          : h("p", null, "Henüz öğrenilen kelime yok. Oyunlarda doğru cevaplanan kelimeler burada görünür.")),
      h("section", { class: "kart blok" }, h("h2", null, "Kazanılan rozetler"),
        rz.length ? h("div", { class: "rozet-serit" }, rz.map(r => h("div", { title: r.aciklama }, em(r.img, 44), h("small", null, r.ad)))) : h("p", null, "İlk rozet birkaç etkinlikten sonra gelir."),
        h("button", { class: "btn acik kucuk", type: "button", style: "align-self:flex-start", onclick: () => Yol.git("premii") }, em("1f3c5", 26), "Tüm rozetler"))),
    h("div", { style: "display:grid;gap:20px;min-width:0" },
      h("section", { class: "kart blok" }, h("h2", null, "Çocuk profili"),
        v.profil ? h("div", { class: "satir" }, em(v.profil.avatar, 56), h("div", { class: "gen" }, h("b", { style: "font-size:20px" }, v.profil.ad || "Profil"), h("div", { class: "kucuk-not" }, `${v.varsta} yaş · sorular bu yaşa göre`))) : h("p", null, "Henüz profil yok."),
        h("button", { class: "btn acik kucuk", type: "button", style: "align-self:flex-start", onclick: profilAc }, v.profil ? "Profili düzenle" : "Profil oluştur")),
      h("section", { class: "kart blok" }, h("h2", null, "Günlük süre sınırı"), h("p", null, "Süre dolunca Lumi vedalaşır; devam etmek için ebeveyn kapısı gerekir."), limit,
        kalan != null ? h("div", { style: "display:grid;gap:6px" }, h("div", { class: "cubuk" }, h("i", { style: `width:${Math.min(1, g.dk / (v.sure_limit + g.ek)) * 100}%;background:var(--turuncu)` })), h("span", { class: "kucuk-not" }, `Bugün ${g.dk} dk kullanıldı, ${kalan} dk kaldı.`)) : null),
      h("section", { class: "kart blok" }, h("h2", null, "Hesap"),
        eb ? h("div", { class: "satir" }, h("div", { class: "gen" }, h("b", null, eb.ad), h("div", { class: "kucuk-not", style: "overflow-wrap:anywhere" }, eb.eposta))) : h("p", null, "Kayıtlı hesap yok; ilerleme bu tarayıcıda saklanıyor."),
        Hesap.me ? h("div", { class: "hesap" }, h("img", { src: Hesap.me.avatarUrl, alt: "" }), h("div", { class: "gen" }, h("b", null, Hesap.me.name || "claude.ai hesabı"), h("div", { class: "kucuk-not" }, v.hesap ? "İlerleme bu hesapta da saklanıyor." : "İlerleme şimdilik sadece bu tarayıcıda."))) : null,
        eb ? h("div", { class: "dugmeler" }, h("button", { class: "btn acik kucuk", type: "button", onclick: pinDegistir }, "PIN'i değiştir"), h("button", { class: "btn acik kucuk", type: "button", onclick: cikisYap }, "Çıkış yap"))
          : h("button", { class: "btn ana kucuk", type: "button", style: "align-self:flex-start", onclick: () => Yol.git("kayit") }, "Kayıt ol")),
      h("section", { class: "kart blok" }, h("h2", null, "Nasıl kullanılır?"), h("ul", null,
        h("li", null, "Cuvinte: Konu seçin, kartlara dokunarak kelimeleri birlikte dinleyin, sonra \"Joacă\" ile oyun oynayın."),
        h("li", null, "Povești: Lumi sayfaları okur; sonunda resimli sorular gelir."),
        h("li", null, "Video ve Cântece: her kelime iki kez söylenir; çocuğunuzla birlikte tekrar edin.")),
        h("p", null, "Kısa ve sık oturumlar (günde 10–15 dakika) en iyisidir.")))));
});
function pinDegistir() {
  const u = $("#uyari");
  const [l1, p1] = alan("pin-yeni", "Yeni PIN", { type: "password", inputmode: "numeric", maxlength: "4", autocomplete: "new-password" });
  const [l2, p2] = alan("pin-yeni2", "Yeni PIN tekrar", { type: "password", inputmode: "numeric", maxlength: "4", autocomplete: "new-password" });
  const hata = h("p", { class: "hata", role: "alert" });
  const kaydet = async () => {
    if (!/^\d{4}$/.test(p1.value)) { hata.textContent = "PIN tam 4 rakam olmalı."; return; }
    if (p1.value !== p2.value) { hata.textContent = "İki PIN aynı değil."; return; }
    Kayit.v.ebeveyn.pin = await pinOzet(p1.value); Kayit.kaydet(); u.hidden = true; tost("PIN değiştirildi");
  };
  u.replaceChildren(h("div", { class: "kart", role: "dialog", "aria-modal": "true" }, h("h2", { style: "font-size:26px" }, "PIN'i değiştir"), l1, l2, hata,
    h("button", { class: "btn ana", type: "button", onclick: kaydet }, "Kaydet"), h("button", { class: "btn acik", type: "button", onclick: () => u.hidden = true }, "Vazgeç")));
  u.hidden = false; setTimeout(() => p1.focus(), 50);
}

// ============================================================ AYARLAR
S.ayarlar = s => kapiliSayfa(s, () => {
  const v = Kayit.v;
  const ayar = (id, ad, alt, deger, f) => { const g = h("input", { type: "checkbox", id, checked: deger }); g.addEventListener("change", () => f(g.checked)); return h("label", { class: "satir ayar-satir", for: id }, h("div", { class: "gen" }, h("b", null, ad), h("div", { class: "kucuk-not" }, alt)), g); };
  const ses = h("input", { type: "range", id: "ses-duzey", min: "0", max: "1", step: ".05", value: v.ses, style: "accent-color:var(--mov)" });
  ses.addEventListener("change", () => { v.ses = +ses.value; Kayit.kaydet(); Ses.efekt("dogru"); });
  const yas = h("div", { class: "secimler" }, [3, 4, 5, 6].map(n => h("button", { type: "button", "aria-pressed": v.varsta === n ? "true" : "false", onclick: () => { v.varsta = n; if (v.profil) v.profil.varsta = n; Kayit.kaydet(); Yol.ciz(); } }, `${n} yaş`)));
  s.append(h("div", { class: "bas-satir" }, h("div", { class: "gen" }, h("span", { class: "kicker" }, "Ayarlar"), h("h1", { class: "sayfa-baslik" }, "Ayarlar"), h("p", { class: "tr" }, "Değişiklikler hemen kaydedilir.")),
    h("button", { class: "btn acik kucuk", type: "button", onclick: () => Yol.git("parinti") }, "Ebeveyn paneli")));
  s.append(h("div", { class: "ebeveyn" },
    h("div", { style: "display:grid;gap:20px;min-width:0" },
      h("section", { class: "kart blok" }, h("h2", null, "Ses"),
        ayar("ayar-ses", "Sesler", "Lumi'nin sesi, şarkılar, hayvan ve doğa sesleri", v.ses_acik, x => { v.ses_acik = x; if (!x) Ses.ortamDur(); Kayit.kaydet(); }),
        h("label", { class: "satir", for: "ses-duzey" }, h("b", { class: "gen" }, "Ses düzeyi"), ses)),
      h("section", { class: "kart blok" }, h("h2", null, "Öğrenme"),
        h("div", { style: "display:grid;gap:6px" }, h("b", null, "Çocuğun yaşı"), h("span", { class: "kucuk-not" }, "Oyun soruları bu yaşa göre seçilir."), yas)),
      h("section", { class: "kart blok" }, h("h2", null, "Görünüm"),
        ayar("ayar-anim", "Az animasyon", "Zıplama ve parıltıları kapatır", v.az_anim, x => { v.az_anim = x; Kayit.kaydet(); document.documentElement.classList.toggle("az-anim", x); }),
        ayar("ayar-duyuru", "Duyuru bandı", "Sayfanın en üstündeki yenilik bandını göster", !v.duyuru_kapali, x => { v.duyuru_kapali = !x; Kayit.kaydet(); ustCiz(); }))),
    h("div", { style: "display:grid;gap:20px;min-width:0" },
      h("section", { class: "kart blok" }, h("h2", null, "Hesap ve veriler"),
        h("p", null, Kayit.v.ebeveyn ? `${Kayit.v.ebeveyn.eposta} hesabı bu tarayıcıda kayıtlı.` : "Kayıtlı hesap yok."),
        h("div", { class: "dugmeler" },
          h("button", { class: "btn acik kucuk", type: "button", style: "color:var(--kirmizi)", onclick: sifirlaSor }, "İlerlemeyi sıfırla"),
          Kayit.v.ebeveyn ? h("button", { class: "btn acik kucuk", type: "button", style: "color:var(--kirmizi)", onclick: hesapSilSor }, "Hesabı sil") : null)),
      h("section", { class: "kart blok" }, h("h2", null, "Bu cihaz"),
        Cihaz.v ? h("div", { class: "cihaz-kimlik" }, em(CIHAZ_TURLERI.find(([t]) => t === Cihaz.v.tur)?.[1] || "1f4f1", 40),
          h("div", { class: "gen" }, h("b", null, Cihaz.v.ad), h("div", { class: "kucuk-not" }, `Cihaz kodu: ${Cihaz.kisaId()} · Kurulum: ${new Date(Cihaz.v.kuruldu).toLocaleDateString("tr-TR")}`))) : null,
        h("p", null, "Her cihazın kendi kurulumu ve oturumu vardır. Başka bir cihazdaki hesap ve ilerleme bu cihaza yüklenmez; bu cihazdakiler de başka cihaza gitmez."),
        h("button", { class: "btn acik kucuk", type: "button", style: "align-self:flex-start;color:var(--kirmizi)", onclick: cihazYenidenKurSor }, "Bu cihazı yeniden kur")),
      h("section", { class: "kart blok" }, h("h2", null, "Gizlilik"), h("p", null, "Reklam yok. Hesap bilgileri (ad, e-posta, PIN özeti) ve çocuğun profili bu tarayıcıda saklanır; PIN'in kendisi saklanmaz. Her cihazın oturumu ayrıdır; bir cihazdaki bilgiler başka cihaza aktarılmaz.")),
      h("section", { class: "kart blok" }, h("h2", null, "Kaynaklar"), h("p", null, "Seslendirme: Microsoft Edge sinir ağı sesi (Alina). Simgeler: Twemoji (CC BY 4.0). Yazı tipleri: Baloo 2 ve Nunito (SIL OFL). Videolar, şarkılar ve fon müziği Lumi için üretildi. Hayvan ve doğa sesleri: Pixabay (Pixabay İçerik Lisansı).")))));
});
function sifirlaSor() {
  const u = $("#uyari");
  u.replaceChildren(h("div", { class: "kart", role: "dialog", "aria-modal": "true" }, h("h2", { style: "font-size:26px" }, "İlerleme sıfırlansın mı?"), h("p", { class: "tr" }, "Yıldızlar, rozetler, öğrenilen kelimeler ve günlük kullanım silinir. Hesap, profil ve ayarlar kalır."),
    h("button", { class: "btn ana", type: "button", onclick: () => u.hidden = true }, "Vazgeç"),
    h("button", { class: "btn acik", type: "button", style: "color:var(--kirmizi)", onclick: () => {
      const { varsta, ses_acik, ses, az_anim, profil, ebeveyn, oturum, hesap, sure_limit, duyuru_kapali, tanitim_goruldu } = Kayit.v;
      Kayit.v = Object.assign(Kayit.bos(), { varsta, ses_acik, ses, az_anim, profil, ebeveyn, oturum, hesap, sure_limit, duyuru_kapali, tanitim_goruldu });
      Kayit.kaydet(); steleCiz(); u.hidden = true; Yol.ciz(); tost("İlerleme sıfırlandı");
    } }, "Evet, sıfırla")));
  u.hidden = false;
}
function hesapSilSor() {
  const u = $("#uyari");
  u.replaceChildren(h("div", { class: "kart", role: "dialog", "aria-modal": "true" }, h("h2", { style: "font-size:26px" }, "Hesap silinsin mi?"),
    h("p", { class: "tr" }, "Hesap, çocuğun profili ve tüm ilerleme bu tarayıcıdan" + (Kayit.v.hesap ? " ve claude.ai hesabınızdaki kayıttan" : "") + " silinir. Bu geri alınamaz."),
    h("button", { class: "btn ana", type: "button", onclick: () => u.hidden = true }, "Vazgeç"),
    h("button", { class: "btn acik", type: "button", style: "color:var(--kirmizi)", onclick: () => {
      const uzak = Kayit.v.hesap;
      Kayit.v = Object.assign(Kayit.bos(), { tanitim_goruldu: true });
      Kayit.kaydet();
      if (uzak && Hesap.ref) Hesap.ref.set({ json: JSON.stringify(Kayit.v), t: Kayit.v.t }).catch(() => {});
      Kapi.kilitle(); steleCiz(); profilCiz(); ustCiz(); u.hidden = true; tost("Hesap silindi"); Yol.git("tanitim");
    } }, "Evet, hesabı sil")));
  u.hidden = false;
}

// ============================================================ OYUNLAR (tam ekran)
const Joc = {
  no: 0,
  ac(icerik) {
    const E = $("#etkinlik");
    E.hidden = false; document.body.style.overflow = "hidden"; Ses.ortamDur();
    E.replaceChildren(...icerik);
  },
  kapat() { this.no++; Ses.sus(); Ses.ortamDur(); $("#etkinlik").hidden = true; $("#etkinlik").replaceChildren(); document.body.style.overflow = ""; if (Yol.su.ad !== "cantec") Yol.ciz(); },
  ust(adimlar) {
    return h("div", { class: "etk-ust" }, h("button", { class: "kapat", type: "button", "aria-label": "Închide", onclick: () => this.kapat() }, "✕"), adimlar || h("div", { class: "adimlar" }));
  },
  kutla(baslik, stele, tekrar) {
    const no = ++this.no;
    Ses.efekt("fanfar");
    setTimeout(() => { if (this.no === no) bravo(); }, 500);
    this.ac([this.ust(), h("div", { class: "etk-govde" }, h("div", { class: "kutlama" }, h("img", { src: "img/lumi_success.png", alt: "", width: "144", height: "178" }), h("h2", null, baslik),
      stele ? h("div", { class: "kazanilan" }, Array.from({ length: Math.min(stele, 10) }, () => em("2b50", 48))) : null,
      stele ? h("p", { class: "tr", style: "font-size:20px" }, `Ai câștigat ${stele} ${stele === 1 ? "stea" : "stele"}!`) : null,
      h("div", { class: "dugmeler", style: "justify-content:center" }, tekrar ? h("button", { class: "btn sari", type: "button", onclick: tekrar }, "Încă o dată") : null, h("button", { class: "btn ana", type: "button", onclick: () => this.kapat() }, "Gata"))))]);
    setTimeout(() => { const i = $("#etkinlik .kutlama img"); if (i) { const [x, y] = merkez(i); patlat(x, y, 24); } }, 200);
  },

  // ---------- soru turu
  quiz(havuz, baslik, kat, bitince) {
    if (!havuz.length) { tost("Bu yaş için soru yok."); return; }
    const sorular = kat ? karistir(havuz).slice(0, 6) : havuz.slice();
    if (kat) Ses.hazirla("k_" + kat);
    const durum = { i: 0, ilk: 0, hata: false };
    const no = ++this.no;
    const adimlar = h("div", { class: "adimlar" }, sorular.map(() => h("i")));
    const govde = h("div", { class: "etk-govde" });
    this.ac([this.ust(adimlar), govde]);
    const sonraki = async dogru => {
      if (dogru && !durum.hata) durum.ilk++;
      adimlar.children[durum.i].className = durum.hata ? "su" : "ok";
      await bekle(1100);
      if (this.no !== no) return;
      durum.i++; durum.hata = false;
      if (durum.i >= sorular.length) {
        const st = Math.max(1, durum.ilk);
        if (kat) Kayit.etkinlik(kat);
        if (bitince) bitince(); else Kayit.stea(st);
        this.kutla(durum.ilk === sorular.length ? "Perfect!" : "Bravo!", bitince ? 2 : st, kat ? () => this.quiz(havuz, baslik, kat) : null);
      } else goster();
    };
    const yanlis = el => { durum.hata = true; Ses.efekt("boing"); el.classList.remove("sallan"); void el.offsetWidth; el.classList.add("sallan"); setTimeout(tekrarDene, 250); };
    const dogruOldu = (el, q) => {
      Ses.efekt("dogru"); const [x, y] = merkez(el); patlat(x, y);
      if (q.kelime) Kayit.ogren(q.kategori, q.kelime);
      if (q.harf) Kayit.ogren("litere", q.harf);
      setTimeout(() => { if (this.no === no) bravo(); }, 350);
      sonraki(true);
    };
    const goster = () => {
      const q = sorular[durum.i];
      adimlar.children[durum.i].className = "su";
      govde.replaceChildren();
      const soruMetni = q.dinle ? "Ascultă și găsește!" : q.soru;
      const okunacak = q.dinle ? (q.secenekler.find(o => o.id === q.dogru) || {}).ro : q.soru;
      govde.append(h("div", { class: "soru" }, h("h2", null, soruMetni), hoparlor(okunacak, 60)));
      setTimeout(() => { if (this.no === no && govde.isConnected) Ses.soyle(okunacak); }, 300);
      if (q.gorsel) govde.append(gorsel(q.gorsel, 180, true));
      (TIP[q.tip] || TIP.sec)(q);
    };
    const kartBtn = (icerik, f) => { const b = h("button", { class: "secenek", type: "button" }, icerik); b.addEventListener("click", () => f(b)); return b; };
    const TIP = {
      sec(q) {
        const n = q.secenekler.length, px = n > 3 ? 110 : 130;
        const kutu = h("div", { class: "secenekler" });
        let bitti = false;
        for (const o of karistir(q.secenekler)) {
          const b = kartBtn(gorsel(o, px), b => {
            if (bitti) return;
            const okunur = o.ro || (q.soyle_secenek && o.metin);
            if (o.id === q.dogru) { bitti = true; b.classList.add("dogru"); if (okunur && !q.dinle) Ses.soyle(okunur); dogruOldu(b, q); }
            else { b.classList.add("yanlis"); b.disabled = true; if (okunur && !q.dinle) Ses.soyle(okunur); yanlis(b); }
          });
          b._o = o;
          if (q.dinle) b.querySelectorAll(".yazi").forEach(x => x.remove());
          kutu.append(b);
        }
        govde.append(kutu);
      },
      ayni(q) {
        const kutu = h("div", { class: "secenekler" });
        let ilk = null, bitti = false;
        for (const o of karistir(q.secenekler)) {
          const b = kartBtn(gorsel(o, 120), b => {
            if (bitti || b === ilk) return;
            Ses.efekt("pop");
            if (!ilk) { ilk = b; b.classList.add("secili"); return; }
            if (b._o.img === ilk._o.img) { bitti = true; [ilk, b].forEach(x => { x.classList.remove("secili"); x.classList.add("dogru"); }); dogruOldu(b, q); }
            else { ilk.classList.remove("secili"); ilk = null; yanlis(b); }
          });
          b._o = o; kutu.append(b);
        }
        govde.append(kutu);
      },
      sirala(q) {
        const kutu = h("div", { class: "secenekler" });
        let sira = 0;
        for (const o of karistir(q.secenekler)) {
          const b = kartBtn(gorsel(o, 130), b => {
            if (b.classList.contains("dogru")) return;
            if (o.sira === sira) { sira++; b.classList.add("dogru"); Ses.efekt("pop"); if (sira === q.secenekler.length) dogruOldu(b, q); }
            else yanlis(b);
          });
          b._o = o; kutu.append(b);
        }
        govde.append(kutu);
      },
      kelime_kur(q) {
        const hedef = [...q.kelime_metin];
        let sira = 0;
        const yuva = h("div", { class: "harf-yuva" }, hedef.map(() => h("span")));
        govde.append(h("div", { class: "gorsel-kutu" }, em(q.img, 150)), yuva);
        const kutu = h("div", { class: "secenekler" });
        for (const harf of karistir(q.harfler)) kutu.append(kartBtn(h("span", { style: "font-size:46px" }, harf), b => {
          if (sira >= hedef.length || b.classList.contains("bitti")) return;
          if (harf === hedef[sira]) {
            yuva.children[sira].textContent = harf; sira++; b.classList.add("bitti"); Ses.soyle(harf);
            if (sira === hedef.length) { const k = (q.soru.match(/cuvântul (.+?)!?$/) || [])[1]; setTimeout(() => k && Ses.soyle(k), 500); dogruOldu(yuva, q); }
          } else yanlis(b);
        }));
        kutu.querySelectorAll(".secenek").forEach(b => { b.style.minWidth = "88px"; b.style.minHeight = "88px"; });
        govde.append(kutu);
      },
      kategori(q) {
        let secili = null, kalan = q.ogeler.length;
        const kutular = h("div", { class: "kutular" }, q.kutular.map(k => {
          const ic = h("div", { class: "icerik" });
          const d = h("button", { class: "kutu-hedef", type: "button" }, em(k.img, 64), k.ro, ic);
          d.addEventListener("click", () => {
            if (!secili) { Ses.soyle(k.ro); return; }
            if (secili._o.kutu === k.id) { ic.append(em(secili._o.img, 40)); secili.classList.add("bitti"); secili.classList.remove("secili"); Ses.efekt("pop"); secili = null; kutular.querySelectorAll(".kutu-hedef").forEach(x => x.classList.remove("hazir")); if (--kalan === 0) dogruOldu(d, q); }
            else yanlis(d);
          });
          d._k = k;
          return d;
        }));
        const ogeler = h("div", { class: "secenekler" }, karistir(q.ogeler).map(o => { const b = kartBtn(em(o.img, 84), b => {
          if (b.classList.contains("bitti")) return;
          if (secili) secili.classList.remove("secili");
          secili = b; b.classList.add("secili"); if (o.ro) Ses.soyle(o.ro); kutular.querySelectorAll(".kutu-hedef").forEach(x => x.classList.add("hazir"));
        }); b._o = o; b.style.minWidth = b.style.minHeight = "104px"; return b; }));
        govde.append(h("p", { class: "tr" }, "Önce resme, sonra doğru kutuya dokun."), ogeler, kutular);
      },
      surukle(q) {
        let secili = null, kalan = q.ogeler.length;
        const golgeler = h("div", { class: "secenekler" }, karistir(q.ogeler).map(o => {
          const d = kartBtn(sekil(o.sekil, "#cfc8e4", 110), d => {
            if (!secili || d.classList.contains("dogru")) return;
            if (secili._o.id === o.id) { d.replaceChildren(sekil(o.sekil, o.renk, 110)); d.classList.add("dogru"); secili.classList.add("bitti"); secili.classList.remove("secili"); secili = null; Ses.efekt("pop"); if (--kalan === 0) dogruOldu(d, q); }
            else yanlis(d);
          });
          d.style.background = "rgba(255,255,255,.6)"; d._o = o; return d;
        }));
        const sekiller = h("div", { class: "secenekler" }, karistir(q.ogeler).map(o => { const b = kartBtn(sekil(o.sekil, o.renk, 100), b => {
          if (b.classList.contains("bitti")) return;
          if (secili) secili.classList.remove("secili");
          secili = b; b.classList.add("secili"); Ses.efekt("pop");
        }); b._o = o; return b; }));
        govde.append(h("p", { class: "tr" }, "Önce şekle, sonra gölgesine dokun."), sekiller, golgeler);
      },
    };
    goster();
  },

  // ---------- hafıza
  hafiza(m) {
    const no = ++this.no;
    const kartlar = karistir([...m.ogeler, ...m.ogeler]);
    const sutun = kartlar.length <= 6 ? 3 : kartlar.length <= 8 ? 4 : kartlar.length <= 12 ? 4 : 4;
    let acik = [], kilit = false, bulunan = 0, hamle = 0;
    const izgara = h("div", { class: "hafiza", style: `grid-template-columns:repeat(${sutun},1fr);max-width:${sutun * 150}px` });
    const sayac = h("span", { class: "tr" }, "0 încercări");
    for (const k of kartlar) {
      const b = h("button", { class: "hkart", type: "button", "aria-label": "Carte" }, h("div", { class: "ic2" }, h("div", { class: "arka" }), h("div", { class: "yuz" }, em(k, 80))));
      b._k = k;
      b.addEventListener("click", async () => {
        if (kilit || b.classList.contains("acik")) return;
        b.classList.add("acik"); Ses.efekt("cevir"); acik.push(b);
        if (acik.length < 2) return;
        hamle++; sayac.textContent = `${hamle} încercări`;
        const [a, c] = acik; acik = [];
        if (a._k === c._k) {
          await bekle(300); a.classList.add("eslesti"); c.classList.add("eslesti"); Ses.efekt("dogru"); const [x, y] = merkez(c); patlat(x, y, 8);
          if (++bulunan === m.ogeler.length) { await bekle(700); if (this.no !== no) return; Kayit.etkinlik("memorie"); const st = m.cift >= 6 ? 3 : 2; Kayit.stea(st); this.kutla("Ai găsit toate perechile!", st, () => this.hafiza(m)); }
        } else { kilit = true; await bekle(900); a.classList.remove("acik"); c.classList.remove("acik"); kilit = false; }
      });
      izgara.append(b);
    }
    this.ac([this.ust(h("div", { class: "gen", style: "flex:1;text-align:center" }, sayac)), h("div", { class: "etk-govde" }, h("div", { class: "soru" }, h("h2", null, "Găsește perechile!")), izgara)]);
    Ses.soyle("Găsește perechile!");
  },

};

// Soru görseli: resim, adet, renk, şekil, sayı, harf, metin, işlem, dizi, hece.
function gorsel(g, px = 130, buyuk = false) {
  const kap = c => buyuk ? h("div", { class: "gorsel-kutu" }, c) : h("div", { style: "display:flex;flex-direction:column;align-items:center;gap:4px" }, c);
  const sayiYaz = (m, renk) => h("span", { style: `font-family:var(--baslik);font-weight:800;font-size:${Math.round(px * .62)}px;line-height:1;color:${renk}` }, m);
  if (g.toplama || g.cikarma) {
    const [a, b] = g.toplama || g.cikarma, k = Math.round(px * .34);
    const grup = (n, ciz) => h("div", { style: `display:flex;flex-wrap:wrap;gap:2px;max-width:${k * 3 + 6}px;justify-content:center` }, Array.from({ length: n }, (_, i) => { const e = em(g.img, k); if (ciz && i >= n - b) e.style.cssText += ";opacity:.3;filter:grayscale(1)"; return e; }));
    return kap(g.toplama ? h("div", { class: "satir", style: "gap:14px" }, grup(a), h("b", { style: "font-size:44px;font-family:var(--baslik)" }, "+"), grup(b)) : grup(a, true));
  }
  if (g.dizi_img || g.dizi_metin) {
    const l = g.dizi_img || g.dizi_metin;
    return kap(h("div", { class: "satir", style: "gap:8px;flex-wrap:wrap;justify-content:center" }, l.map(x => g.dizi_img ? (x === "?" ? h("b", { style: "font-size:56px;color:var(--mov)" }, "?") : em(x, 70)) : h("span", { style: `font-family:var(--baslik);font-weight:800;font-size:52px;min-width:56px;text-align:center;color:${x === "?" ? "var(--mov)" : "var(--metin)"}` }, x)), g.dizi_img ? h("b", { style: "font-size:56px;color:var(--mov)" }, "?") : null));
  }
  if (g.img && g.adet) {
    const n = g.adet, s = n === 1 ? 1 : n <= 4 ? 2 : n <= 9 ? 3 : 4, k = Math.floor(px / Math.max(s, Math.ceil(n / s)) * .9);
    return kap(h("div", { style: `display:grid;grid-template-columns:repeat(${s},${k}px);gap:2px;justify-content:center` }, Array.from({ length: n }, () => em(g.img, k))));
  }
  if (g.img) {
    const o = g.olcek || 1;
    const icerik = h("div", { style: `width:${px}px;height:${px}px;display:grid;place-items:center` }, em(g.img, Math.round(px * o)));
    const yazi = g.ro || g.metin;
    return kap([icerik, g.hece ? h("b", { style: "font-family:var(--baslik);font-size:34px;letter-spacing:.06em;color:var(--mov)" }, g.hece) : null, yazi ? h("span", { class: "yazi" }, yazi) : null]);
  }
  if (g.sekil) return kap([sekil(g.sekil, g.renk || "#42A5F5", px), g.ro ? h("span", { class: "yazi" }, g.ro) : null]);
  if (g.renk) return kap([sekil("pata", g.renk, px), g.ro ? h("span", { class: "yazi" }, g.ro) : null]);
  if (g.sayi != null) return kap(sayiYaz(String(g.sayi), "#5c6bc0"));
  if (g.harf) return kap(sayiYaz(g.harf, "#ef6c00"));
  if (g.metin) return kap(h("span", { style: `font-family:var(--baslik);font-weight:800;font-size:${px > 150 ? 46 : 32}px;padding:10px 6px` }, g.metin));
  return kap(h("span"));
}

// ============================================================ BAŞLAT
$("#logo").addEventListener("click", () => Yol.git(oturumAcik() ? "acasa" : "tanitim"));
$("#stele").addEventListener("click", () => Yol.git("premii"));
$("#parinte-lnk").addEventListener("click", () => Yol.git("parinti"));
$("#profil-btn").addEventListener("click", profilAc);
$("#giris-btn").addEventListener("click", () => Yol.git("giris"));
$("#kayit-btn").addEventListener("click", () => Yol.git("kayit"));
$("#ayar-btn").addEventListener("click", () => Yol.git("ayarlar"));
$("#duyuru-git").addEventListener("click", () => Yol.git("videoclipuri"));
$("#duyuru-kapat").addEventListener("click", () => { Kayit.v.duyuru_kapali = true; Kayit.kaydet(); ustCiz(); });
for (const b of document.querySelectorAll("[data-git]")) b.addEventListener("click", () => Yol.git(b.dataset.git));
window.addEventListener("hashchange", () => { const a = location.hash.slice(1); if (V && KOK.includes(a) && a !== Yol.su.ad && $("#etkinlik").hidden) Yol.git(a); });
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  if (!$("#uyari").hidden) { if (!$("#uyari").dataset.kilit) $("#uyari").hidden = true; }
  else if (!$("#etkinlik").hidden) Joc.kapat();
});
$("#uyari").addEventListener("click", e => { if (e.target.id === "uyari" && !e.target.dataset.kilit) e.target.hidden = true; });
(async () => {
  Kayit.yukle();
  for (const im of document.querySelectorAll("img[src]")) im.src = yol(im.getAttribute("src"));
  if (GOMULU) document.documentElement.style.setProperty("--tilki", `url(${yol("img/lumi_tilki.png")})`);
  document.documentElement.classList.toggle("az-anim", !!Kayit.v.az_anim);
  try {
    const [v, s, vid] = await Promise.all([getir("veri.json").then(r => r.json()), getir("ses/dizin.json").then(r => r.json()), getir("video/video.json").then(r => r.ok ? r.json() : []).catch(() => [])]);
    VIDEOLAR = vid;
    V = v; Ses.dizin = s.dizin; Ses.paketler = s.paketler;
    V.emoji.liste.forEach((k, i) => EMOJI[k] = i);
  } catch (e) {
    $("#ana").replaceChildren(h("div", { class: "yukleniyor" }, "Nu s-a putut încărca. Reîncarcă pagina."));
    return;
  }
  Ses.hazirla("ortak");
  menuCiz(); steleCiz(); profilCiz(); ustCiz();
  // Bu cihazda daha önce Lumi kullanıldıysa (eski sürüm) veriler korunur, cihaz kimliği sessizce verilir.
  Cihaz.yukle();
  if (!Cihaz.v && (Kayit.v.ebeveyn || Kayit.v.t)) Cihaz.olustur();
  if (BU_SAYFA) {
    if ((BU_SAYFA === "giris" || BU_SAYFA === "kayit") && oturumAcik()) { location.replace(SAYFALAR.acasa); return; }
    Yol.su = { ad: BU_SAYFA, p: BU_SAYFA === "kayit" ? { kilitli: new URLSearchParams(location.search).has("kilitli") } : {} };
    if (BU_SAYFA === "acasa" && !oturumAcik()) Yol.su = { ad: Kayit.v.ebeveyn ? "giris" : "tanitim", p: {} };
  } else {
    const hs = location.hash.slice(1);
    Yol.su = { ad: KOK.includes(hs) && (oturumAcik() || ACIK.includes(hs)) ? hs : oturumAcik() ? "acasa" : Kayit.v.ebeveyn ? "giris" : "tanitim", p: {} };
  }
  if (!Cihaz.v && !ACIK.includes(Yol.su.ad)) Yol.su = { ad: "tanitim", p: {} };
  if (!ACIK.includes(Yol.su.ad) && !oturumAcik()) Yol.su = Kayit.v.ebeveyn ? { ad: "giris", p: {} } : { ad: "kayit", p: { kilitli: true } };
  const adres = sayfaAdresi(Yol.su.ad, Yol.su.p);
  if (adres) { location.replace(adres); return; }
  if (!Cihaz.v) {
    // Yeni cihaz: önce kurulum. Bu cihazın oturumu sıfırdan başlar.
    Yol.ciz();
    kurulumAc(hedef => { Yol.git(hedef, {}, false); Hesap.bagla(); });
    return;
  }
  Yol.ciz();
  Hesap.bagla();
})();
